<?php
namespace Vnecoms\Sms\Block\Customer\Address;

class Edit extends \Vnecoms\Sms\Block\Customer\Account\Mobile
{
    
}
