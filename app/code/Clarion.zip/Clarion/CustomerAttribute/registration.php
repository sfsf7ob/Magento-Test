<?php
/**
 * Module configuration
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Clarion_CustomerAttribute',
    __DIR__
);
