1.0.0
=============
* 29-03-2017 Release
* 12-04-2017 Fix Btn Quickview not show after ajax load