<?php
namespace Codedecorator\AutoInvoice\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Framework\DB\Transaction;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Sales\Api\OrderRepositoryInterface;
use Codedecorator\AutoInvoice\Helper\Data;
use Magento\Framework\Event\Observer;
use Magento\Sales\Model\Order;
class Multishipping implements ObserverInterface
{
    protected $invoiceService;
    protected $transaction;
    protected $invoiceSender;
    protected $orderRepository;
    protected $helper;

    public function __construct(
        InvoiceService $invoiceService,
        Transaction $transaction,
        OrderRepositoryInterface $orderRepository,
        InvoiceSender $invoiceSender,
        Data $helper
    ) {
        $this->invoiceService = $invoiceService;
        $this->transaction = $transaction;
        $this->invoiceSender = $invoiceSender;
        $this->orderRepository = $orderRepository;
        $this->helper = $helper;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        try {
            foreach ($observer->getData('orders') as $order){
                /** @var $order \Magento\Sales\Model\Order */
                if ($this->helper->isEnable($order->getStoreId())) {
                    $amount = $this->helper->getMaxAmount($order->getStoreId());


                    if (!$order->canInvoice()) {
                        return null;
                    }
                    if (!$order->getState() == 'new') {
                        return null;
                    }
                    if ($amount < $order->getGrandTotal()) {
                        return null;
                    }
                    $invoice = $this->invoiceService->prepareInvoice($order);

                    $invoice->register();
                    $invoice->save();
                    $transactionSave = $this->transaction->addObject(
                        $invoice
                    )->addObject(
                        $invoice->getOrder()
                    );
                    $transactionSave->save();
                    $this->invoiceSender->send($invoice);//Send Invoice mail to customer

                    $status = Order::STATE_PROCESSING;

                    $order->setStatus($status)->setState($status);
                    $order->addStatusHistoryComment(
                        __('Notified customer about invoice creation #%1.', $invoice->getId())
                    )
                        ->setIsCustomerNotified(true)
                        ->save();
                    $this->orderRepository->save($order);
                }
            }

        } catch (\Exception $e) {
            return null;
        }
    }
}