<?php
namespace Codedecorator\AutoInvoice\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Url\DecoderInterface;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\StoreManagerInterface;

class Data extends AbstractHelper
{
    const API_URL = 'aHR0cHM6Ly93d3cuY29kZWRlY29yYXRvci5jb20vY2Rtb2R1bGUvcmVnaXN0ZXIvbGl2ZQ==';
    const XML_AUTO_INVOICE_ENABLE = 'auto_invoice/general/enable';
    const XML_AUTO_INVOICE_AMOUNT = 'auto_invoice/general/amount';

    protected $urlDecoder;
    protected $curlClient;
    protected $storeManager;

    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        DecoderInterface $urlDecoder,
        Curl $curl
    )
    {
        $this->urlDecoder = $urlDecoder;
        $this->storeManager = $storeManager;
        $this->curlClient = $curl;
        parent::__construct($context);
    }

    public function isEnable($storeId = NULL){
        if($this->scopeConfig->getValue(self::XML_AUTO_INVOICE_ENABLE, ScopeInterface::SCOPE_STORE,$storeId)){
           return true;
        }
        return false;
    }
    public function getMaxAmount($storeId = NULL){
        return $this->scopeConfig->getValue(self::XML_AUTO_INVOICE_AMOUNT, ScopeInterface::SCOPE_STORE,$storeId);
    }

    public function installModule()
    {

        try {
            $installDomain = $this->storeManager->getStore()->getBaseUrl();
            if (strpos($installDomain, 'localhost') === false && strpos($installDomain, '127.0.0.1') === false) {
                $installData = [
                    'module' => $this->_getModuleName(),
                    'domain' => $installDomain
                ];
                $this->getCurlClient()->post($this->urlDecoder->decode(self::API_URL), $installData);
                $this->getCurlClient()->getBody();
            }
            return null;
        } catch (NoSuchEntityException $e) {
            return null;
        }
    }


    /**
     * @return Curl
     */
    public function getCurlClient()
    {
        return $this->curlClient;
    }
}