var config = {
    map: {
        "*": {
            whatsAppChat: "Codedecorator_WhatsAppChat/js/whatsapp-data"
        }
    }
};