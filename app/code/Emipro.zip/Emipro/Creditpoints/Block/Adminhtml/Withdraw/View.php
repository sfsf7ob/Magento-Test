<?php
namespace Emipro\Creditpoints\Block\Adminhtml\Withdraw;
use Magento\Backend\Block\Widget\Form\Container as FormContainer;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\Registry;

class View extends FormContainer
{
	 public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }
	protected function _construct()
	{
		 $this->_objectId = 'withdraw_id';
		 $this->_mode="view";
        $this->_blockGroup = 'emipro_creditpoints';
        $this->_controller = 'adminhtml_withdraw';
        parent::_construct();
		$this->buttonList->remove('delete');
		$this->buttonList->remove('reset');
        $this->buttonList->update('delete', 'label', __('Delete Request'));
        $data = array(
        'label' =>  'Back',
        'onclick'   => 'setLocation(\'' . $this->getUrl('creditpoints/creditpoints/withdraw') . '\')',
        'class'     =>  'back'
		);
		$this->addButton ('my_back', $data,0,'header'); 
		$this->buttonList->remove('back');
		
	}
}
