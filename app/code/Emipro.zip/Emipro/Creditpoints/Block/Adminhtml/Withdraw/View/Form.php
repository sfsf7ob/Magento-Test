<?php
namespace Emipro\Creditpoints\Block\Adminhtml\Withdraw\View;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;

class Form extends Generic{
		protected $_coreRegistry;
	    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        array $data = []
    ) {
		$this->_coreRegistry = $registry;
        parent::__construct($context, $registry, $formFactory, $data);
    }
    /**
     * @return $this
     */
    public function _prepareForm()
    {		
        /** @var \Magento\Framework\Data\Form $form */
               $form = $this->_formFactory->create(
            [
                'data' => [
                    'id'    => 'edit_form',
                    'action' => $this->getData('action'),
                    'method' => 'post'
                ]
            ]
        );
          $form->setUseContainer(true);
		$this->setForm($form);
		$model = $this->_coreRegistry->registry("withdraw");
			
		$fieldset = $form->addFieldset('withdraw_form', ['legend'=>__('Withdraw Information')]);
				
		    $fieldset->addField('id', 'hidden', [
                'name' => 'id',
            ]);
        
		$fieldset->addField('status', 'select',[
                'name'      =>    'status',
                'label'     =>    __('Status'),
                'values' => [
					['value' => 'Pending', 'label' => __('Pending')],
					['value' => 'Approved', 'label' => __('Approved')],
					['value' => 'Disapproved', 'label' => __('Disapproved')],
				],				
				 'required' => true,
        ]);

		$fieldset->addField('name', 'text', [
				'label'     => __('Name'),
				'name'      => 'title',
				'readonly'	=>true,
		]);
		$fieldset->addField('email', 'text', [
				'label'     => __('Email'),
				'name'      => 'email',
				'readonly'	=>true,
		]);
		$fieldset->addField('amount', 'text', [
				'label'     => __('Amount'),
				'name'      => 'amount',
				'readonly'	=>true,
		]);
		$fieldset->addField('paypal_email', 'text', [
				'label'     => __('Paypal Email'),
				'name'      => 'paypal_email',
				'readonly'	=>true,
		]);
		$fieldset->addField('message', 'text', [
				'label'     => __('Message'),
				'name'      => 'message',
				'readonly'	=>true,
		]);
		$form->setValues($model->getData());
        return parent::_prepareForm();
    }
	}
