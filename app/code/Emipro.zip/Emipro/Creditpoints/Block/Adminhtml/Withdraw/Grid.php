<?php
namespace Emipro\Creditpoints\Block\Adminhtml\Withdraw;
 
class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;
 
    /**
     * @var \Webkul\Grid\Model\GridFactory
     */
    protected $_gridFactory;
 
    /**
     * @var \Webkul\Grid\Model\Status
     */
   
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Webkul\Grid\Model\GridFactory $gridFactory
     * @param \Webkul\Grid\Model\Status $status
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Emipro\Creditpoints\Model\WithdrawFactory $gridFactory,
        \Magento\Framework\Module\Manager $moduleManager,
        array $data = []
    ) {
        $this->_gridFactory = $gridFactory;
        
        $this->moduleManager = $moduleManager;
        parent::__construct($context, $backendHelper, $data);
    }
 
    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('gridGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
        $this->setVarNameFilter('grid_record');
    }
 
    /**
     * @return $this
     */
    protected function _prepareCollection()
    {
        $collection = $this->_gridFactory->create()->getCollection();
        $this->setCollection($collection);
 
        parent::_prepareCollection();
        return $this;
    }
 
    /**
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            'cid',
            [
                'header' => __('Customer ID'),
                'type' => 'number',
                'index' => 'cid',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        );
        $this->addColumn(
            'name',
            [
                'header' => __('Customer Name'),
                'index' => 'name',
            ]
        );
         $this->addColumn(
            'email',
            [
                'header' => __('Email'),
                'index' => 'email',
                'class' => 'xxx'
            ]
        );
         $this->addColumn(
            'amount',
            [
                'header' => __('Points'),
                'index' => 'amount',
            ]
        );
        $this->addColumn(
            'paypal_email',
            [
                'header' => __('Paypal Email'),
                'index' => 'paypal_email',
            ]
        );
        $this->addColumn(
            'message',
            [
                'header' => __('Message'),
                'index' => 'message',
            ]
        );
        $this->addColumn(
            'message',
            [
                'header' => __('Message'),
                'index' => 'message',
            ]
        );
         $this->addColumn(
            'status',
            [
                'header' => __('Status'),
                'index' => 'status',
            ]
        );
        $this->addColumn(
            'date',
            [
                'header' => __('Requested Date'),
                'index' => 'date',
                'type' => 'datetime'
            ]
        );
        $this->addColumn(
            'updated_date',
            [
                'header' => __('Updated Date'),
                'index' => 'updated_date',
                'type' => 'datetime'
            ]
        );
      

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }
 
        return parent::_prepareColumns();
    }
 
    /**
     * @return $this
     */
   
    public function getGridUrl()
    {
        return $this->getUrl('creditpoints/creditpoints/withdrawgrid', ['_current' => true]);
    }
	public function getRowUrl($row)
    {
		return $this->getUrl(
            'creditpoints/*/view',
            ['withdraw_id' => $row->getId()]
        );
    }
  
}
