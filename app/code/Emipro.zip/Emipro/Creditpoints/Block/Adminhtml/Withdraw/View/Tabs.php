<?php
namespace Emipro\Creditpoints\Block\Adminhtml\Withdraw\View;
use Magento\Backend\Block\Widget\Tabs as WidgetTabs;
class Tabs extends WidgetTabs {
	 public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $jsonEncoder, $authSession, $data);
    }
	protected function _construct()
    {
     
        $this->setId('withdraw_view_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Withdraw Request'));
        parent::_construct();
    }
        protected function _beforeToHtml()
    {
        $this->addTab(
            'withdraw_info',
            [
                'label' => __('Withdraw Information'),
                'title' => __('Withdraw Information'),
                'content' => $this->getLayout()->createBlock(
                    'Emipro\Creditpoints\Block\Adminhtml\Withdraw\View\Tab\Form'
                )->toHtml(),
                'active' => true
            ]
        ); 
        return parent::_beforeToHtml();
    }
     
}
