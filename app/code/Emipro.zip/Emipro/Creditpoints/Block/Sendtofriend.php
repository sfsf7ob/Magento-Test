<?php
namespace Emipro\Creditpoints\Block;
class Sendtofriend extends \Magento\Framework\View\Element\Template
{
     public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
     ) {
        parent::__construct($context, $data);
        $this->pageConfig->getTitle()->set(__('Send Credit Point(s) To Friend'));
    }
}
