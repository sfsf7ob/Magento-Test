<?php
namespace Emipro\Creditpoints\Block;
class Cart extends \Magento\Framework\View\Element\Template
{
}
