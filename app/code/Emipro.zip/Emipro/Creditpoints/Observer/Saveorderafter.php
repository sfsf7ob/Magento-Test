<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Emipro\Creditpoints\Observer;

use Magento\Framework\Event\ObserverInterface;
use Emipro\Creditpoints\Model\TransactionsFactory;
use \Magento\Framework\App\ResourceConnection;

class Saveorderafter implements ObserverInterface {

    protected $_collection;

    public function __construct(\Psr\Log\LoggerInterface $logger, \Magento\Sales\Model\ResourceModel\Order\Collection $collection,
    TransactionsFactory $TransactionsFactory,
    ResourceConnection $resource
    ) {
        $this->_collection = $collection;
        $this->_transaction=$TransactionsFactory;
        $this->_resource = $resource;
        $this->_logger = $logger;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) 
    {
        $new_data = $observer->getEvent()->getData('data_object')->getData();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $helper=$objectManager->get('Emipro\Creditpoints\Helper\Data');
        $order_amount = $helper->getConfig('creditpoints/creditpoints_order/order_amount');
		$ctredit_points = $helper->getConfig('creditpoints/creditpoints_order/ctredit_points');
		$allow_earn = $helper->getConfig('creditpoints/creditpoints_order/allow_earn');
        $transaction=$this->_transaction->create();
        $order_collection=$this->_collection;
        
        if($new_data['status']=="complete")
        {
			$cid=$new_data['customer_id'];
			$email=$new_data['customer_email'];
			$order = $objectManager->get("Magento\Sales\Model\Order")->load($new_data['increment_id'],'increment_id');
			if($cid){
				if($allow_earn){
					$ordergettotal = $order->getGrandTotal();
					if($ordergettotal >= $order_amount){
						$percentage = ($ctredit_points*100)/$order_amount;
						$orderpoint = round(($ordergettotal*$percentage)/100);
								$date=date("Y-m-d H:i:s");
								$tran["order_id"]=$new_data['increment_id'];
								$tran["customer_id"]=$cid;
								$tran["points_spent"]=0;
								$tran["name"]=$new_data['customer_firstname']." ".$new_data['customer_lastname'];;
								$tran["currency"]=$new_data['order_currency_code'];
								$tran["store_id"]=$new_data['store_id'];
								$tran["date"]=$date;
								$tran["reason"]="Earn Point(s) By Purchasing Product";
								$tran["points_get"]=$orderpoint;
								if($orderpoint>0)
								{
									$transaction->setData($tran);
									$transaction->save();
									$writeConnection = $this->_resource->getConnection('core_write');
									$table=$this->_resource->getTableName('customer_entity'); 
									$query = "UPDATE {$table} SET points = points+'{$orderpoint}' WHERE entity_id = ".(int)$cid;
									$writeConnection->query($query);
								}
					}
				}		
			}
			$items = $order->getAllItems();
			foreach ($items as $itemId => $item)
			{
				if($item->getSku()=="creditpoints")
				{
							$purchasepoints=$item->getQtyOrdered();
							$currentCurrencyCode = $new_data['order_currency_code'];
										
							$date=date("Y-m-d H:i:s");
							$tra["order_id"]=$new_data['increment_id'];
							$tra["customer_id"]=$cid;
							$tra["points_spent"]=0;
							$tra["name"]=$new_data['customer_firstname']." ".$new_data['customer_lastname'];;
							$tra["currency"]=$currentCurrencyCode;
							$tra["store_id"]=$new_data['store_id'];
							$tra["date"]=$date;
							$tra["reason"]="Purchase Point(s) From Store";
							$tra["points_get"]=$purchasepoints;
							if($purchasepoints>0)
							{
								$transaction->setData($tra);
								$transaction->save();
								
								$writeConnection = $this->_resource->getConnection('core_write');
								 $table=$this->_resource->getTableName('customer_entity'); 
								 $query = "UPDATE {$table} SET points = points+'{$purchasepoints}' WHERE entity_id = ".(int)$cid;
								 $writeConnection->query($query);
								 
								 return;
								
							}
						
					}

				}

		}
				
    }

}
