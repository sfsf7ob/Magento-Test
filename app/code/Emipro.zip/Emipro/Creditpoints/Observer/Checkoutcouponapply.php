<?php 

namespace Emipro\Creditpoints\Observer;
use Magento\Framework\Event\ObserverInterface;
class Checkoutcouponapply implements ObserverInterface
{
	protected $scopeConfig;
	protected $pointsSession;
	protected $_messageManager;
	public function __construct(
	\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
	\Magento\Framework\Message\ManagerInterface $messageManager
	){
		
		$this->_scopeConfig = $scopeConfig;
		$this->_messageManager = $messageManager;
		
	}
    public function execute(\Magento\Framework\Event\Observer $observer )
    {
    	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    	$pointsSession=$objectManager->get('Magento\Catalog\Model\Session');
         $allow=$this->_scopeConfig->getValue('creditpoints/creditpoints_options/allow_with_coupon', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
				if($allow == 0)
				{
					if($pointsSession->getPoints() != 0){
						$pointsSession->setPoints(0);
						$this->_messageManager->addError(
	                        __('Credit Points is not apply when coupon code is applied.')
	                    );
					}
				}
    	return;
    }
}