<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Emipro\Creditpoints\Observer;

use Magento\Framework\Event\ObserverInterface;
use Emipro\Creditpoints\Model\TransactionsFactory;
use \Magento\Framework\App\ResourceConnection;

class Successorder implements ObserverInterface {

    
 /** @var \Magento\Framework\Logger\Monolog */
    protected $_logger;
    protected $_orderFactory;    
    protected $_checkoutSession;
    
    public function __construct(        
        \Psr\Log\LoggerInterface $loggerInterface,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        ResourceConnection $resource,
        TransactionsFactory $TransactionsFactory
    ) {
        $this->_logger = $loggerInterface;
        $this->_checkoutSession = $checkoutSession; 
        $this->_orderFactory = $orderFactory;
        $this->_resource = $resource; 
        $this->_transaction=$TransactionsFactory;    
    }
 
    /**
     * This is the method that fires when the event runs.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer ) {        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $pointsSession=$objectManager->get('Magento\Catalog\Model\Session');
        $transaction=$this->_transaction->create();
        $orderIds = $observer->getEvent()->getOrderIds();
        if (count($orderIds)) {
            $orderId = $orderIds[0];            
            $order = $this->_orderFactory->create()->load($orderId);
            $customerSession=$objectManager->get('Magento\Customer\Model\Session');
			$customeremial = $customerSession->getCustomer()->getEmail();
            if($customeremial != ''){
	            if($order->getStatus() == 'complete' || $order->getStatus() == 'pending' || $order->getStatus() == 'processing'){
	            	$creaditpoints = $order->getCreditpointFeeAmount();
	            	if($creaditpoints != '' && $creaditpoints != '0.00' && $creaditpoints != 'NULL'){
	            		
	            			$date=date("Y-m-d H:i:s");
	            			$currentCurrencyCode = $order->getOrderCurrencyCode();
							$tra["order_id"]=$order->getIncrementId();
							$tra["customer_id"]=$order->getCustomerId();
							$tra["points_spent"]=abs($pointsSession->getPoints());
							$tra["name"]=$customerSession->getCustomer()->getFirstname()." ".$customerSession->getCustomer()->getLastname();
							$tra["currency"]=$currentCurrencyCode;
							$tra["store_id"]=$order->getStoreId();
							$tra["date"]=$date;
							$tra["reason"]="Spent Point(s) For Purchasing Product";
							$tra["points_get"]=0;
							$transaction->setData($tra);
							$transaction->save();
                            $sesscreditpoint = $pointsSession->getPoints();
							$writeConnection = $this->_resource->getConnection('core_write');
										 $table=$this->_resource->getTableName('customer_entity'); 
										 $query = "UPDATE {$table} SET points = points+'{$sesscreditpoint}' WHERE entity_id = ".(int)$order->getCustomerId();
										 $writeConnection->query($query);
							$pointsSession->setPoints(0);
                            $pointsSession->setCalcpoints(0);
                            $pointsSession->setCriditcustomitem(0);
                            $pointsSession->setCriditcustomitempoint(0);
    						return;
	            	}
	            }
            }           
        }
    }

}
