<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Emipro\Creditpoints\Observer;

use Magento\Framework\Event\ObserverInterface;

class Quotesubmitbefore implements ObserverInterface {
	protected $logger;
	public function __construct(\Psr\Log\LoggerInterface $logger)
	{
	    $this->logger = $logger;
	}
    public function execute(\Magento\Framework\Event\Observer $observer)
    {  
        $quote=$observer->getQuote();
        $order=$observer->getOrder();
        $order->setCreditpointFeeAmount($quote->getCreditpointFeeAmount());
        $order->setCreditpointBaseFeeAmount($quote->getCreditpointBaseFeeAmount());
    }

}
