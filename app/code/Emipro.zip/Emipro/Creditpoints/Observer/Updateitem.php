<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Emipro\Creditpoints\Observer;

use Magento\Framework\Event\ObserverInterface;

class Updateitem implements ObserverInterface {

	protected $scopeConfig;
    protected $_collection;
	protected $request;
	protected $_messageManager;
	protected $pointsSession;
    public function __construct(\Psr\Log\LoggerInterface $logger, \Magento\Sales\Model\ResourceModel\Order\Collection $collection,
    	\Magento\Framework\App\Request\Http $request,
    	\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    	\Magento\Framework\Message\ManagerInterface $messageManager) {
        $this->_collection = $collection;
        $this->_logger = $logger;
        $this->request = $request;
        $this->_scopeConfig = $scopeConfig;
        $this->_messageManager = $messageManager;

    }

    public function execute(\Magento\Framework\Event\Observer $observer) 
    {
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$maximum_points =  $this->_scopeConfig->getValue('creditpoints/creditpoints_options/max_point_allow', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		if($maximum_points == ''){$maximum_points = 0;}
		$customerData = $objectManager->get('Magento\Customer\Model\Session');
		 $cid=$customerData->getId();
		if($cid){
		$customernew = $objectManager->get('Magento\Customer\Model\Customer')->load($cid); 
		$total=$customernew->getPoints();
        $quote=$observer->getCart()->getQuote()->getAllItems();
        $observer->getCart()->getQuote()->setTotalsCollectedFlag(false)->collectTotals();
		$grand_total=$observer->getCart()->getQuote()->getGrandTotal();
		$pointsSession=$objectManager->get('Magento\Catalog\Model\Session');
		$point = $pointsSession->getPoints();
		if($grand_total < $point){
			$pointsSession->setPoints(0);
			$this->_messageManager->addNotice(
		                        __(
		                            'Current credit points is greater than grand total. Please apply credit points again.'
		                        )
		                    );
		}
		foreach ($quote as $itemId => $item) {
				if($item->getSku() =='creditpoints')
				{	if($item->getQty() > 0){
						if($maximum_points != 0){
							$allpoints = $total+$item->getQty(); 
							if($allpoints > $maximum_points){
								$qty = $maximum_points - $total;
								$this->_messageManager->addNotice(
			                        __(
			                            'Currently you have %1 credit points. You can have maximum %2 credit points. Please buy credit points within this limit.', $total,$maximum_points
			                        )
			                    );
								$item->setQty($qty)->save();
								$observer->getCart()->getQuote()->save();
								$observer->getCart()->getQuote()->setTotalsCollectedFlag(false)->collectTotals();
							}
						}
					}
				}
			
			}
		}		
    }

}
