<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Emipro\Creditpoints\Observer;

use Magento\Framework\Event\ObserverInterface;
use Emipro\Creditpoints\Model\TransactionsFactory;
use \Magento\Framework\App\ResourceConnection;

class Newregister implements ObserverInterface {

    protected $_collection;
    protected $_messageManager;
    protected $scopeConfig;
    public function __construct(\Psr\Log\LoggerInterface $logger, \Magento\Sales\Model\ResourceModel\Order\Collection $collection,
    TransactionsFactory $TransactionsFactory,
    ResourceConnection $resource,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    \Magento\Framework\Message\ManagerInterface $messageManager) {
        $this->_collection = $collection;
        $this->_transaction=$TransactionsFactory;
        $this->_resource = $resource;
        $this->_logger = $logger;
        $this->_scopeConfig = $scopeConfig;
        $this->_messageManager = $messageManager;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) 
    {
    	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    	$cid = $observer->getEvent()->getCustomer()->getId();
    	$cemail = $observer->getEvent()->getCustomer()->getEmail();
        $fname = $observer->getEvent()->getCustomer()->getFirstname();
        $lname = $observer->getEvent()->getCustomer()->getLastname();
        $fullname = $fname." ".$lname;
		$newacc_allow_earn =  $this->_scopeConfig->getValue('creditpoints/creditpoints_newaccount/newacc_allow_earn', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$newacc_earn_points =  $this->_scopeConfig->getValue('creditpoints/creditpoints_newaccount/newacc_earn_points', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$sendtofriend_allow =  $this->_scopeConfig->getValue('creditpoints/creditpoints_options/sendtofriend_allow', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$sendtofriendpoints = 0;
		if($sendtofriend_allow == 1){
			$sendtofriendcollection = $objectManager->get('Emipro\Creditpoints\Model\SendtofriendFactory')->create()->getCollection()->addFieldToFilter('email',$cemail);
			if($sendtofriendcollection->getData()){
			$sendtofriendname = '';
			foreach($sendtofriendcollection as $sendtofriend){
			    $sendtofriendpoints+=$sendtofriend->getPoints();
			    $sendtofriendpoint =$sendtofriend->getPoints();
			    $sendtofriendname = $sendtofriend->getSendername();
			    $sendtofriendConnection = $this->_resource->getConnection('core_write');
				$sendtofriendtable=$this->_resource->getTableName('customer_entity'); 
				$sendtofriendquery = "UPDATE {$sendtofriendtable} SET points = points+'{$sendtofriendpoint}' WHERE entity_id = ".(int)$cid;
				$sendtofriendConnection->query($sendtofriendquery);
		        $date=date("Y-m-d H:i:s");
		        $tranadd["customer_id"]=$cid;
		        $tranadd["name"]=$fullname;
		        $tranadd["date"]=$date;
		        $tranadd["reason"]="Get Credit Point(s) From ".$sendtofriendname;
		        $tranadd["points_get"]=$sendtofriendpoint;
		        $transactionadd=$this->_transaction->create();
		        $transactionadd->setData($tranadd);
		        $transactionadd->save();
			    $sendtofriend->delete();
			}
			}
		}
		if($newacc_allow_earn == 1){
			if($newacc_earn_points > 0 && $newacc_earn_points != ''){
		        
		        $transaction=$this->_transaction->create();
		        $purchasepoints=$newacc_earn_points;
				$date=date("Y-m-d H:i:s");
				$tra["customer_id"]=$cid;
				$tra["name"]=$fullname;
				$tra["date"]=$date;
				$tra["reason"]="Earn Point(s) By Create A New Account";
				$tra["points_get"]=$purchasepoints;
				
				$transaction->setData($tra);
				$transaction->save();

				$writeConnection = $this->_resource->getConnection('core_write');
				$table=$this->_resource->getTableName('customer_entity'); 
				$query = "UPDATE {$table} SET points = points+'{$purchasepoints}' WHERE entity_id = ".(int)$cid;
				$writeConnection->query($query);
				$finalpoints = $purchasepoints+$sendtofriendpoints;
				$this->_messageManager->addNotice(__('Congratulations! You have received %1 Credit Points.',$finalpoints));
			}
		}
		return;
       
    }

}
