<?php 
namespace Emipro\Creditpoints\Model\Total;
use Magento\Framework\Model\AbstractModel;

class Creditpointfee extends \Magento\Quote\Model\Quote\Address\Total\AbstractTotal
{
   /**
     * Collect grand total address amount
     *
     * @param \Magento\Quote\Model\Quote $quote
     * @param \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment
     * @param \Magento\Quote\Model\Quote\Address\Total $total
     * @return $this
     */
    protected $quoteValidator = null; 

    public function __construct(\Magento\Quote\Model\QuoteValidator $quoteValidator)
    {
        $this->quoteValidator = $quoteValidator;
    }
  public function collect(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
        \Magento\Quote\Model\Quote\Address\Total $total
    ) {
        parent::collect($quote, $shippingAssignment, $total);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    	$pointsSession=$objectManager->get('Magento\Catalog\Model\Session');
        $logger=$objectManager->get('Psr\Log\LoggerInterface');
		$used_points=$pointsSession->getPoints();
		$base_point = $objectManager->get('Emipro\Creditpoints\Helper\Data')->getConfig('creditpoints/creditpoints_options/one_point_cost');
	    $current_rate= number_format(($used_points*$base_point),2);
        $fee = $current_rate;
        $balance = $fee;
        $pointsSession->setCalcpoints(abs($balance));
        if(abs($balance) > 0){
            if ($quote->getBillingAddress()->getData('address_type') == 'billing'){
                if($total->getSubtotal())
                {
                    $total->setTotalAmount('creditpointfee', $balance);
                    $total->setBaseTotalAmount('creditpointfee', $balance);
                    $quote->setCreditpointFeeAmount($balance);
                    $quote->setCreditpointBaseFeeAmount($balance);
                    $pointsSession->setCalcpoints(abs($balance));
                }
            }
        }
        return $this;
    } 

    protected function clearValues(Address\Total $total)
    {
        $total->setTotalAmount('subtotal', 0);
        $total->setBaseTotalAmount('subtotal', 0);
        $total->setTotalAmount('tax', 0);
        $total->setBaseTotalAmount('tax', 0);
        $total->setTotalAmount('discount_tax_compensation', 0);
        $total->setBaseTotalAmount('discount_tax_compensation', 0);
        $total->setTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setBaseTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setSubtotalInclTax(0);
        $total->setBaseSubtotalInclTax(0);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $pointsSession=$objectManager->get('Magento\Catalog\Model\Session');
        $pointsSession->setCalcpoints(0);
        $pointsSession->setCriditcustomitem(0);
        $pointsSession->setCriditcustomitempoint(0);
    }
    /**
     * @param \Magento\Quote\Model\Quote $quote
     * @param Address\Total $total
     * @return array|null
     */
    /**
     * Assign subtotal amount and label to address object
     *
     * @param \Magento\Quote\Model\Quote $quote
     * @param Address\Total $total
     * @return array
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function fetch(\Magento\Quote\Model\Quote $quote, \Magento\Quote\Model\Quote\Address\Total $total)
    {
        if ($quote->getData('address_type') == 'shipping')
                return $this;
    	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    	$pointsSession=$objectManager->get('Magento\Catalog\Model\Session');
		$used_points=$pointsSession->getPoints();
		$base_point = $objectManager->get('Emipro\Creditpoints\Helper\Data')->getConfig('creditpoints/creditpoints_options/one_point_cost');
	    $current_rate= number_format(($used_points*$base_point),2);
        return [
            'code' => 'creditpointfee',
            'title' => __('Credit Points Discountsssss'),
            'value' => $current_rate
        ];
    }

    /**
     * Get Subtotal label
     *
     * @return \Magento\Framework\Phrase
     */
    public function getLabel()
    {
        return __('Credit Points Discount');
    }
}