<?php

namespace Emipro\Creditpoints\Model\Sales\Order\Pdf;

class Creditpointfee extends \Magento\Sales\Model\Order\Pdf\Total\DefaultTotal
{

    public function getTotalsForDisplay()
    {
	   parent::getTotalsForDisplay();
	   $amount = $this->getSource()->getCreditpointFeeAmount();
       if($amount){
       $charge=$this->getOrder()->formatPriceTxt($amount);

        $fontSize = $this->getFontSize() ? $this->getFontSize() : 7;
        $total = ['amount' => $charge, 'label' => 'Credit Points Discount', 'font_size' => $fontSize];
        return [$total];
        }else{
            return;
        }
	
    }
}
