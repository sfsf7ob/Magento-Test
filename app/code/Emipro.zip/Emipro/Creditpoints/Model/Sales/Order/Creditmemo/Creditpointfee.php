<?php
namespace Emipro\Creditpoints\Model\Sales\Order\Creditmemo;

class Creditpointfee extends \Magento\Sales\Model\Order\Creditmemo\Total\AbstractTotal
{
	protected $_code="creditpointfee";
	protected $_service_charge;
	  public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }
    
	public function collect(\Magento\Sales\Model\Order\Creditmemo $creditmemo) {

        parent::collect($creditmemo);
        $order=$creditmemo->getOrder();
		if($order->getCreditpointFeeAmount())
		{
			$creditmemo->setCreditpointFeeAmount($order->getCreditpointFeeAmount());
			$creditmemo->setCreditpointBaseFeeAmount($order->getCreditpointBaseFeeAmount());

			$creditmemo->setGrandTotal($creditmemo->getGrandTotal() + $order->getCreditpointFeeAmount());
			$creditmemo->setBaseGrandTotal($creditmemo->getBaseGrandTotal() + $order->getCreditpointBaseFeeAmount());
		
		}
        return $this;
    }
}
