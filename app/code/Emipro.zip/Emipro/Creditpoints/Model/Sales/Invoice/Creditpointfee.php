<?php
namespace Emipro\Creditpoints\Model\Sales\Invoice;

class Creditpointfee extends \Magento\Sales\Model\Order\Invoice\Total\AbstractTotal
{
	protected $_code="creditpointfee";
	protected $_service_charge;
	
	public function collect(\Magento\Sales\Model\Order\Invoice $invoice        
    ) {
        parent::collect($invoice);
			$order=$invoice->getOrder();
		if($order->getCreditpointFeeAmount())
		{
			$invoice->setCreditpointFeeAmount($order->getCreditpointFeeAmount());
			$invoice->setCreditpointBaseFeeAmount($order->getCreditpointBaseFeeAmount());

			$invoice->setGrandTotal($invoice->getGrandTotal() + $order->getCreditpointFeeAmount());
			$invoice->setBaseGrandTotal($invoice->getBaseGrandTotal() + $order->getCreditpointBaseFeeAmount());
		}
        return $this;
    } 

}
