<?php 
namespace Emipro\Creditpoints\Model;
use Magento\Framework\Model\AbstractModel;

class Withdraw  extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('Emipro\Creditpoints\Model\ResourceModel\Withdraw');
    }

}
