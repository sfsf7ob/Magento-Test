<?php 

namespace Emipro\Creditpoints\Model\ResourceModel\Transactions;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    
    protected function _construct()
    {
        $this->_init('Emipro\Creditpoints\Model\Transactions', 'Emipro\Creditpoints\Model\ResourceModel\Transactions');
    }

}

