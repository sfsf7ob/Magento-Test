<?php 

namespace Emipro\Creditpoints\Model\ResourceModel\Withdraw;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    
    protected function _construct()
    {
        $this->_init('Emipro\Creditpoints\Model\Withdraw', 'Emipro\Creditpoints\Model\ResourceModel\Withdraw');
    }

}

