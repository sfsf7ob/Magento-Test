<?php 

namespace Emipro\Creditpoints\Model\ResourceModel\Sendtofriend;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    
    protected function _construct()
    {
        $this->_init('Emipro\Creditpoints\Model\Sendtofriend', 'Emipro\Creditpoints\Model\ResourceModel\Sendtofriend');
    }

}

