<?php 
namespace Emipro\Creditpoints\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * Installs DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();
		
		$installer->getConnection()
		->addColumn($installer->getTable('customer_entity'),
		'points',
			array(
				'type' => Table::TYPE_INTEGER,
				'default' => 0,
				'comment' => 'points'
			)
			);
		$installer->endSetup();
        
		$installer = $setup;

        $installer->startSetup();
		
		
        $table = $installer->getConnection()
            ->newTable($installer->getTable('emipro_creditpoints_sendtofriend'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'nullable' => false, 'primary' => true],
                'Post ID'
            )
            ->addColumn('email', Table::TYPE_TEXT,  255, ['nullable' => false], 'Customer Email')
            ->addColumn('points', Table::TYPE_INTEGER,  null, ['nullable' => false], 'Points')
            ->addColumn('sendername', Table::TYPE_TEXT,  255, ['nullable' => false], 'Sender Name')
            ->setComment('Emipro Credit Points Send To Friend');
            
            
         $table2 = $installer->getConnection()
            ->newTable($installer->getTable('emipro_trans_credit_points'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'nullable' => false, 'primary' => true],
                'Post ID'
            )
            ->addColumn('order_id', Table::TYPE_TEXT, 32, ['nullable' => true, 'default' => null])
            ->addColumn('customer_id', Table::TYPE_INTEGER, null, ['nullable' => true], 'customer id')
            ->addColumn('points_get', Table::TYPE_INTEGER,  null, ['nullable' => false], 'points get')
            ->addColumn('points_spent', Table::TYPE_INTEGER,  null, ['nullable' => false], 'points spent')
            ->addColumn('reason', Table::TYPE_TEXT,  255, ['nullable' => false], 'points get')
            ->addColumn('comment', Table::TYPE_TEXT,  255, ['nullable' => false], 'comment')
            ->addColumn('date', Table::TYPE_DATETIME,  null, ['nullable' => false], 'date')
            ->addColumn('name', Table::TYPE_TEXT,  255, ['nullable' => false], 'name')
            ->addColumn('currency', Table::TYPE_TEXT,  100, ['nullable' => false], 'currency')
            ->addColumn('store_id', Table::TYPE_INTEGER,  null, ['nullable' => false], 'store_id')
            ->setComment('Emipro Trans Credit Points');

        $installer->getConnection()->createTable($table);
        $installer->getConnection()->createTable($table2);
        
        $installer->endSetup();
        
        $installer->startSetup();
        
        $installer->run("ALTER TABLE  `".$setup->getTable('quote')."` ADD  `creditpoint_fee_amount` DECIMAL( 10, 2 )  NULL");
        $installer->run("ALTER TABLE  `".$setup->getTable('quote')."` ADD  `creditpoint_base_fee_amount` DECIMAL( 10, 2 )  NULL");

        $installer->run("ALTER TABLE  `".$setup->getTable('quote_address')."` ADD  `creditpoint_fee_amount` DECIMAL( 10, 2 )  NULL");
		$installer->run("ALTER TABLE  `".$setup->getTable('quote_address')."` ADD  `creditpoint_base_fee_amount` DECIMAL( 10, 2 )  NULL");
		
		
		$installer->run("ALTER TABLE  `".$setup->getTable('sales_order')."` ADD  `creditpoint_fee_amount` DECIMAL( 10, 2 )  NULL");
		$installer->run("ALTER TABLE  `".$setup->getTable('sales_order')."` ADD  `creditpoint_base_fee_amount` DECIMAL( 10, 2 )  NULL");

		$installer->run("ALTER TABLE  `".$setup->getTable('sales_invoice')."` ADD  `creditpoint_fee_amount` DECIMAL( 10, 2 )  NULL");
		$installer->run("ALTER TABLE  `".$setup->getTable('sales_invoice')."` ADD  `creditpoint_base_fee_amount` DECIMAL( 10, 2 )  NULL");

		$installer->run("ALTER TABLE  `".$setup->getTable('sales_creditmemo')."` ADD  `creditpoint_fee_amount` DECIMAL( 10, 2 )  NULL");
		$installer->run("ALTER TABLE  `".$setup->getTable('sales_creditmemo')."` ADD  `creditpoint_base_fee_amount` DECIMAL( 10, 2 )  NULL");
		
		
		
		 $installer->endSetup();
		 
		 
		 $installer->startSetup();
		 $table3 = $installer->getConnection()
            ->newTable($installer->getTable('emipro_creditpoints_withdraw'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'nullable' => false, 'primary' => true],
                'Post ID'
            )
            ->addColumn('cid', Table::TYPE_INTEGER, null, ['nullable' => true, 'default' => null])
            ->addColumn('name', Table::TYPE_TEXT,  255, ['nullable' => false], 'name')
            ->addColumn('email', Table::TYPE_TEXT,  null, ['nullable' => false], 'points get')
            ->addColumn('amount', Table::TYPE_INTEGER,  null, ['nullable' => false], 'points spent')
            ->addColumn('paypal_email', Table::TYPE_TEXT,  255, ['nullable' => false], 'points get')
            ->addColumn('message', Table::TYPE_TEXT,  255, ['nullable' => false], 'points get')
            ->addColumn('status', Table::TYPE_TEXT,  255, ['nullable' => false], 'name')
            ->addColumn('date', Table::TYPE_DATETIME,  null, ['nullable' => false], 'date')
            ->addColumn('updated_date', Table::TYPE_DATETIME,  100, ['nullable' => false], 'currency')
            ->addColumn('is_approved', Table::TYPE_INTEGER,  null, ['nullable' => false], 'store_id')
            ->setComment('Emipro Credit Points Withdraw');

        $installer->getConnection()->createTable($table3);
		 
		 
		 
		 
    }

}
