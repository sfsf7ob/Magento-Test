<?php 
namespace Emipro\Creditpoints\Controller\Customer; 

use Magento\Backend\Model\View\Result\RedirectFactory;
use Emipro\Creditpoints\Model\TransactionsFactory;
use Emipro\Creditpoints\Model\SendtofriendFactory;
use Magento\Framework\App\RequestInterface;

class Submitsendtofriend extends \Magento\Framework\App\Action\Action {
     /**
         * @var \Magento\Framework\View\Result\PageFactory
         */
        protected $resultPageFactory;

		protected $_customerSession;
        /**
         * @param \Magento\Framework\App\Action\Context $context
         * @param \Magento\Framework\View\Result\PageFactory resultPageFactory
         */
        public function __construct(
            \Magento\Framework\App\Action\Context $context,
            TransactionsFactory $TransactionsFactory,
            SendtofriendFactory $SendtofriendFactory,
            \Magento\Customer\Model\Session $customerSession
        )
        {
            $this->_customerSession = $customerSession;
            $this->_transaction = $TransactionsFactory;
            $this->_sendtofriend = $SendtofriendFactory;
            parent::__construct($context);
            
        }
    /**
     * Default customer account page
     *
     * @return void
     */
     protected function _getSession()
    {
        return $this->_customerSession;
    }
     public function dispatch(RequestInterface $request)
    {
        if (!$this->_getSession()->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        return parent::dispatch($request);
    }
    public function execute()
    {
       $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
       $customerSession=$objectManager->get('Magento\Customer\Model\Session');
       $points = $customerSession->getCustomer()->getPoints();
       $escaper = $this->_objectManager->get('Magento\Framework\Escaper');
       $resultRedirect = $this->resultRedirectFactory->create();
       $helper=$objectManager->get('Emipro\Creditpoints\Helper\Data');
       $sendtofriend_allow =  $helper->getConfig('creditpoints/creditpoints_options/sendtofriend_allow');
       if($sendtofriend_allow != 1){
            $this->messageManager->addError(
                                __(
                                    'Sorry you can not allow to send credit points to friend.'
                                )
                            );
            return $resultRedirect->setPath('creditpoints/*/transaction');
       }
       $data=$this->getRequest()->getPost('sender');
       $storeManager =  $objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
       $transportBuilder = $objectManager->get('Magento\Framework\Mail\Template\TransportBuilder'); 
       $StateInterface = $objectManager->get('Magento\Framework\Translate\Inline\StateInterface'); 
       $websites = $storeManager->getStore()->getWebsiteId();
       $customer = $objectManager->create('Magento\Customer\Model\Customer')->setWebsiteId($websites)->loadByEmail($data['friend_email']);
       if($data['amount'] == '' || $data['amount'] <= 0){
        $this->messageManager->addError(
                                __(
                                    'Please enter credit points.'
                                )
                            );
            return $resultRedirect->setPath('creditpoints/*/sendtofriend');
       }
		if($data['amount'] > $points)
		{
			$this->messageManager->addError(
                                __(
                                    'Please enter credit points less than or equal to available balance.'
                                )
                            );
            return $resultRedirect->setPath('creditpoints/*/sendtofriend');
		}
		else
		{
            $sendpointsadd = abs($data['amount']);
            $sendpointsdeduct = -abs($data['amount']);
            // Send Credit Point(s) Start
            $connection = $objectManager->create('Magento\Framework\App\ResourceConnection')->getConnection();
            $table = $connection->getTableName('customer_entity');
            $query = "UPDATE {$table} SET points = points+'{$sendpointsdeduct}' WHERE entity_id = ".(int)$data['cid'];
            $connection->query($query);
			$date=date("Y-m-d H:i:s");
            $tran["customer_id"]=$data['cid'];
            $tran["points_spent"]=abs($sendpointsdeduct);
            $tran["name"]=$data['name'];
            $tran["date"]=$date;
            $tran["reason"]="Send Credit Point(s) To ".$data['firstname']." ".$data['lstname'].' ('.$data['friend_email'].')';
            $tran["points_get"]=0;
			$transaction=$this->_transaction->create();
			$transaction->setData($tran);
            $transaction->save();
            // Send Credit Point(s) End

            // Get Credit Point(s) Start
            if($customer->getId()){
            $connection = $objectManager->create('Magento\Framework\App\ResourceConnection')->getConnection();
            $table = $connection->getTableName('customer_entity');
            $query = "UPDATE {$table} SET points = points+'{$sendpointsadd}' WHERE entity_id = ".(int)$customer->getId();
            $connection->query($query);
            $date=date("Y-m-d H:i:s");
            $tranadd["customer_id"]=$customer->getId();
            $tranadd["points_spent"]=0;
            $tranadd["name"]=$data['firstname']." ".$data['lstname'];
            $tranadd["date"]=$date;
            $tranadd["reason"]="Get Credit Point(s) From ".$data['name'];
            $tranadd["points_get"]=$sendpointsadd;
            $transactionadd=$this->_transaction->create();
            $transactionadd->setData($tranadd);
            $transactionadd->save();
            
            $creditpoint_sendtofriend = $helper->getConfig('creditpoints/creditpoints_options/creditpoint_sendtofriend');            
            $options=['area' => "frontend",'store' => $storeManager->getStore()->getId(),];
            $templateVars = array(
                    'store' => $storeManager->getStore(),
                    'sender_name' => $data['name'],
                    'recipient_name' => $data['firstname']." ".$data['lstname'],
                    'points'   => $sendpointsadd,
                    'message_friend'   => $data['message'],
                    'login_url' => $objectManager->get('\Magento\Framework\UrlInterface')->getUrl('customer/account/login')
                );
            $from = array('email' => $data['email'], 'name' => $data['name']);
            $StateInterface->suspend();
            $to = array($data['friend_email']);
            $transport = $transportBuilder->setTemplateIdentifier($creditpoint_sendtofriend)
                ->setTemplateOptions($options)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($to)
                ->getTransport();
            $transport->sendMessage();
            $StateInterface->resume();

            }else{
            $sendtof["email"]=$data['friend_email'];
            $sendtof["points"]=$sendpointsadd;
            $sendtof["sendername"]=$data['name'];
            $sendtofriend=$this->_sendtofriend->create();
            $sendtofriend->setData($sendtof);
            $sendtofriend->save();
            $creditpoint_sendtofriendnotexist = $helper->getConfig('creditpoints/creditpoints_options/creditpoint_sendtofriendnotexist');            
            $options=['area' => "frontend",'store' => $storeManager->getStore()->getId(),];
            $templateVars = array(
                    'store' => $storeManager->getStore(),
                    'sender_name' => $data['name'],
                    'recipient_name' => $data['firstname']." ".$data['lstname'],
                    'points'   => $sendpointsadd,
                    'message_friend'   => $data['message'],
                    'register_url' => $objectManager->get('\Magento\Framework\UrlInterface')->getUrl('customer/account/create')
                );
            $from = array('email' => $data['email'], 'name' => $data['name']);
            $StateInterface->suspend();
            $to = array($data['friend_email']);
            $transport = $transportBuilder->setTemplateIdentifier($creditpoint_sendtofriendnotexist)
                ->setTemplateOptions($options)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($to)
                ->getTransport();
            $transport->sendMessage();
            $StateInterface->resume();
            }
            // Get Credit Point(s) End
			$this->messageManager->addSuccess(
                                __(
                                    'Credit point(s) sent successfully to '.$data['firstname'].' '.$data['lstname'].'.'
                                )
                            );
			return $resultRedirect->setPath('creditpoints/*/transaction');
		}
    }
}
