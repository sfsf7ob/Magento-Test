<?php 
namespace Emipro\Creditpoints\Controller\Customer; 

use Emipro\Creditpoints\Model\TransactionsFactory;
use Magento\Framework\App\RequestInterface;

class Transaction extends \Magento\Framework\App\Action\Action {
     /**
         * @var \Magento\Framework\View\Result\PageFactory
         */
        protected $resultPageFactory;
        
        protected $_modelTransactionsFactory;
        protected $_customerSession;
        /**
         * @param \Magento\Framework\App\Action\Context $context
         * @param \Magento\Framework\View\Result\PageFactory resultPageFactory
         */
        public function __construct(
            \Magento\Framework\App\Action\Context $context,
            \Magento\Framework\View\Result\PageFactory $resultPageFactory,
            \Magento\Customer\Model\Session $customerSession,
            TransactionsFactory $modelTransactionsFactory
        )
        {

            parent::__construct($context);
            $this->_modelTransactionsFactory = $modelTransactionsFactory;
            $this->resultPageFactory = $resultPageFactory;
            $this->_customerSession = $customerSession;
            
        }
    /**
     * Default customer account page
     *
     * @return void
     */
     protected function _getSession()
    {
        return $this->_customerSession;
    }
     public function dispatch(RequestInterface $request)
    {
        if (!$this->_getSession()->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        return parent::dispatch($request);
    }
    public function execute()
    {
       $this->_view->loadLayout();
       $this->_view->renderLayout();
    }
}
