<?php 
namespace Emipro\Creditpoints\Controller\Customer; 

//use Emipro\Creditpoints\Model\TransactionsFactory;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Framework\App\RequestInterface;

class Purchasepoint extends \Magento\Framework\App\Action\Action 
{
	
	protected $scopeConfig;
	protected $pointsSession;
	protected $_resultRedirectFactory;
	protected $_checkoutSession;
	protected $_customerSession;
	
	public function __construct(
	\Magento\Framework\App\Action\Context $context,
	\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
	\Magento\Checkout\Model\Cart $cart,
	\Magento\Catalog\Model\Session $catalogSession,
	\Magento\Checkout\Model\Session $checkoutSession,
	\Magento\Customer\Model\Session $customerSession,
	
	RedirectFactory $resultRedirectFactory
	
	){
		
		parent::__construct(
		$context,
		$this->_scopeConfig = $scopeConfig,
		$cart,
		$this->catalogSession = $catalogSession,
		$this->_checkoutSession = $checkoutSession,
		$this->_customerSession = $customerSession,
		$resultRedirectFactory
		);
		
	}
	protected function _getSession()
    {
        return $this->_customerSession;
    }
     public function dispatch(RequestInterface $request)
    {
        if (!$this->_getSession()->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        return parent::dispatch($request);
    }
	public function execute()
    {
		$data=(array)$this->getRequest()->getPost();
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$resultRedirect = $this->resultRedirectFactory->create();
		
		$product = $objectManager->get('Magento\Catalog\Model\Product');
		
		if(!$product->getIdBySku('creditpoints'))
			try{
			$product
				->setWebsiteIds(array(1)) 
				->setAttributeSetId(4) 
				->setTypeId('virtual') 
				->setCreatedAt(strtotime('now')) 
			
			 
				->setSku('creditpoints') 
				->setName('Credit Points')
				
				->setStatus(1)
				->setTaxClassId(0) 
				->setPrice(1) 
				->setMetaTitle('Credit Points')
				->setMetaKeyword('Credit Points')
				->setMetaDescription('Credit Points')
			 
				->setDescription('Credit Points')
				->setShortDescription('Credit Points')
			 
				->setMediaGallery (array('images'=>array (), 'values'=>array ()))
				->addImageToMediaGallery('/creditpoints/coin.png', array('image','thumbnail','small_image'), false, false)
			 
				->setStockData(array(
								   'use_config_manage_stock' => 0, 
								   'manage_stock'=>0, 
								   'min_sale_qty'=>1, 
								   
								   'is_in_stock' => 1, 
								   'qty' => 9999 
							   )
				);

			$product->save();
			
			}
			catch(\Magento\Framework\Exception\LocalizedException $e)
			{
				// $this->messageManager->addError(__($e->getMessage()));
			}
			$maximum_points =  $this->_scopeConfig->getValue('creditpoints/creditpoints_options/max_point_allow', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
			if($maximum_points == ''){$maximum_points = 0;}
			$product_sku ="creditpoints"; 
			$qty = $data["points"]; 
			$qtys = $data["points"]; 
			$id = $objectManager->get('Magento\Catalog\Model\Product')->getIdBySku($product_sku);
			
					 $customerData = $objectManager->get('Magento\Customer\Model\Session');
					 $cid=$customerData->getId();
   
					 $customernew = $objectManager->get('Magento\Customer\Model\Customer')->load($cid); 
					 $total=$customernew->getPoints();
					if($qty > 0)
					{
						if($maximum_points != 0){
							$allpoints = $total+$qty; 
							if($allpoints > $maximum_points){
								$qty = $maximum_points - $total;
								$this->messageManager->addNotice(
	                                __(
	                                    'Currently you have %1 credit points. You can have maximum %2 credit points. Please buy credit points within this limit.', $total,$maximum_points
	                                )
	                            );
	                            return $resultRedirect->setPath('creditpoints/customer/transaction');
							}
						}
					}
			
			if($qty > 0)
			{
					$_product = $objectManager->get('Magento\Catalog\Model\Product')->load($id);
					$cart = $objectManager->get('Magento\Checkout\Model\Cart');
					//$cart->init();
					$cart->addProduct($_product, array('qty' => $qty));
					$cart->save();
					$this->_checkoutSession->setCartWasUpdated(true);
					
					$this->messageManager->addSuccess(
                                __(
                                    '%1 credit point(s)  has been added into your cart.', $qty
                                )
                            );
					
					
					return $resultRedirect->setPath('checkout/cart');
				
			}
			
			
	}
	
}
