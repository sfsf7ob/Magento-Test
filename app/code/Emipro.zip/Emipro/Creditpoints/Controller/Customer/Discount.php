<?php 
namespace Emipro\Creditpoints\Controller\Customer; 

//use Emipro\Creditpoints\Model\TransactionsFactory;
use Magento\Framework\App\RequestInterface;

class Discount extends \Magento\Framework\App\Action\Action 
{
	
	protected $scopeConfig;
	protected $pointsSession;
	protected $_customerSession;
	
	public function __construct(
	\Magento\Framework\App\Action\Context $context,
	\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
	\Magento\Checkout\Model\Cart $cart,
	\Magento\Catalog\Model\Session $catalogSession,
	\Magento\Customer\Model\Session $customerSession
	
	){
		
		parent::__construct(
		$context,
		$this->_scopeConfig = $scopeConfig,
		$cart,
		$this->catalogSession = $catalogSession,
		$this->_customerSession = $customerSession
		);
		
	}
	protected function _getSession()
    {
        return $this->_customerSession;
    }
     public function dispatch(RequestInterface $request)
    {
        if (!$this->_getSession()->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        return parent::dispatch($request);
    }
	protected function _goBack($backUrl = null)
    {
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($backUrl || $backUrl = $this->getBackUrl($this->_redirect->getRefererUrl())) {
            $resultRedirect->setUrl($backUrl);
        }
        
        return $resultRedirect;
    }
    protected function _isInternalUrl($url)
    {
        if (strpos($url, 'http') === false) {
            return false;
        }

        /**
         * Url must start from base secure or base unsecure url
         */
        /** @var $store \Magento\Store\Model\Store */
        $store = $this->_storeManager->getStore();
        $unsecure = strpos($url, $store->getBaseUrl()) === 0;
        $secure = strpos($url, $store->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_LINK, true)) === 0;
        return $unsecure || $secure;
    }
	 protected function getBackUrl($defaultUrl = null)
    {
        $returnUrl = $this->getRequest()->getParam('return_url');
        if ($returnUrl && $this->_isInternalUrl($returnUrl)) {
            $this->messageManager->getMessages()->clear();
            return $returnUrl;
        }

        $shouldRedirectToCart = $this->_scopeConfig->getValue(
            'checkout/cart/redirect_to_cart',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        if ($shouldRedirectToCart || $this->getRequest()->getParam('in_cart')) {
            if ($this->getRequest()->getActionName() == 'add' && !$this->getRequest()->getParam('in_cart')) {
                $this->_checkoutSession->setContinueShoppingUrl($this->_redirect->getRefererUrl());
            }
            return $this->_url->getUrl('checkout/cart');
        }

        return $defaultUrl;
    }
	public function execute()
    {
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$one_point_cost =  $this->_scopeConfig->getValue('creditpoints/creditpoints_options/one_point_cost', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$minimum_points =  $this->_scopeConfig->getValue('creditpoints/creditpoints_options/min_point_redeem', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$maximum_points_perorder =  $this->_scopeConfig->getValue('creditpoints/creditpoints_usage/maxusage_point_perorder', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$maximum_points_percentage_perorder =  $this->_scopeConfig->getValue('creditpoints/creditpoints_usage/percentage_of_order_amount', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		if($maximum_points_perorder == ''){$maximum_points_perorder=0;}
		if($maximum_points_percentage_perorder == ''){$maximum_points_percentage_perorder=0;}
		$customerSession = $objectManager->get('Magento\Customer\Model\Session');
		$helper=$objectManager->get('Magento\Framework\Pricing\Helper\Data');
		$cart_data=$objectManager->get('Magento\Checkout\Model\Session')->getQuote();
		$coupon_code = $objectManager->get('Magento\Checkout\Model\Session')->getQuote()->getCouponCode(); 
		$grandTotal=$cart_data["grand_total"];//exit;
		if($maximum_points_percentage_perorder != 0 && $maximum_points_perorder != 0){
			$maximum_points_percentage_perorder_final = round(($grandTotal*$maximum_points_percentage_perorder)/100);
			if($maximum_points_percentage_perorder_final > $maximum_points_perorder){
				$maximum_points_usage = $maximum_points_percentage_perorder_final;
			}else{
				$maximum_points_usage = $maximum_points_perorder;
			}
		}else{
			$maximum_points_usage = 0;
		}
		$cartallitems = $cart_data->getAllItems();
		
		if($customerSession->isLoggedIn()) 
		{
			$points=$customerSession->getCustomer()->getPoints();
			$id=$customerSession->getCustomer()->getId();//print customer id
			
		}
		$customerSession=$objectManager->get('Magento\Customer\Model\Session');
		$customerpoints = $customerSession->getCustomer()->getPoints();
		$credit_points=$this->getRequest()->getpost('credit-points');
		$crdapply=$this->getRequest()->getpost('crdapply');
		$crdcancle=$this->getRequest()->getpost('crdcancle');
		$escaper = $this->_objectManager->get('Magento\Framework\Escaper');
		$current_rate=$helper->currency(($credit_points*$one_point_cost),null,true,false);
		//echo $grand_total=$helper->currency(number_format(($grandTotal),2),true,false);
		if($crdapply){
			if($cartallitems){
				foreach ($cartallitems as $itemId => $item) {
					if($item->getSku() =='creditpoints')
					{	if($item->getQty() > 0){
								$this->messageManager->addError(
			                        __(
			                            'Credit Point(s) %1 is not apply on product Credit Points.', 
			                            $escaper->escapeHtml($credit_points)
			                        )
			                    );
			                	return $this->_goBack();
						}
					}
				
				}
			}
			if($maximum_points_usage != 0){
				if($credit_points > $maximum_points_usage){
					$this->messageManager->addError(
		                                __(
		                                    'Usage limit exceeded. Your maximum credit points usage limit is %1.',
		                                    $maximum_points_usage
		                                )
		                            );
		            return $this->_goBack();
				}
			}
			if($maximum_points_percentage_perorder != 0 && $maximum_points_perorder == 0){
				$maximum_points_percentage_perorder_final = round(($grandTotal*$maximum_points_percentage_perorder)/100);
				if($credit_points > $maximum_points_percentage_perorder_final){
					$this->messageManager->addError(
		                                __(
		                                    'Usage limit exceeded. Your maximum credit points usage limit is %1.',
		                                    $maximum_points_percentage_perorder_final
		                                )
		                            );
		            return $this->_goBack();
				}

			}
			if($maximum_points_perorder != 0 && $maximum_points_percentage_perorder == 0){
				if($credit_points > $maximum_points_perorder){
					$this->messageManager->addError(
		                                __(
		                                    'Usage limit exceeded. Your maximum credit points usage limit is %1.',
		                                    $maximum_points_perorder
		                                )
		                            );
		            return $this->_goBack();
				}

			}
			if($credit_points < $minimum_points && $minimum_points > 0)
			{
				$this->messageManager->addError(
	                                __(
	                                    'Minimum redeemable points are  %1.',
	                                    $escaper->escapeHtml($minimum_points)
	                                )
	                            );
	            return $this->_goBack();
			}
			
			elseif($credit_points > $points)
			{
				
				$this->messageManager->addError(
	                        __('Credit Points %1 is not valid. You used maximum %2 points.', $escaper->escapeHtml($credit_points),$customerpoints)
	                    );
	                   
	            return $this->_goBack();
			}
			elseif($current_rate > $grandTotal)
			{
				
				$this->messageManager->addError(
	                        __('Credit Points %1 is not valid.', $escaper->escapeHtml($credit_points))
	                    );
	                   
	            return $this->_goBack();
			}
			if($coupon_code)
			{ 
				$allow=$this->_scopeConfig->getValue('creditpoints/creditpoints_options/allow_with_coupon', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
				if($allow == 0)
				{
					$this->messageManager->addError(
                        __('Credit Points is not apply when coupon code is applied.')
                    );
                   return $this->_goBack();
				}
			}
			
			if($credit_points > $one_point_cost)
			{
				$this->messageManager->addSuccess(
	                                __(
	                                    'You used %1 credit points.',
	                                    $escaper->escapeHtml($credit_points)
	                                )
	                            );
			}
		}
		$pointsSession=$objectManager->get('Magento\Catalog\Model\Session');
		if($crdcancle){
			$this->messageManager->addNotice(
                                __(
                                    'Credit point cancled. Now you used 0 credit point.'
                                )
                            );
			$pointsSession->setPoints(0);
		}else{
			$pointsSession->setPoints(-$credit_points);
		}
		
		return $this->_goBack();
	}
	
}
