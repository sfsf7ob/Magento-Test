<?php 
namespace Emipro\Creditpoints\Controller\Customer; 

use Magento\Backend\Model\View\Result\RedirectFactory;
use Emipro\Creditpoints\Model\WithdrawFactory;
use Magento\Framework\App\RequestInterface;

class Submitwithdraw extends \Magento\Framework\App\Action\Action {
     /**
         * @var \Magento\Framework\View\Result\PageFactory
         */
        protected $resultPageFactory;
		protected $_resultRedirectFactory;
		protected $_customerSession;
        /**
         * @param \Magento\Framework\App\Action\Context $context
         * @param \Magento\Framework\View\Result\PageFactory resultPageFactory
         */
        public function __construct(
            \Magento\Framework\App\Action\Context $context,
            WithdrawFactory $withdrawFactory,
            \Magento\Customer\Model\Session $customerSession
        )
        {
            $this->_withdraw=$withdrawFactory;
            $this->_customerSession = $customerSession;
            parent::__construct($context);
            
        }
    /**
     * Default customer account page
     *
     * @return void
     */
     protected function _getSession()
    {
        return $this->_customerSession;
    }
     public function dispatch(RequestInterface $request)
    {
        if (!$this->_getSession()->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        return parent::dispatch($request);
    }
    public function execute()
    {
       $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
       $customerSession=$objectManager->get('Magento\Customer\Model\Session');
       $points = $customerSession->getCustomer()->getPoints();
       $escaper = $this->_objectManager->get('Magento\Framework\Escaper');
       $resultRedirect = $this->resultRedirectFactory->create();
       $helper=$objectManager->get('Emipro\Creditpoints\Helper\Data');
       $minimum = $helper->getConfig('creditpoints/creditpoints_options/min_point_redeem');
      
       $data=$this->getRequest()->getPost('sender');
       
       if($data['amount'] < $minimum)
		{
			$this->messageManager->addError(
                                __(
                                    'Minimum Reedeamable points are  %1.',
                                    $escaper->escapeHtml($minimum)
                                )
                            );
            return $resultRedirect->setPath('creditpoints/*/withdraw');
		}
		if($data['amount'] > $points)
		{
			$this->messageManager->addError(
                                __(
                                    'Please enter amount less than or equal to available balance.'
                                )
                            );
            return $resultRedirect->setPath('creditpoints/*/withdraw');
		}
		else
		{
			$date=date("Y-m-d H:i:s");
			$data['status']="Pending";
			$data['date']=$date;
			$data['updated_date']=$date;
			$model=$this->_withdraw->create();
			$model->setData($data);
			$model->save();
			
			$this->messageManager->addSuccess(
                                __(
                                    'Request is submitted successfully.'
                                )
                            );
			return $resultRedirect->setPath('creditpoints/*/withdraw');
		}
    }
}
