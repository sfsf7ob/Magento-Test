<?php
namespace Emipro\Creditpoints\Controller\Adminhtml\Creditpoints;

class Points extends \Magento\Backend\App\Action
{
    
    public function execute()
    {
      
    }
}
