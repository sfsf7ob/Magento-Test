<?php

namespace Emipro\Creditpoints\Controller\Adminhtml\Creditpoints;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Emipro\Creditpoints\Model\WithdrawFactory;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Framework\App\ResourceConnection;
class Save extends Action
{
	protected $_coreRegistry = null;
	protected $_resultPageFactory;
	protected $_resource;
	public function __construct(
	Context $context,
	WithdrawFactory $withdrawFactory,
	PageFactory $pageFactory,
	ResourceConnection $resource
	)
	{
		$this->_withdraw=$withdrawFactory;
		$this->_resultPageFactory=$pageFactory;
		$this->_resource = $resource;
		parent::__construct($context);

	}
	public function execute()
	{
		$data=$this->getRequest()->getParams();
		$resultRedirect = $this->resultRedirectFactory->create();
		
		 if ($data) 
		 {
			
			$points=$data["amount"];
			$customer=$this->_withdraw->create()->load($data["id"]);
			$isApproved=$customer->getIsApproved();
            try {
					if($data["status"]=="Approved" && $isApproved==1)
					{
						$this->messageManager->addError(
                                __(
                                    'Request Is Already Approved.'
                                )
                            );
						return $resultRedirect->setPath('creditpoints/creditpoints/withdraw');
						
					}
					
					if($data["status"]=="Approved" && $isApproved==0)
					{
								 $date=date("Y-m-d H:i:s");
								 $status=array("status"=>$data["status"],"updated_date"=>$date,"is_approved"=>1);
								
								 $cid=$customer->getCid();
								 $writeConnection = $this->_resource->getConnection('core_write');
								 $table=$this->_resource->getTableName('customer_entity'); 
								 $query = "UPDATE {$table} SET points = points-'{$points}' WHERE entity_id = ".(int)$cid;
								 $writeConnection->query($query);
							 
								 $model=$this->_withdraw->create()->load($data["id"]);
								 $model->addData($status);
						         $model->setId($data["id"])->save();
						        
						        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
								$customerData= $objectManager->get('Magento\Customer\Model\Customer')->load($cid)->getData();
								$fn=$customerData["firstname"];
								$ln=$customerData["lastname"];
								$name=$fn." ".$ln;
						        $transobj=$objectManager->create("Emipro\Creditpoints\Model\Transactions");
								$trans["customer_id"]=$cid;
								$trans["comment"]='';
								$trans["points_spent"]=$points; 
								$trans["reason"]="Withdraw Credit Point(s)";
								$date=date("Y-m-d H:i:s");
								$trans["date"]=$date;
								$trans["name"]=$name;
								
								$transobj->setData($trans);
								$transobj->save();
					}
					else
					{
						$date=date("Y-m-d H:i:s");
						$status=array("status"=>$data["status"],"updated_date"=>$date);
						$model=$this->_withdraw->create()->load($data["id"]);
						$model->addData($status);
						$model->setId($data["id"])->save();
					}
					$this->messageManager->addSuccess(
                                __(
                                    'Withdraw was successfully saved.'
                                )
                            );
						return $resultRedirect->setPath('creditpoints/creditpoints/withdraw');
                
				
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError(__($e->getMessage()));
				return $resultRedirect->setPath('creditpoints/creditpoints/withdraw',array('withdraw_id' => $this->getRequest()->getParam('id')));
            }

		}
	}
}
