<?php
namespace Emipro\Creditpoints\Controller\Adminhtml\Creditpoints;


use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Emipro\Creditpoints\Model\WithdrawFactory;
use Magento\Framework\View\Result\PageFactory;

class View extends Action
{
	  protected $_coreRegistry = null;
	protected $_resultPageFactory;
	public function __construct(
	Context $context,
	WithdrawFactory $withdrawFactory,
	PageFactory $pageFactory,
	\Magento\Framework\Registry $registry
	)
	{
		$this->_coreRegistry = $registry;
		$this->_withdraw=$withdrawFactory;
		$this->_resultPageFactory=$pageFactory;
		parent::__construct($context);

	}
	public function execute()
	{
		
		$id = $this->getRequest()->getParam('withdraw_id');
		$model=$this->_withdraw->create();
		$data=$model->load($id);
		$this->_coreRegistry->register("withdraw",$data);
		$resultPage=$this->_resultPageFactory->create();
		$resultPage->setActiveMenu('Emipro_Creditpoints::withdraw');
        $resultPage->addBreadcrumb(__('Withdraw Request'), __('Withdraw Request'));
        $resultPage->getConfig()->getTitle()->prepend(__('Withdraw Request'));
		return $resultPage;
	}
}
