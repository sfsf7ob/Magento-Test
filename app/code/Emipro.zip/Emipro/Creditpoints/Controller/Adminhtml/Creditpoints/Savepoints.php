<?php
namespace Emipro\Creditpoints\Controller\Adminhtml\Creditpoints;

use Emipro\Creditpoints\Model\TransactionsFactory;
use Magento\Backend\Model\View\Result\RedirectFactory;

class Savepoints extends \Magento\Backend\App\Action
{
    
    protected $resultPageFactory;
        
    protected $_modelTransactionsFactory;
    
    protected $_resultPageFactory;
    
    protected $scopeConfig;
    
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        TransactionsFactory $modelTransactionsFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    )
    {
        $this->_modelTransactionsFactory = $modelTransactionsFactory;
        $this->_scopeConfig = $scopeConfig;   
        parent::__construct($context);
    }
    

    public function execute()
    {
      	$resultRedirect = $this->resultRedirectFactory->create();
      	$data=$this->getRequest()->getParams();
		$transactionData = $this->_modelTransactionsFactory->create();
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerData= $objectManager->get('Magento\Customer\Model\Customer')->load($data['customer_id'])->getData();
		
		$id=$data["customer_id"];
		$points=$data["points"];
		$fn=$customerData["firstname"];
		$ln=$customerData["lastname"];
		$name=$fn." ".$ln;
		$customerpoint = $customerData["points"];
		$maximum_points =  $this->_scopeConfig->getValue('creditpoints/creditpoints_options/max_point_allow', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		if($maximum_points == ''){$maximum_points = 0;}
					if($points > 0)
					{
						if($maximum_points != 0){
							$allpoints = $customerpoint+$points; 
							if($allpoints > $maximum_points){
								$oldenterpoints = $points;
								$points = $maximum_points - $customerpoint;
									$this->messageManager->addNotice(
					                        __(
					                            'Currently customer have %1 credit points. Customer can have maximum %2 credit points. Please add credit points within this limit.', $customerpoint,$maximum_points
					                        )
					                );
										return $resultRedirect->setPath('customer/index/edit/id/'.$id.'/');
							}
						}
					}
					try
					{
					$connection = $objectManager->create('Magento\Framework\App\ResourceConnection')->getConnection();
					$table = $connection->getTableName('customer_entity');
					 $query = "UPDATE {$table} SET points = points+'{$points}' WHERE entity_id = ".(int)$id;
					 $connection->query($query);
					}
					catch(\Magento\Framework\Exception\LocalizedException $e)
					{
						$this->messageManager->addError(__($e->getMessage()));
					}
						$d=$objectManager->create("Emipro\Creditpoints\Model\Transactions");
						$trans["customer_id"]=$id;
						$trans["comment"]=$data["comment"];
						if($points>0)
						{
						$trans["points_get"]=$points;
						}
						else
						{ 
							$trans["points_spent"]=abs($points); 
						}
						$trans["reason"]="Updated Point(s) By Admin";
						$date=date("Y-m-d H:i:s");
						$trans["date"]=$date;
						$trans["name"]=$name;
						
						$d->setData($trans);
						$d->save();
						if($points < 0)
						{
							$this->messageManager->addSuccess(
                                __(
                                    'Credit point(s) deducted successfully.'
                                )
                            );
						}else{
							$this->messageManager->addSuccess(
                                __(
                                    'Credit point(s) added successfully .'
                                )
                            );
						}
						return $resultRedirect->setPath('customer/index/edit/id/'.$id.'/');
     
    }
}
