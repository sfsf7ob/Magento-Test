<?php

namespace Emipro\Rma\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface {

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;

        $installer->startSetup();

        $table = $installer->getConnection()
                ->newTable($installer->getTable('emipro_rma_status'))
                ->addColumn(
                        'status_id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true], 'Status ID'
                )
                ->addColumn('title', Table::TYPE_TEXT, 255, ['nullable' => true], 'title')
                ->addColumn('sort_order', Table::TYPE_INTEGER, null, ['nullable' => false], 'sort_order')
                ->addColumn('is_active', Table::TYPE_INTEGER, null, ['nullable' => false], 'is_active')
                ->setComment('Emipro Rma Setup');
        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
                ->newTable($installer->getTable('emipro_rma_reason'))
                ->addColumn(
                        'reason_id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true], 'Reason ID'
                )
                ->addColumn('title', Table::TYPE_TEXT, 255, ['nullable' => true], 'title')
                ->addColumn('sort_order', Table::TYPE_INTEGER, null, ['nullable' => false], 'sort_order')
                ->addColumn('is_active', Table::TYPE_INTEGER, null, ['nullable' => false], 'is_active')
                ->setComment('Emipro Rma Reason');
        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
                ->newTable($installer->getTable('emipro_rma_package_condition'))
                ->addColumn(
                        'packagecon_id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true], 'Packagecon ID'
                )
                ->addColumn('title', Table::TYPE_TEXT, 255, ['nullable' => true], 'title')
                ->addColumn('sort_order', Table::TYPE_INTEGER, null, ['nullable' => false], 'sort_order')
                ->addColumn('is_active', Table::TYPE_INTEGER, null, ['nullable' => false], 'is_active')
                ->setComment('Emipro Rma Reason');
        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
                ->newTable($installer->getTable('emipro_rma_return'))
                ->addColumn(
                        'return_id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true], 'Return ID'
                )
                ->addColumn('title', Table::TYPE_TEXT, 255, ['nullable' => true], 'title')
                ->addColumn('is_active', Table::TYPE_INTEGER, null, ['nullable' => false], 'is_active')
                ->addColumn('sort_order', Table::TYPE_INTEGER, null, ['nullable' => false], 'sort_order')
                ->addColumn('description', Table::TYPE_TEXT, '64k', ['nullable' => true], 'description')
                ->setComment('Emipro Rma Return');
        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
                ->newTable($installer->getTable('emipro_rma_request'))
                ->addColumn(
                        'rma_id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true], 'Rmi ID'
                )
                ->addColumn('order_id', Table::TYPE_INTEGER, null, ['nullable' => false], 'order_id')
                ->addColumn('product_id', Table::TYPE_INTEGER, null, ['nullable' => false], 'product_id')
                ->addColumn('qty', Table::TYPE_INTEGER, null, ['nullable' => false], 'qty')
                ->addColumn('reason', Table::TYPE_INTEGER, null, ['nullable' => false], 'reason')
                ->addColumn('return', Table::TYPE_INTEGER, null, ['nullable' => false], 'return')
                ->addColumn('package', Table::TYPE_INTEGER, null, ['nullable' => false], 'package')
                ->addColumn('customer_id', Table::TYPE_INTEGER, null, ['nullable' => false], 'customer_id')
                ->addColumn('customer_name', Table::TYPE_TEXT, 255, ['nullable' => true], 'customer_name')
                ->addColumn('date', Table::TYPE_DATETIME, null, ['nullable' => true], 'date')
                ->addColumn('status', Table::TYPE_INTEGER, null, ['nullable' => false], 'stats')
                ->setComment('Emipro Rma Request');
        $installer->getConnection()->createTable($table);

        $installer->run("ALTER TABLE {$setup->getTable('emipro_rma_request')} AUTO_INCREMENT=100000000");

        $table = $installer->getConnection()
                ->newTable($installer->getTable('emipro_rma_conversation'))
                ->addColumn(
                        'conversation_id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true], 'Conversation ID'
                )
                ->addColumn('rma_id', Table::TYPE_INTEGER, null, ['nullable' => false], 'rma_id')
                ->addColumn('status_id', Table::TYPE_INTEGER, null, ['nullable' => false], 'status_id')
                ->addColumn('current_admin', Table::TYPE_INTEGER, null, ['nullable' => false], 'current_admin')
                ->addColumn('user_details', Table::TYPE_TEXT, 255, ['nullable' => true], 'user_details')
                ->addColumn('name', Table::TYPE_TEXT, 255, ['nullable' => true], 'name')
                ->addColumn('message', Table::TYPE_TEXT, '64k', ['nullable' => true], 'message')
                ->addColumn('message_type', Table::TYPE_TEXT, 255, ['nullable' => true], 'message_type')
                ->addColumn('date', Table::TYPE_DATETIME, null, ['nullable' => true], 'date')
                ->addForeignKey(
                        $installer->getFkName(
                                'emipro_rma_conversation', 'status_id', 'emipro_rma_status', 'status_id'
                        ), 'status_id', $installer->getTable('emipro_rma_status'), 'status_id', \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE, \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE)
                ->addForeignKey(
                        $installer->getFkName(
                                'emipro_rma_conversation', 'rma_id', 'emipro_rma_request', 'rma_id'
                        ), 'rma_id', $installer->getTable('emipro_rma_request'), 'rma_id', \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE, \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE)
                ->setComment('Emipro Rma Conversation');
        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
                ->newTable($installer->getTable('emipro_rma_attachment'))
                ->addColumn(
                        'attachment_id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true], 'Attachment_id ID'
                )
                ->addColumn('conversation_id', Table::TYPE_INTEGER, null, ['nullable' => false], 'conversation_id')
                ->addColumn('file', Table::TYPE_TEXT, 255, ['nullable' => true], 'file')
                ->addColumn('current_file_name', Table::TYPE_TEXT, 255, ['nullable' => true], 'current_file_name')
                ->addColumn('date', Table::TYPE_DATETIME, null, ['nullable' => true], 'date')
                ->addForeignKey(
                        $installer->getFkName(
                                'emipro_rma_attachment', 'conversation_id', 'emipro_rma_conversation', 'conversation_id'
                        ), 'conversation_id', $installer->getTable('emipro_rma_conversation'), 'conversation_id', \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE, \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE)
                ->setComment('Emipro Rma Conversation');
        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }

}
