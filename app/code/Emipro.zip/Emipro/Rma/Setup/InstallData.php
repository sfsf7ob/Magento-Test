<?php

namespace Emipro\Rma\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface {

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context) {


        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();


        $status = $objectManager->create("Emipro\Rma\Model\Status");
        $status->setTitle("Pending Approval");
        $status->setSortOrder(10);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Status");
        $status->setTitle("Approved");
        $status->setSortOrder(20);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Status");
        $status->setTitle("Package Sent");
        $status->setSortOrder(30);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Status");
        $status->setTitle("Rejected");
        $status->setSortOrder(40);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Status");
        $status->setTitle("Closed");
        $status->setSortOrder(50);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Status");
        $status->setTitle("Canceled");
        $status->setSortOrder(60);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Reason");
        $status->setTitle("Out Of Service");
        $status->setSortOrder(10);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Reason");
        $status->setTitle("Dislike");
        $status->setSortOrder(20);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Reason");
        $status->setTitle("Wrong type");
        $status->setSortOrder(30);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Reason");
        $status->setTitle("Wrong Size");
        $status->setSortOrder(40);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Reason");
        $status->setTitle("Other");
        $status->setSortOrder(50);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Retur");
        $status->setTitle("Replacement");
        $status->setSortOrder(10);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Retur");
        $status->setTitle("Refund");
        $status->setSortOrder(20);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Retur");
        $status->setTitle("Store Credit");
        $status->setSortOrder(30);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Package");
        $status->setTitle("Opened");
        $status->setSortOrder(10);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Package");
        $status->setTitle("Not Opened");
        $status->setSortOrder(20);
        $status->setIsActive(1);
        $status->save();

        $status = $objectManager->create("Emipro\Rma\Model\Package");
        $status->setTitle("Damaged");
        $status->setSortOrder(30);
        $status->setIsActive(1);
        $status->save();
    }

}
