<?php
namespace Emipro\Rma\Block;
use Magento\Backend\Model\View\Result\RedirectFactory;
class Rma extends \Magento\Framework\View\Element\Template
{
     protected $_gridFactory; 
     protected $_resultRedirectFactory;
     public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Emipro\Rma\Model\RmaFactory $rmaFactory,
        RedirectFactory $resultRedirectFactory,
        
        array $data = []
     ) {
        $this->_rmaFactory = $rmaFactory;
        parent::__construct($context, $data, $resultRedirectFactory);
        //get collection of data 
        $collection = $this->_rmaFactory->create()->getCollection();
        $this->setCollection($collection);
        $this->pageConfig->getTitle()->set(__('RMA Requests'));
    }
  
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if ($this->getCollection()) {
            // create pager block for collection 
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'emipro.rma.record.pager'
            )->setCollection(
                $this->getCollection() // assign collection to pager
            );
            $this->setChild('pager', $pager);// set pager block in layout
        }
        return $this;
    }
  
    /**
     * @return string
     */
    // method for get pager html
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }   
}
?>
