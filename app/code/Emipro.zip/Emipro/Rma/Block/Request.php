<?php
namespace Emipro\Rma\Block;
class Request extends \Magento\Framework\View\Element\Template
{
     protected $_gridFactory; 
     protected $catalogSession;
     public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Emipro\Rma\Model\RmaFactory $rmaFactory,
        \Magento\Catalog\Model\Session $catalogSession,
        array $data = []
     ) {
        $this->_rmaFactory = $rmaFactory;
        parent::__construct($context, $data);
        //get collection of data 
        $collection = $this->_rmaFactory->create()->getCollection();
        $this->setCollection($collection);
        $this->catalogSession = $catalogSession;
        $this->pageConfig->getTitle()->set(__('RMA Requests'));
    }
	public function getCatalogSession()
	{
		return $this->catalogSession;
	}
}
?>
