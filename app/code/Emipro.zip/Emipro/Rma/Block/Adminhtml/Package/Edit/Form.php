<?php

namespace Emipro\Rma\Block\Adminhtml\Package\Edit;

use Magento\Backend\Block\Widget\Form\Generic;
use Emipro\Rma\Helper\Data;
use Magento\Framework\Registry;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Data\FormFactory;

class Form extends Generic {

    protected $helper;
    protected $_coreRegistry;

    public function __construct(
    Context $context, Registry $registry, FormFactory $formFactory, Data $helper, array $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->helper = $helper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    protected function _prepareForm() {

        $form = $this->_formFactory->create(
                [
                    'data' => [
                        'id' => 'edit_form',
                        'action' => $this->getUrl('*/*/savepackage', array('id' => $this->getRequest()->getParam('id'))),
                        'method' => 'post',
                        'enctype' => 'multipart/form-data'
                    ]
                ]
        );

        $fieldset = $form->addFieldset(
                'base_fieldset', ['legend' => __('Package Condition Information')]
        );

        $fieldset->addField('title', 'text', array(
            'label' => __('Title'),
            'name' => 'title',
            'required' => true,
        ));

        $fieldset->addField('sort_order', 'text', array(
            'label' => __('Sort Order'),
            'name' => 'sort_order',
            'note' => 'Sort order defines the priority in which a particular package condition will appear. It goes in ascending order. If the values are 10, 20, and 30, package condition with the value 10 will displayed first followed by 20 and 30.',
        ));

        $fieldset->addField('is_active', 'select', array(
            'name' => 'is_active',
            'label' => __('Active'),
            'values' => array(
                array('value' => 0, 'label' => __('No')),
                array('value' => 1, 'label' => __('Yes')),
            ),
        ));
        if ($this->_coreRegistry->registry('package')) {
            $form->setValues($this->_coreRegistry->registry('package')->getData());
        }
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }

}
