<?php

namespace Emipro\Rma\Block\Adminhtml\Package;

class Edit extends \Magento\Backend\Block\Widget\Form\Container {

    protected $_coreRegistry = null;

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context, \Magento\Framework\Registry $registry
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context);
    }

    protected function _construct() {
        $this->_objectId = 'id';
        $this->_blockGroup = 'emipro_rma';
        $this->_controller = 'adminhtml_package';
        parent::_construct();
        $id = $this->getRequest()->getParam("id");
        $this->buttonList->remove('back');
        $this->buttonList->remove('delete');
        $data = array(
            'label' => 'Back',
            'onclick' => 'setLocation(\'' . $this->getUrl('*/*/managepackage') . '\')',
            'class' => 'back'
        );
        $this->buttonList->add('my_back', $data, -1, 'header');
        }

    public function getHeaderText() {
        if ($this->_coreRegistry->registry('package')->getId()) {
            return __("Edit Post '%1'", $this->escapeHtml($this->_coreRegistry->registry('status')->getTitle()));
        } else {
            return __('New Grid');
        }
    }

}
