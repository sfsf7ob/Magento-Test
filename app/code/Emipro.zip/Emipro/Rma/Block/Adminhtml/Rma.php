<?php

namespace Emipro\Rma\Block\Adminhtml;

use Magento\Backend\Block\Widget\Container;

class Rma extends Container {

    protected $_template = 'grid/view.phtml';

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context
    ) {
        parent::__construct($context);
    }

    protected function _prepareLayout() {
        $addButtonProps = [
            'id' => 'gridGrid',
            'label' => __('Add New RMA'),
            'class' => 'add',
            'button_class' => '',
             'onclick' => "setLocation('" . $this->_getCreateUrl() . "')",
            'style' => "background-color: #eb5202;border-color: #eb5202;color: #fff;"
        ];
        $this->buttonList->add('add_new', $addButtonProps);

        $this->setChild(
                'grid', $this->getLayout()->createBlock('Emipro\Rma\Block\Adminhtml\Rma\Grid', 'rma.view.grid')
        );
        return parent::_prepareLayout();
    }

    protected function _getCreateUrl() {
        return $this->getUrl(
                        'rma/rma/newrma'
        );
    }

    public function getGridHtml() {
        return $this->getChildHtml('grid');
    }

}
