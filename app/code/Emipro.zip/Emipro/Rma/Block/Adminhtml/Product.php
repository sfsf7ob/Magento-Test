<?php

namespace Emipro\Rma\Block\Adminhtml;

use Magento\Backend\Block\Widget\Container;

class Product extends Container {

    protected $_template = 'grid/view.phtml';

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context
    ) {
        parent::__construct($context);
    }

}
