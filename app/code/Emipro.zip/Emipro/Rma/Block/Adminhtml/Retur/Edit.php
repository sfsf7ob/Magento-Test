<?php

namespace Emipro\Rma\Block\Adminhtml\Retur;

class Edit extends \Magento\Backend\Block\Widget\Form\Container {

    protected $_coreRegistry = null;

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context, \Magento\Framework\Registry $registry
    ) {

        $this->_coreRegistry = $registry;
        parent::__construct($context);
    }

    protected function _construct() {
        $this->_objectId = 'id';
        $this->_blockGroup = 'emipro_rma';
        $this->_controller = 'adminhtml_retur';
        parent::_construct();
        $id = $this->getRequest()->getParam("id");
        $this->buttonList->remove('back');
        $this->buttonList->remove('delete');
        $data = array(
            'label' => 'Back',
            'onclick' => 'setLocation(\'' . $this->getUrl('*/*/managereturn') . '\')',
            'class' => 'back'
        );
        $this->buttonList->add('my_back', $data, -1, 'header');
    }

    public function getHeaderText() {
        if ($this->_coreRegistry->registry('return')->getId()) {
            return __("Edit Post '%1'", $this->escapeHtml($this->_coreRegistry->registry('return')->getTitle()));
        } else {
            return __('New Grid');
        }
    }

    protected function _prepareLayout() {
        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('page_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'content');
                }
            };
        ";
        return parent::_prepareLayout();
    }

}
