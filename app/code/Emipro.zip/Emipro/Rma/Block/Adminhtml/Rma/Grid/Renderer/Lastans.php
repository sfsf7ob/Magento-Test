<?php

namespace Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer;

class Lastans extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer {

    public function __construct(\Magento\Backend\Block\Context $context, array $data = []) {
        parent::__construct($context, $data);
        $this->_authorization = $context->getAuthorization();
    }

    public function render(\Magento\Framework\DataObject $row) {
        $r_id = $this->_getValue($row);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $collection = $objectManager->get('Emipro\Rma\Model\Conversation')->getCollection()->addFieldToFilter('rma_id',$r_id);
        $collection->getSelect()->order("conversation_id DESC");
         $cstName=$collection->getFirstItem()->getUserDetails();
        if(isset($cstName))
        {
            return $cstName;
        }
        else
        {
           return "Yet not replied";
        }
    }

}
