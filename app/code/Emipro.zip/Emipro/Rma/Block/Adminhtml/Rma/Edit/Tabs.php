<?php

namespace Emipro\Rma\Block\Adminhtml\Rma\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs {

    protected function _construct() {
        parent::_construct();
        $this->setId('rma_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Manage RMA Request'));
    }

}
