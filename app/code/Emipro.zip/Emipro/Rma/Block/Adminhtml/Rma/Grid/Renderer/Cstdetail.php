<?php

namespace Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer;

class Cstdetail extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer {

    public function __construct(\Magento\Backend\Block\Context $context, array $data = []) {
        parent::__construct($context, $data);
        $this->_authorization = $context->getAuthorization();
    }

    public function render(\Magento\Framework\DataObject $row) {
        $c_id = $this->_getValue($row);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cst = $objectManager->get('Magento\Customer\Model\Customer')->load($c_id);
        $cst_name = $cst->getName();
        $cst_email = $cst->getEmail();
        return '<a href="' . $this->_urlBuilder->getUrl("customer/index/edit", array("id" => $c_id)) . '" target="_blank">' . $cst_name . '</a> <br>'.$cst_email;
    }

}
