<?php

namespace Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer;

class Product extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer {

    public function __construct(\Magento\Backend\Block\Context $context, array $data = []) {
        parent::__construct($context, $data);
        $this->_authorization = $context->getAuthorization();
    }

    public function render(\Magento\Framework\DataObject $row) {
        $p_id = $this->_getValue($row);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product = $objectManager->get('Magento\Catalog\Model\Product')->load($p_id);
        $pro_id = $product->getId();
        $pro_name = $product->getName();
        return '<a href="' . $this->_urlBuilder->getUrl("catalog/product/edit", array("id" => $pro_id)) . '" target="_blank">' . $pro_name . '</a>';
    }

}
