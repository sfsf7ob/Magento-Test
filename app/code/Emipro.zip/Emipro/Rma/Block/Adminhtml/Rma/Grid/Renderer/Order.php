<?php

namespace Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer;

class Order extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer {

    public function __construct(\Magento\Backend\Block\Context $context, array $data = []) {
        parent::__construct($context, $data);
        $this->_authorization = $context->getAuthorization();
    }

    public function render(\Magento\Framework\DataObject $row) {
        $o_id = $this->_getValue($row);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $order = $objectManager->get('Magento\Sales\Model\Order')->load($o_id);
        $orderinc_id = $order->getIncrementId();
        $order_id = $order->getEntityId();

        return '<a href="' . $this->_urlBuilder->getUrl("sales/order/view", array("order_id" => $order_id)) . '" target="_blank">' . $orderinc_id . '</a>';
    }

}
