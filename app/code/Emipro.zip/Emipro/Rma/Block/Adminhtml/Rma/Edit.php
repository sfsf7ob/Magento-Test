<?php

namespace Emipro\Rma\Block\Adminhtml\Rma;

class Edit extends \Magento\Backend\Block\Widget\Form\Container {

    protected $_coreRegistry = null;

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context, \Magento\Framework\Registry $registry
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context);
    }

    protected function _construct() {
        $this->_objectId = 'id';
        $this->_blockGroup = 'emipro_rma';
        $this->_controller = 'adminhtml_rma';

        parent::_construct();
        $this->buttonList->remove('delete');
        $this->buttonList->remove('save');
    }

    public function getHeaderText() {
        if ($this->_coreRegistry->registry('rma')->getId()) {
            return __("Edit Post '%1'", $this->escapeHtml($this->_coreRegistry->registry('rma')->getTitle()));
        } else {
            return __('New Grid');
        }
    }

    protected function _getSaveAndContinueUrl() {
        return $this->getUrl('rma/rma/save', ['_current' => true, 'back' => 'edit', 'active_tab' => '{{tab_id}}']);
    }

    protected function _prepareLayout() {
        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('page_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'content');
                }
            };
        ";
        return parent::_prepareLayout();
    }

}
