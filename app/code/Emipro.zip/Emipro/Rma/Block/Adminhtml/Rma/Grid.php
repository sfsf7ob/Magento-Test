<?php

namespace Emipro\Rma\Block\Adminhtml\Rma;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended {

    protected $_projectsFactory;
    protected $moduleManager;

    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Framework\Module\Manager $moduleManager, \Magento\Backend\Helper\Data $backendHelper, \Emipro\Rma\Model\RmaFactory $rmaFactory
    ) {
        $this->moduleManager = $moduleManager;
        $this->_rmaFactory = $rmaFactory;

        parent::__construct($context, $backendHelper);
    }

    protected function _construct() {
        parent::_construct();
        $this->setId('emipro_rma');
        $this->setDefaultSort('rma_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
        $this->setVarNameFilter('rma_id');
    }

    protected function _prepareCollection() {

        $collection = $this->_rmaFactory->create()->getCollection();
        $this->setCollection($collection);
        parent::_prepareCollection();
        return $this;
    }

    protected function _prepareColumns() {
        $this->addColumn(
                'rma_id', [
            'header' => __('Request ID #'),
            'type' => 'number',
            'index' => 'rma_id',
            'header_css_class' => 'col-id',
            'column_css_class' => 'col-id',
            'renderer' => '\Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer\Erma',
                ]
        );

        $this->addColumn(
                'order_id', [
            'header' => __('Order ID #'),
            'index' => 'order_id',
            'type' => 'text',
            'renderer' => '\Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer\Order',
            'filter_condition_callback' => array($this, '_filterHasUrlConditionCallback'),
                ]
        );

          $this->addColumn(
                'customer_id', [
            'header' => __('Customer'),
            'index' => 'customer_id',
            'renderer' => '\Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer\Cstdetail',
            'filter_condition_callback' => array($this, '_filterCustomer'),
                ]
        );

        $this->addColumn(
                'product_id', [
            'header' => __('Product Name'),
            'index' => 'product_id',
            'type' => 'text',
            'renderer' => '\Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer\Product',
            'filter_condition_callback' => array($this, '_filterHasUrlCallback'),
                ]
        );
              
        $this->addColumn(
                'qty', [
            'header' => __('Qty'),
            'index' => 'qty'
                ]
        );

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $reasonArray = $objectManager->create("Emipro\Rma\Model\Reason")->getCollection()->addFieldToFilter("is_active", 1);
        $reason = array();
        foreach ($reasonArray as $newreason) {
            $reason[$newreason->getId()] = $newreason->getTitle();
        }
        $this->addColumn(
                'reason', [
            'header' => __('Reason'),
            'index' => 'reason',
            'type' => 'options',
            'options' => $reason
                ]
        );

        $returnArray = $objectManager->create("Emipro\Rma\Model\Retur")->getCollection()->addFieldToFilter("is_active", 1);
        $returns = array();
        foreach ($returnArray as $newreturn) {
            $returns[$newreturn->getId()] = $newreturn->getTitle();
        }
        $this->addColumn(
                'return', [
            'header' => __('Return Type'),
            'index' => 'return',
            'type' => 'options',
            'options' => $returns
                ]
        );

        $packageArray = $objectManager->create("Emipro\Rma\Model\Package")->getCollection()->addFieldToFilter("is_active", 1);
        $package = array();
        foreach ($packageArray as $newpackage) {
            $package[$newpackage->getId()] = $newpackage->getTitle();
        }
        $this->addColumn(
                'package', [
            'header' => __('Package Condition'),
            'index' => 'package',
            'type' => 'options',
            'options' => $package
                ]
        );

         $this->addColumn(
                'reply', [
            'header' => __('Last Answered By'),
            'index' => 'rma_id',
            'renderer' => '\Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer\Lastans',
            'filter_condition_callback' => array($this, '_filterLastans'),
                ]
        );
         
        $statusArray = $objectManager->create("Emipro\Rma\Model\Status")->getCollection()->addFieldToFilter("is_active", 1);
        $statuss = array();
        foreach ($statusArray as $newstatus) {
            $statuss[$newstatus->getId()] = $newstatus->getTitle();
        }
        $this->addColumn(
                'status', [
            'header' => __('Status'),
            'index' => 'status',
            'type' => 'options',
            'options' => $statuss
                ]
        );
       
        $this->addColumn(
                'date', [
            'header' => __('Created At'),
            'index' => 'date',
            'type' => 'datetime',
                ]
        );
        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }
        return parent::_prepareColumns();
    }

    protected function _filterHasUrlConditionCallback($collection, $column) {

        if (!$order = $column->getFilter()->getValue()) {
            return $this;
        }

        $this->getCollection()->getSelect()->where(
                "order_id like ?"
                , "%$order%");
        return $this;
    }
    protected function _filterLastans($collection, $column) {

        if (!$value = $column->getFilter()->getValue()) {
            return $this;
        }
         $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $pro = $objectManager->create("Emipro\Rma\Model\Conversation")->getCollection();
        $pro->addFieldToFilter('user_details', array('like' => '%' . $value . '%'));
        $pro->getSelect()->order("conversation_id DESC");
        $ids = [];
        $ids=$pro->getFirstItem()->getRmaId();
        $this->getCollection()->addFieldToFilter('rma_id', ['in' => $ids]);
        return $this;
    }

     protected function _filterCustomer($collection, $column) {
        if (!$cstName = $column->getFilter()->getValue()) {
            return $this;
        }

        $this->getCollection()->getSelect()->where(
                "customer_name like ?"
                , "%$cstName%");
        return $this;
    }

    protected function _filterHasUrlCallback($collection, $column) {
        if (!$value = $column->getFilter()->getValue()) {
            return $this;
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $pro = $objectManager->create("Magento\Catalog\Model\Product")->getCollection();
        $pro->addFieldToFilter('name', array('like' => '%' . $value . '%'));
        $ids = array();
        foreach ($pro as $item) {
            $ids[] = $item->getId();
        }
        $this->getCollection()->addFieldToFilter('product_id', array('in' => $ids));
        return $this;
    }

    public function getGridUrl() {
        return $this->getUrl('rma/rma/gridrma', ['_current' => true]);
    }

    public function getRowUrl($row) {
        return $this->getUrl(
                        'rma/rma/editrma', ['id' => $row->getId()]
        );
    }

}
