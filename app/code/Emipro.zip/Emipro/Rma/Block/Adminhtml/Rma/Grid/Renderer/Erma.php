<?php

namespace Emipro\Rma\Block\Adminhtml\Rma\Grid\Renderer;

class Erma extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer {

    public function __construct(\Magento\Backend\Block\Context $context, array $data = []) {
        parent::__construct($context, $data);
        $this->_authorization = $context->getAuthorization();
    }

    public function render(\Magento\Framework\DataObject $row) {
        $r_id = $this->_getValue($row);
        return '<a href="' . $this->_urlBuilder->getUrl("rma/rma/editrma", array("id" => $r_id)) . '" target="_blank">' . $r_id . '</a>';
    }

}
