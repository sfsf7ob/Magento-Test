<?php

namespace Emipro\Rma\Block\Adminhtml\Rmarequestcreate;

class Edit extends \Magento\Backend\Block\Widget\Form\Container {

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context
    ) {

        parent::__construct($context);
    }

    protected function _construct() {
        $this->_objectId = 'id';
        $this->_blockGroup = 'emipro_rma';
        $this->_controller = 'adminhtml_rmarequestcreate';

        parent::_construct();
        $this->buttonList->update('save', 'label', __('Submit'));
        $this->buttonList->remove('delete');
        $this->buttonList->remove('reset');
    }

    protected function _prepareLayout() {
        $this->_formScripts[] = "
            function getAttr(obj,val)
            {
                if(obj > val)
                {
                    alert('Please enter quantity less than or equal to remaining quantity');
                    document.getElementById('qty').value=1;
                }
            }
            ";
        return parent::_prepareLayout();
    }

}
