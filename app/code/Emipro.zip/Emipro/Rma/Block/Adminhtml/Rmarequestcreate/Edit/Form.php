<?php

namespace Emipro\Rma\Block\Adminhtml\Rmarequestcreate\Edit;

use Magento\Backend\Block\Widget\Form\Generic;
use Emipro\Rma\Helper\Data;
use Magento\Framework\Registry;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Data\FormFactory;

class Form extends Generic {

    protected $helper;
    protected $_coreRegistry;

    public function __construct(
    Context $context, Registry $registry, FormFactory $formFactory, Data $helper, array $data = []
    ) {

        $this->helper = $helper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    protected function _prepareForm() {

        $data = (array) $this->getRequest()->getPost();
        $form = $this->_formFactory->create(
                [
                    'data' => [
                        'id' => 'edit_form',
                        'action' => $this->getUrl('*/*/newrmacreaterequest'),
                        'method' => 'post',
                        'enctype' => 'multipart/form-data'
                    ]
                ]
        );

        $fieldset = $form->addFieldset(
                'base_fieldset', ['legend' => __('Create New RMA Request')]
        );
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product2 = $objectManager->get('Magento\Catalog\Model\ProductFactory');
        $product = $product2->create();
        $product->load($this->helper->getProductId($data["product_id"]));
        $objectManager->create('Magento\Catalog\Helper\Product')->getImageUrl($product);
        $proimg = $objectManager->create('Magento\Catalog\Helper\Image')->init($product, 'cart_page_product_thumbnail')->constrainOnly(true)->keepAspectRatio(true)->keepFrame(false)->setImageFile($product->getImage())->getUrl();

        $fieldset->addField('file1', 'label', array(
            'label' => __('Image'),
            'name' => "file1",
        ))->setAfterElementHtml('<div style="height:auto;width:163px"><img src=' . $proimg . ' alt="proimg"></div>');

        $fieldset->addField('order_id', 'hidden', array(
            'label' => __('Order Id'),
            'name' => 'order_id',
            'value' => $this->helper->getOrderId($data["order_entity_Id"]),
        ));
        $fieldset->addField('order_no', 'label', array(
            'label' => __('Order No.'),
            'name' => 'order_no',
            'value' => $this->helper->getOrderId($data["order_entity_Id"]),
        ));
        $fieldset->addField('product_id', 'hidden', array(
            'label' => __('Product Id'),
            'name' => 'product_id',
            'value' => $this->helper->getProductId($data["product_id"]),
        ));

        $fieldset->addField('customer_id', 'hidden', array(
            'label' => __('Customer Id'),
            'name' => 'customer_id',
            'value' => $this->helper->getCustomerId($data["order_entity_Id"]),
        ));
        $fieldset->addField('remaining_qty', 'label', array(
            'label' => __('Remaining Qty'),
            'name' => 'remaining_qty',
            'value' => $this->helper->getTotalQuantity($data["product_id"], $data["order_entity_Id"]),
        ));
        $fieldset->addField('qty', 'text', array(
            'label' => __('Qty'),
            'name' => 'qty',
            'required' => true,
            'class' => 'validate-number validate-greater-than-zero',
            'onchange' => "getAttr(this.value," . $this->helper->getTotalQuantity($data['product_id'], $data['order_entity_Id']) . ");",
        ));
        $fieldset->addField('status', 'select', array(
            'label' => __('Select Status'),
            'required' => true,
            'name' => 'status',
            'values' => $this->helper->getStatus(),
        ));
        $fieldset->addField('reason', 'select', array(
            'label' => __('Select Reason'),
            'required' => true,
            'name' => 'reason',
            'values' => $this->helper->getReason(),
        ));

        $fieldset->addField('return', 'select', array(
            'label' => __('Select Return Type'),
            'required' => true,
            'name' => 'return',
            'values' => $this->helper->getReturn(),
        ));

        $fieldset->addField('package', 'select', array(
            'label' => __('Select Package Condition'),
            'required' => true,
            'name' => 'package',
            'values' => $this->helper->getPackage(),
        ));

        $fieldset->addField('message', 'textarea', array(
            'label' => __('Message'),
            'name' => "message",
            'required' => true,
        ));

        $fieldset->addField('file', 'file', array(
            'label' => __('Attachment'),
            'name' => "file",
        ));

        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }

}
