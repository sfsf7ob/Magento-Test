<?php

namespace Emipro\Rma\Block\Adminhtml\Status;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended {

    protected $_projectsFactory;
    protected $moduleManager;

    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Framework\Module\Manager $moduleManager, \Magento\Backend\Helper\Data $backendHelper, \Emipro\Rma\Model\StatusFactory $statusFactory
    ) {
        $this->moduleManager = $moduleManager;
        $this->_statusFactory = $statusFactory;
        parent::__construct($context, $backendHelper);
    }

    protected function _construct() {
        parent::_construct();
        $this->setId('PageGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
        $this->setVarNameFilter('id');
    }

    protected function _prepareCollection() {
        $collection = $this->_statusFactory->create()->getCollection()->addFieldToFilter('status_id',['neq' => 6]);
        $this->setCollection($collection);
        parent::_prepareCollection();
        return $this;
    }

    protected function _prepareColumns() {
        $this->addColumn('status_id', array(
            'header' => __('ID'),
            'align' => 'left',
            'index' => 'status_id',
            'sortable' => true,
        ));
        $this->addColumn('title', array(
            'header' => __('Title'),
            'align' => 'left',
            'index' => 'title'
        ));

        $this->addColumn('sort_order', array(
            'header' => __('Sort Order'),
            'align' => 'left',
            'index' => 'sort_order'
        ));

        $status[1] = "Yes";
        $status[0] = "No";
        $this->addColumn('is_active', array(
            'header' => __('Active'),
            'align' => 'left',
            'index' => 'is_active',
            'type' => 'options',
            'options' => $status,
        ));

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }
        return parent::_prepareColumns();
    }

    protected function _filterHasUrlConditionCallback($collection, $column) {
        if (!$customer = $column->getFilter()->getValue()) {
            return $this;
        }

        $this->getCollection()->getSelect()->where(
                "customer_id like ?"
                , "%$customer%");
        return $this;
    }

    public function getGridUrl() {
        return $this->getUrl('rma/rma/gridstatus', ['_current' => true]);
    }

    public function getRowUrl($row) {
        return $this->getUrl(
                        'rma/rma/editstatus', ['id' => $row->getId()]
        );
    }

    protected function _prepareMassaction() {
        $this->setMassactionIdField('id');
        $this->getMassactionBlock()->setFormFieldName('id');

        $this->getMassactionBlock()->addItem(
                'Active', [
            'label' => __('Active'),
            'url' => $this->getUrl('rma/rma/massActivestatus'),
                ]
        );
        $this->getMassactionBlock()->addItem(
                'Inactive', [
            'label' => __('Inactive'),
            'url' => $this->getUrl('rma/rma/massInactivestatus'),
                ]
        );


        return $this;
    }

}
