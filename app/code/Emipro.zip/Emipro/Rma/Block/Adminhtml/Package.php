<?php

namespace Emipro\Rma\Block\Adminhtml;

use Magento\Backend\Block\Widget\Container;

class Package extends Container {

    protected $_template = 'grid/view.phtml';

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context
    ) {
        parent::__construct($context);
    }

    protected function _prepareLayout() {
        $addButtonProps = [
            'id' => 'gridpackage',
            'label' => __('Add New Package Condition'),
            'class' => 'add',
            'button_class' => '',
            'onclick' => "setLocation('" . $this->_getCreateUrl() . "')",
            'style' => "background-color: #eb5202;border-color: #eb5202;color: #fff;"
        ];
        $this->buttonList->add('add_new', $addButtonProps);
        $this->setChild(
                'grid', $this->getLayout()->createBlock('Emipro\Rma\Block\Adminhtml\Package\Grid', 'rma.package.view.grid')
        );
        return parent::_prepareLayout();
    }

    protected function _getCreateUrl() {
        return $this->getUrl(
                        'rma/rma/newpackage'
        );
    }

    public function getGridHtml() {
        return $this->getChildHtml('grid');
    }

}
