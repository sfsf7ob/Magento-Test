<?php

namespace Emipro\Rma\Block\Adminhtml;

use Magento\Backend\Block\Widget\Container;

class Status extends Container {

    protected $_template = 'grid/view.phtml';

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context
    ) {
        parent::__construct($context);
    }

    protected function _prepareLayout() {
        $addButtonProps = [
            'id' => 'gridstatus',
            'label' => __('Add New Status'),
            'class' => 'add',
            'button_class' => '',
            'onclick' => "setLocation('" . $this->_getCreateUrl() . "')",
            'style' => "background-color: #eb5202;border-color: #eb5202;color: #fff;"
        ];
        $this->buttonList->add('add_new', $addButtonProps);
        $this->setChild(
                'grid', $this->getLayout()->createBlock('Emipro\Rma\Block\Adminhtml\Status\Grid', 'rma.status.view.grid')
        );
        return parent::_prepareLayout();
    }

    protected function _getCreateUrl() {
        return $this->getUrl(
                        'rma/rma/newstatus'
        );
    }

    public function getGridHtml() {
        return $this->getChildHtml('grid');
    }

}
