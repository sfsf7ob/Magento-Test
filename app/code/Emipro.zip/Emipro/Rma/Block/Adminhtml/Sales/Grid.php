<?php

namespace Emipro\Rma\Block\Adminhtml\Sales;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended {

    protected $_projectsFactory;
    protected $moduleManager;
    protected $_storeManager;
    public function __construct(
    \Magento\Backend\Block\Template\Context $context,
    \Magento\Store\Model\StoreManagerInterface $storeManager, 
    \Magento\Framework\Module\Manager $moduleManager, \Magento\Backend\Helper\Data $backendHelper, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->moduleManager = $moduleManager;
         $this->_storeManager=$storeManager;
        parent::__construct($context, $backendHelper);
    }

    protected function _construct() {
        parent::_construct();
        $this->setId('sales_order_grid');
        $this->setDefaultSort('created_at');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
        $this->setVarNameFilter('id');
    }

    protected function _prepareCollection() {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $order_status = $this->scopeConfig->getValue('rma/rma_newgroup/rma_orderstatus', $storeScope);
        $order_days = $this->scopeConfig->getValue('rma/rma_newgroup/rma_days', $storeScope);
        $order_new = explode(",", $order_status);
        $time = time();
        $to = date('Y-m-d H:i:s', $time) . "<br>";
        $lastTime = $time - (86400 * $order_days);
        $from = date('Y-m-d H:i:s', $lastTime);

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $collection = $objectManager->create("Magento\Sales\Model\ResourceModel\Order\Grid\Collection");
        $collection->addFieldToFilter('status', array('in' => $order_new))
                 ->addFieldToFilter('created_at', array('from' => $from, 'to' => $to));

        $this->setCollection($collection);
        parent::_prepareCollection();
        return $this;
    }

    protected function _prepareColumns() {
        $this->addColumn(
                'increment_id', [
            'header' => __('Order ID #'),
            'type' => 'text',
            'index' => 'increment_id',
                ]
        );

        if (!$this->_storeManager->isSingleStoreMode())
        {
            $this->addColumn(
                    'store_id', [
                'header' => __('Purchased From (Store)'),
                'index' => 'store_id',
                'type' => 'store',
                'store_view' => true,
                'display_deleted' => true,
                    ]
            );
         }
        $this->addColumn(
                'created_at', [
            'header' => __('Created Date'),
            'index' => 'created_at',
            'type' => 'datetime',
                ]
        );
        $this->addColumn(
                'billing_name', [
            'header' => __('Bill to name'),
            'type' => 'text',
            'index' => 'billing_name',
                ]
        );
        $this->addColumn(
                'shipping_name', [
            'header' => __('Ship to Name'),
            'type' => 'text',
            'index' => 'shipping_name',           
                ]
        );

        $this->addColumn(
                'base_grand_total', [
            'header' => __('G.T. (Base)'),
            'index' => 'base_grand_total',
            'type' => 'currency',
            'currency' => 'base_currency_code',
                ]
        );
        $this->addColumn(
                'grand_total', [
            'header' => __('G.T. (Purchased)'),
            'index' => 'grand_total',
            'type' => 'currency',
            'currency' => 'order_currency_code',
                ]
        );
        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }
        return parent::_prepareColumns();
    }

    public function getGridUrl() {
        return $this->getUrl('rma/rma/gridsales', ['_current' => true]);
    }

    public function getRowUrl($row) {
        return $this->getUrl(
                        'rma/rma/product', ['order_id' => $row->getId()]
        );
    }

}
