<?php

namespace Emipro\Rma\Block\Adminhtml\Product\Edit;

use Magento\Backend\Block\Widget\Form\Generic;
use Emipro\Rma\Helper\Data;
use Magento\Framework\Registry;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Data\FormFactory;

class Form extends Generic {

    protected $helper;
    protected $_coreRegistry;

    public function __construct(
    Context $context, Registry $registry, FormFactory $formFactory, Data $helper, array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    protected function _prepareForm() {

        $orderId = $this->getRequest()->getParam('order_id');

        $form = $this->_formFactory->create(
                [
                    'data' => [
                        'id' => 'edit_form',
                        'action' => $this->getUrl('*/*/rmarequestcreate'),
                        'method' => 'post',
                        'enctype' => 'multipart/form-data'
                    ]
                ]
        );

        $fieldset = $form->addFieldset(
                'base_fieldset', ['legend' => __('Create New RMA Request')]
        );

        $fieldset->addField('order_entity_Id', 'hidden', [
            'label' => __('Order Id'),
            'name' => 'order_entity_Id',
            'value' => $orderId,
                ]
        );

        $fieldset->addField('product_id', 'select', array(
            'label' => __('Product'),
            'required' => true,
            'name' => 'product_id',
            'values' => $this->helper->getProductList($orderId),
        ));


        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }

}
