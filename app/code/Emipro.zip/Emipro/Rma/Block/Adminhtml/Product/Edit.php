<?php

namespace Emipro\Rma\Block\Adminhtml\Product;

class Edit extends \Magento\Backend\Block\Widget\Form\Container {

    public function __construct(
    \Magento\Backend\Block\Widget\Context $context
    ) {

        parent::__construct($context);
    }

    protected function _construct() {
        $this->_objectId = 'id';
        $this->_blockGroup = 'emipro_rma';
        $this->_controller = 'adminhtml_product';
        parent::_construct();
        $this->buttonList->update('save', 'label', __('Next'));
        $this->buttonList->remove('delete');
        $this->buttonList->remove('reset');
    }

    protected function _prepareLayout() {
        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('page_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'content');
                }
            };
        ";
        return parent::_prepareLayout();
    }

}
