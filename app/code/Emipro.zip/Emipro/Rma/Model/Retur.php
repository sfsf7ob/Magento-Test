<?php 
namespace Emipro\Rma\Model;
use Magento\Framework\Model\AbstractModel;
class Retur extends AbstractModel
{
    protected function _construct()
    {
        $this->_init('Emipro\Rma\Model\ResourceModel\Retur');
    }

}
