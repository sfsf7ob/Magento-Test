<?php 
namespace Emipro\Rma\Model;
use Magento\Framework\Model\AbstractModel;

class Conversation extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('Emipro\Rma\Model\ResourceModel\Conversation');
    }

}
