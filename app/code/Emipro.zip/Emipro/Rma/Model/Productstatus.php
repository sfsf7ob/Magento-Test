<?php
namespace Emipro\Rma\Model;
 
class Productstatus implements \Magento\Framework\Option\ArrayInterface
{
  public function toOptionArray()
  {
	   $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
	   $reason=$objectManager->get('Emipro\Rma\Model\ResourceModel\Status\Collection')
	   ->addFieldToFilter("is_active",1);
	   $reason->setOrder('sort_order', 'ASC');
	   foreach($reason as $newreason){
					$attributeArray[] = array(
						'label' => $newreason->getTitle(),
						'value' => $newreason->getTitle()
					);
			} 
			return $attributeArray; 
  }
}

