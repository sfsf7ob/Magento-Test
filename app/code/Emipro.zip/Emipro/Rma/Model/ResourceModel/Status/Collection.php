<?php 

namespace Emipro\Rma\Model\ResourceModel\Status;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init('Emipro\Rma\Model\Status', 'Emipro\Rma\Model\ResourceModel\Status');
    }

}

