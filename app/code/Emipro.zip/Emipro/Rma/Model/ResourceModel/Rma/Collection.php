<?php 

namespace Emipro\Rma\Model\ResourceModel\Rma;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    
    protected function _construct()
    {
        $this->_init('Emipro\Rma\Model\Rma', 'Emipro\Rma\Model\ResourceModel\Rma');
    }

}

