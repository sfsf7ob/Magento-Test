<?php
namespace Emipro\Rma\Model\System\Config\Source;

class Adminuser implements \Magento\Framework\Option\ArrayInterface
{
	public function toOptionArray()
    {
		$user=array();
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$admin_user =$objectManager->get('Magento\User\Model\User')->getCollection()->getData();
		foreach($admin_user as $value)
		{
			$user[]=array('value' => $value["user_id"], 'label'=>__($value["firstname"]." ".$value["lastname"]));
		}	
		 return $user;
    }

   
}
