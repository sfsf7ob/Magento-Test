<?php
namespace Emipro\Rma\Model;

class Orderstatus implements \Magento\Framework\Option\ArrayInterface
{
  public function toOptionArray()
  {
	   $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
	   $status=$objectManager->get('Magento\Sales\Model\Order\Status')->getResourceCollection();
	    foreach($status as $newstatus){
					$attributeArray[] = array(
						'value' => $newstatus->getStatus(),
						'label' => $newstatus->getLabel()
					);
			} 
			return $attributeArray; 
  }
}

