<?php

namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\RedirectFactory;
class Rmarequestcreate extends \Magento\Backend\App\Action {

    protected $resultPageFactory;
    protected $_resultRedirectFactory;
    public function __construct(
    Context $context, PageFactory $resultPageFactory ,RedirectFactory $resultRedirectFactory
    ) {
        parent::__construct($context);
        $this->_resultRedirectFactory = $resultRedirectFactory;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute() {
        $resultPage = $this->resultPageFactory->create();
        $resultRedirect = $this->_resultRedirectFactory->create();
        $postData = $this->getRequest()->getPost();
        $proqty=explode(':',$postData['product_id']);
        $pro = $proqty[0];
        $qty = $proqty[1];
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $data = $objectManager->get('Magento\Sales\Model\Order')->load($postData['order_entity_Id'])->getData();
        $productdata = $objectManager->get("Magento\Catalog\Model\Product")->load($pro);
        $orderId = $data["increment_id"];
        $customerId = $data["customer_id"];
        $model = $objectManager->get('Emipro\Rma\Model\Rma')->getCollection()
            ->addFieldToFilter('product_id', $pro)
            ->addFieldToFilter('customer_id', $customerId)
            ->addFieldToFilter('order_id', $orderId);
        $total_qty = 0;
        foreach ($model as $newmodel) 
        {
            $total_qty+=$newmodel->getQty();
        }
        if($total_qty >= $qty)
        { 
         $this->messageManager->addError(__('You have already requested for this product.'));
            $resultRedirect->setPath('rma/rma/product', ['order_id' => $postData['order_entity_Id']]);
            return $resultRedirect;
        }
        $resultPage->getConfig()->getTitle()->prepend(__('Create New RMA Request'));
        return $resultPage;
    }

}
