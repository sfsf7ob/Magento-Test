<?php

namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Framework\Filesystem;
use Emipro\Rma\Model\RmaFactory;
use Emipro\Rma\Model\AttachmentFactory;

class Checkattachmentlink extends Action {

    protected $_rma;
    protected $_attachment;
    protected $session;
    protected $_filesystem;

    public function __construct(
    Context $context, RmaFactory $rmaFactory, Session $session, Filesystem $filesystem, AttachmentFactory $attachmentFactory
    ) {
        $this->_rma = $rmaFactory;
        $this->_attachment = $attachmentFactory;
        $this->_filesystem = $filesystem;
        $this->session = $session;
        parent::__construct($context);
    }

    public function execute() {
        $ticketId = $this->getRequest()->getParam('rma_id');
        $conversationId = $this->getRequest()->getParam('conversation_id');
        $attachmentId = $this->getRequest()->getParam('attachment_id');
        $object_manager = \Magento\Framework\App\ObjectManager::getInstance();
        $UserId = $object_manager->get('\Magento\Backend\Model\Auth\Session')->getUser()->getUserId();
        if ($UserId) {
            try {
                $attachment = $this->_attachment->create()->getCollection();
                $attachment->addFieldToFilter("conversation_id", $conversationId)
                        ->addFieldToFilter("attachment_id", $attachmentId);
                $attachmentData = $attachment->getFirstItem();
                $file = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                                ->getAbsolutePath("rma/attachment/") . $attachmentData->getFile();
                if (file_exists($file)) {
                    $resourceType = \Magento\Downloadable\Helper\Download::LINK_TYPE_FILE;
                    $helper = $this->_objectManager->create('\Magento\Downloadable\Helper\Download');
                    $helper->setResource('rma/attachment/' . $attachmentData->getFile());
                    $contentType = $helper->getContentType();


                    header('Cache-Control: public');
                    header('Content-Description: File Transfer');
                    header("Content-Disposition: attachment; filename={$attachmentData->getCurrentFileName()}");
                    header("Content-Type:{$contentType}");
                    header('Content-Transfer-Encoding: binary');
                    readfile($file);
                } else {
                    $this->messageManager->addError(__('Sorry, File not exists.'));
                    return $this->resultRedirectFactory->create()->setPath('rma/rma/index');
                }
            } catch (Exception $e) {
                $this->messageManager->addError(__('You don\'t have permission to access this file.'));
                return $this->resultRedirectFactory->create()->setPath('rma/rma/index');
            }
        }
    }

}
