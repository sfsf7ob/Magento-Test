<?php

namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;
use Magento\Framework\App\TemplateTypesInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Backend\App\Action\Context;

class Save extends \Magento\Backend\App\Action {

    protected $_resultRedirectFactory;
    protected $scopeConfig;
    protected $helper;

    public function __construct(Context $context, RedirectFactory $resultRedirectFactory, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Emipro\Rma\Helper\Data $helper
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_resultRedirectFactory = $resultRedirectFactory;
        $this->helper = $helper;
        parent::__construct($context);
    }

    public function execute() {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resultRedirect = $this->_resultRedirectFactory->create();
        $data = (array) $this->getRequest()->getPost();
        $maxfile_size = 1024 * 1024 * 4;
        if ($this->getRequest()->getPost()) {

            try {
                $data = (array) $this->getRequest()->getPost();
                $rmId = $data["rma_id"];

                if ($data["message"] == "") {
                    $this->messageManager->addError(__('Please enter message.'));
                    $resultRedirect->setPath('rma/rma/editrma', ['id' => $data["rma_id"], '_current' => true]);
                    return $resultRedirect;
                }

                if ($_FILES['file']['size'] > $maxfile_size) {
                    $this->_getSession()->setTicketmessage($data["message"]);
                    $this->messageManager->addError(__('Message attachment was not uploaded. Please,try again later.'));
                    $resultRedirect->setPath('rma/rma/editrma', ['id' => $data["rma_id"], '_current' => true]);
                    return $resultRedirect;
                }
                $msg = strip_tags($data["message"]);
                 $message_new = nl2br($msg);
                $model = $objectManager->create("Emipro\Rma\Model\Conversation");

                if (($data["message"] != "")) {
                    $model->setData("message", $message_new);
                    $model->setData("rma_id", $data["rma_id"]);
                    $model->setData("name", $data["name"]);
                    $model->setData("con_id", $data["admin_id"]);
                    $model->setData("user_details", 'Support');
                    $model->setData("date", $data["date"]);
                    $model->setData("status_id", $data["status_id"]);
                    $model->save();
                    $con_id = $model->save()->getId();
                    $status = $objectManager->create("Emipro\Rma\Model\Status")->load($data["status_id"]);
                    $status_id["status"] = $status->getTitle();
                    $new_status["status"] = $data["status_id"];
                    $dataa = $objectManager->create("Emipro\Rma\Model\Rma");
                    $dataa->setId($data["rma_id"]);
                    $dataa->addData($new_status);
                    $dataa->save();
                }

                $moduleInfo = $objectManager->get('Magento\Framework\Module\ModuleList')->getOne('Emipro_Creditpoints');
                 if(isset($moduleInfo['name']))
                  {  
                    if($data['order_id'])
                    {
                       $orderRepository = $objectManager->create('Magento\Sales\Api\OrderRepositoryInterface');
                        $order = $orderRepository->get($data['order_id']);
                        $orderIncrementId = $order->getIncrementId();
                    }
                    if($data['credit_points'] > 0 && isset($moduleInfo['name']) && $data["status_id"]==2 && $data["return_id"]==3)
                    {
                         $logger = $objectManager->create('Psr\Log\LoggerInterface');
                        $credit=$objectManager->create("Emipro\Creditpoints\Model\Transactions");
                        $date=date("Y-m-d H:i:s");
                        $tra = array();
                        $tra["order_id"]=$orderIncrementId;
                        $tra["customer_id"]=$data['customer_id'];
                        $tra["points_spent"]=0;
                        $tra["name"]=$data['customer_name'];
                        $tra["date"]=$date;
                         $tra["comment"]="RMA Id: ".$data["rma_id"];
                         $tra["reason"]="Store Credit For Return Product";
                         $tra["points_get"]=$data['credit_points'];
                         if($data['credit_points'] > 0)
                         {   
                             $credit->setData($tra);
                             $credit->save();
                         }
                         $amount=$data['credit_points'];
                         $resource = $objectManager->create("Magento\Framework\App\ResourceConnection");
                         $connection = $resource->getConnection();
                         $table = $resource->getTableName('customer_entity'); 
                       $query = "Update " . $table . " Set points = points+".$amount." where entity_id = ".(int)$data['customer_id'];
                          $connection->query($query);  
                    }
                }

                if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
                    $fileName = $_FILES['file']['name'];
                    $ext = pathinfo($fileName, PATHINFO_EXTENSION);
                    $new_fileName = md5(uniqid(rand(), true)) . "." . $ext;
                    $isSave = $this->helper->saveAttachment('file', $new_fileName, 'rma/attachment');
                    $file = $objectManager->create("Emipro\Rma\Model\Attachment");
                    $file->setData("conversation_id", $con_id);
                    $file->setData("file", $new_fileName);
                    $file->setData("current_file_name", $fileName);
                    $file->save();
                    $file_id = $file->save()->getId();
                }

                // ticket conversation mail send to customer.
                $customer = $objectManager->get("Magento\Customer\Model\Customer")->load($data["customer_id"]);
                $customer_email = $customer->getEmail();
                $customer_name = $customer->getFirstname();

                $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
                $ticket_email = $this->scopeConfig->getValue('rma/emipro_group/ticket_email', $storeScope);

                $ticket_template = $this->scopeConfig->getValue('rma/ticket/conversation', $storeScope);

                $sender_email = $this->scopeConfig->getValue('trans_email/ident_' . $ticket_email . '/email', $storeScope);

                $ticket_admin_name = $this->scopeConfig->getValue('trans_email/ident_' . $ticket_email . '/name', $storeScope);
                    $message_new = strip_tags($message_new, '<br>');
                $emailTemplateVariables = array();
                $emailTemplateVariables['customer_name'] = $customer_name;
                $emailTemplateVariables['message'] = $message_new;
                $emailTemplateVariables['rma_id'] = $data["rma_id"];
                $emailTemplateVariables['sender_name'] = $ticket_admin_name;
                $emailTemplateVariables['rma_status'] = $status_id["status"];
                $sender_name = $this->scopeConfig->getValue('trans_email/ident_' . $ticket_email . '/name', $storeScope);
                $emailTemplateVariables['tempsubject'] = "Reply for RMA request" . $data["rma_id"];

                $filesystem = $objectManager->create('Magento\Framework\Filesystem');
                $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface');
                $currentStore = $storeManager->getStore();
                $path = $filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                        ->getAbsolutePath('rma/attachment');

                $attachment = $objectManager->get('Emipro\Rma\Controller\Customer\UploadTransportBuilder');
                if(isset($new_fileName))
                {
                $transport = $attachment->setTemplateIdentifier($ticket_template)
                        ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                            'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                        ])
                        ->setTemplateVars($emailTemplateVariables)
                        ->setFrom(array("name" => $sender_name, 'email' => $sender_email))
                        ->addTo($customer_email)
                        ->setReplyTo($sender_email)
                        ->attachFile($path . "/" . $new_fileName, $new_fileName)
                        ->getTransport();
                $transport->sendMessage();
            }
            else{
                  $transport = $attachment->setTemplateIdentifier($ticket_template)
                        ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                            'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                        ])
                        ->setTemplateVars($emailTemplateVariables)
                        ->setFrom(array("name" => $sender_name, 'email' => $sender_email))
                        ->addTo($customer_email)
                        ->setReplyTo($sender_email)                    
                        ->getTransport();
                $transport->sendMessage();

            }

                if ($this->getRequest()->getParam("testmag") == 'back') {
                    $this->messageManager->addSuccess(__('RMA Request has been updated successfully.'));
                    return $resultRedirect->setPath('rma/rma/editrma', ['id' => $data["rma_id"], '_current' => true]);
                }

                $this->messageManager->addSuccess(__('RMA information was successfully saved.'));
                return $resultRedirect->setPath('*/*/', ['id' => $data["rma_id"], '_current' => true]);
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the post.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('rma/rma/editrma', ['rma_id' => $this->getRequest()->getParam('rma_id')]);
        }
        return $resultRedirect->setPath('rma/rma/editrma');
    }

}
