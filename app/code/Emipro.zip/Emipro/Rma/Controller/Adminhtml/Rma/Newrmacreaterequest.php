<?php

namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;
use Magento\Framework\App\TemplateTypesInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Backend\App\Action\Context;

class Newrmacreaterequest extends \Magento\Backend\App\Action {

    protected $_resultRedirectFactory;
    protected $scopeConfig;
    protected $helper;

    public function __construct(Context $context, RedirectFactory $resultRedirectFactory, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Emipro\Rma\Helper\Data $helper
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_resultRedirectFactory = $resultRedirectFactory;
        $this->helper = $helper;
        parent::__construct($context);
    }

    public function execute() {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $resultRedirect = $this->_resultRedirectFactory->create();
        $data = (array) $this->getRequest()->getPost();
        $maxfile_size = 1024 * 1024 * 4;

        $customer_name = $this->helper->getCustomerName($data["customer_id"]);
        $currentDate = $objectManager->get("Magento\Framework\Stdlib\DateTime\DateTime")->date('Y-m-d H:i');
        $data["customer_name"] = $customer_name;
        $data["date"] = $currentDate;
        $admin = $objectManager->create("Magento\Backend\Model\Auth\Session")->getUser();
        $admin_name = $admin->getFirstName() . " " . $admin->getLastName();

        if ($_FILES['file']['size'] > $maxfile_size) {

            $this->messageManager->addError(__('RMA attachment was not uploaded. Please,try again later.'));
            $resultRedirect->setPath('*/*/');
            return $resultRedirect;
        }

        if ($this->getRequest()->getPost()) {

            try {
                $rma = $objectManager->create("Emipro\Rma\Model\Rma");
                $rma->setData($data);
                $rma->save();
                $rma_id = $rma->save()->getId();

                $msg = strip_tags($data["message"]);
                $message_new = nl2br($msg);
                $message_new = htmlentities($message_new);
                $dataa = $objectManager->create("Emipro\Rma\Model\Rma")->load($rma_id);
                $status_id = $dataa->getStatus();

                $model = $objectManager->create("Emipro\Rma\Model\Conversation");
                $model->setData("rma_id", $rma_id);
                $model->setData("message", $message_new);
                $model->setData("name", $admin_name);
                $model->setData("status_id", $status_id);
                $model->setData("date", $data["date"]);
                $model->save();
                $conversation_id = $model->save()->getId();
                if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
                    $fileName = $_FILES['file']['name'];
                    $ext = pathinfo($fileName, PATHINFO_EXTENSION);
                    $new_fileName = md5(uniqid(rand(), true)) . "." . $ext;
                    $isSave = $this->helper->saveAttachment('file', $new_fileName, 'rma/attachment');
                    $file = $objectManager->create("Emipro\Rma\Model\Attachment");
                    $file->setData("conversation_id", $conversation_id);
                    $file->setData("file", $new_fileName);
                    $file->setData("current_file_name", $fileName);
                    $file->save();
                    $file_id = $file->save()->getId();
                }
                // ticket conversation mail send to customer.
                echo "test1";
                $customer = $objectManager->get("Magento\Customer\Model\Customer")->load($data["customer_id"]);
                $customer_email = $customer->getEmail();
                $customer_name = $customer->getFirstname();
                echo "test2";
                $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

                $admin_user_id = $this->scopeConfig->getValue('rma/emipro_group/ticket_admin', $storeScope);
                $assign_admin_email = $objectManager->get('Magento\User\Model\User')->load($admin_user_id)->getEmail();

                $ticket_email = $this->scopeConfig->getValue('rma/emipro_group/ticket_email', $storeScope);

                $ticket_admin_name = $this->scopeConfig->getValue('trans_email/ident_' . $ticket_email . '/name', $storeScope);

                $ticket_email = $this->scopeConfig->getValue('rma/emipro_group/ticket_email', $storeScope);

                 $template=$this->scopeConfig->getValue('rma/ticket/customer',$storeScope); 

                $sender_email = $this->scopeConfig->getValue('trans_email/ident_' . $ticket_email . '/email', $storeScope);

                $ticket_admin_name = $this->scopeConfig->getValue('trans_email/ident_' . $ticket_email . '/name', $storeScope);

                $emailTemplateVariables = array();
                $emailTemplateVariables['customer_name'] = $customer_name;
                $emailTemplateVariables['message'] = $message_new;
                $emailTemplateVariables['rma_id'] = $rma_id;
                $emailTemplateVariables['sender_name'] = $ticket_admin_name;
                $sender_name = $this->scopeConfig->getValue('trans_email/ident_' . $ticket_email . '/name', $storeScope);
                $emailTemplateVariables['tempsubject'] = "RMA request has been created with RMA Id " . $rma_id;

                $filesystem = $objectManager->create('Magento\Framework\Filesystem');
                $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface');
                $currentStore = $storeManager->getStore();
                $path = $filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                        ->getAbsolutePath('rma/attachment');

                $attachment = $objectManager->get('Emipro\Rma\Controller\Customer\UploadTransportBuilder');
                if(isset($new_fileName)){
                $transport = $attachment->setTemplateIdentifier($template)
                        ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                            'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                        ])
                        ->setTemplateVars($emailTemplateVariables)
                        ->setFrom(array("name" => $sender_name, 'email' => $sender_email))
                        ->addTo($customer_email)
                        ->setReplyTo($sender_email)
                        ->attachFile($path . "/" . $new_fileName, $new_fileName)
                        ->getTransport();
                $transport->sendMessage();
            }
            else
            {
                   $transport = $attachment->setTemplateIdentifier($template)
                        ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                            'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                        ])
                        ->setTemplateVars($emailTemplateVariables)
                        ->setFrom(array("name" => $sender_name, 'email' => $sender_email))
                        ->addTo($customer_email)
                        ->setReplyTo($sender_email)
                        ->getTransport();
                $transport->sendMessage();
            }
                $this->messageManager->addSuccess(__('RMA request has been created successfully with ticket Id ' . $rma_id));
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Unable to submit your request. Please, try again later.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('rma/rma/editrma', ['rma_id' => $this->getRequest()->getParam('rma_id')]);
        }
    }

}
