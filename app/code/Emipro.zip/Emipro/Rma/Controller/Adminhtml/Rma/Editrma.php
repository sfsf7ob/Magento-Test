<?php
namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;

class Editrma extends \Magento\Backend\App\Action {

    protected $resultPageFactory;
     protected $_coreRegistry = null;
    public function __construct(
    Context $context, PageFactory $resultPageFactory ,\Magento\Framework\Registry $registry
    ) {
        parent::__construct($context);
         $this->_coreRegistry = $registry;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute() {
        $id = $this->getRequest()->getParam('id');
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $model = $objectManager->create("Emipro\Rma\Model\Rma")->load($id);

         $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__('RMA Request Information #'.$id));

       if($model->getId() || $id = 0)
       {  
        $data = $objectManager->get('Magento\Backend\Model\Session')->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }
         $this->_coreRegistry->register('rma', $model);
        $resultPage->getConfig()->getTitle()->prepend(__('RMA Request Information #'.$id));
         return $resultPage;
       }
       else{

            $this->messageManager->addError(__("Request For RMA does not exist"));
             $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('rma/rma/index');
       }

       
    }

}
