<?php

namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\RedirectFactory;

class MassInactivepackage extends \Magento\Backend\App\Action {

    protected $resultPageFactory;
    protected $_resultRedirectFactory;

    public function __construct(
    Context $context, PageFactory $resultPageFactory, RedirectFactory $resultRedirectFactory
    ) {
        parent::__construct($context);
        $this->_resultRedirectFactory = $resultRedirectFactory;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute() {
        $resultRedirect = $this->_resultRedirectFactory->create();
        $entity_ids = (array) $this->getRequest()->getParam('id');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        if (!is_array($entity_ids)) {
            $this->messageManager->addError(__('Plase Select'));
        } else {
            try {
                $count= 0;
                foreach ($entity_ids as $entity_id) {
                    $faq = $objectManager->create("Emipro\Rma\Model\Package")->setId($entity_id)->setIsActive(0)->save();
                    $count++;
                }
               $this->messageManager->addSuccess(__('A total of %1 record(s) have been updated.', $count));
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the post.'));
            }
        }
        return $resultRedirect->setPath('rma/rma/managepackage');
    }

}
