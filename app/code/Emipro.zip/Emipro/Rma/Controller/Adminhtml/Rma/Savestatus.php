<?php

namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\RedirectFactory;

class Savestatus extends \Magento\Backend\App\Action {

    protected $resultPageFactory;
    protected $_resultRedirectFactory;

    public function __construct(
    Context $context, PageFactory $resultPageFactory, RedirectFactory $resultRedirectFactory
    ) {
        parent::__construct($context);
        $this->_resultRedirectFactory = $resultRedirectFactory;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute() {
        $resultRedirect = $this->_resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        if ($this->getRequest()->getPost()) {
            $data = (array) $this->getRequest()->getPost();
            $status = $objectManager->create("Emipro\Rma\Model\Status")->load($id);
        }

        if ($id != "" && $id > 0) {

            $model = $objectManager->create("Emipro\Rma\Model\Status")->load($id);
            $model->addData($data);
            $model->setId($id)->save();
            $this->messageManager->addSuccess(__('Status was successfully saved'));
            $resultRedirect->setPath('rma/rma/managestatus');
            return $resultRedirect;
        } else {
            $model = $objectManager->create("Emipro\Rma\Model\Status");
            $model->setData($data);
            $model->save();
            $this->messageManager->addSuccess(__('Status was successfully saved'));
            $resultRedirect->setPath('*/*/managestatus');
            return $resultRedirect;
        }
    }

}
