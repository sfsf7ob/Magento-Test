<?php

namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;

class Editreason extends \Magento\Backend\App\Action {

    protected $resultPageFactory;
    protected $_coreRegistry = null;

    public function __construct(
    Context $context, PageFactory $resultPageFactory, \Magento\Framework\Registry $registry
    ) {
        parent::__construct($context);
        $this->_coreRegistry = $registry;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute() {

        $id = $this->getRequest()->getParam('id');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $model = $objectManager->create("Emipro\Rma\Model\Reason")->load($id);
        $resultPage = $this->resultPageFactory->create();
        $data = $objectManager->get('Magento\Backend\Model\Session')->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }
        $this->_coreRegistry->register('reason', $model);
       if($id)
        {
            $resultPage->getConfig()->getTitle()->prepend(__('View/Edit RMA Reason'));
        }
        else
        {
            $resultPage->getConfig()->getTitle()->prepend(__('Add New RMA Reason'));
        }
        return $resultPage;
    }

}
