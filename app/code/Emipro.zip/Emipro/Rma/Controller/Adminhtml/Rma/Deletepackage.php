<?php

namespace Emipro\Rma\Controller\Adminhtml\Rma;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\RedirectFactory;

class Deletepackage extends \Magento\Backend\App\Action {

    protected $resultPageFactory;
    protected $_resultRedirectFactory;

    public function __construct(
    Context $context, PageFactory $resultPageFactory, RedirectFactory $resultRedirectFactory
    ) {
        parent::__construct($context);
        $this->_resultRedirectFactory = $resultRedirectFactory;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute() {
        $resultRedirect = $this->_resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $status_array = array(1, 2, 3);
        if (in_array($id, $status_array)) {
            $this->messageManager->addError(__('This package condition is sysetm generated you can\'t delete this. So please instead of delete it, just disable it.'));
            $resultRedirect->setPath('rma/rma/managepackage');
            return $resultRedirect;
        } else {
            $model = $objectManager->create("Emipro\Rma\Model\Package")->setId($id)->delete();
            $this->messageManager->addSuccess(__('Package condition was successfully deleted'));
            $resultRedirect->setPath('rma/rma/managepackage');
            return $resultRedirect;
        }
    }

}
