<?php 
namespace Emipro\Rma\Controller\Customer; 

use Magento\Framework\App\RequestInterface;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Filesystem;
use Magento\Backend\Model\View\Result\RedirectFactory;
session_cache_limiter(false);
header('Cache-Control: max-age=1800');

class Requestrma extends \Magento\Framework\App\Action\Action {
     /**
         * @var \Magento\Framework\View\Result\PageFactory
         */
        protected $resultPageFactory;
        
      
        protected $_customerSession;
        protected $catalogSession;
        protected $_fileUploaderFactory;
        protected $_filesystem;
        protected $_resultRedirectFactory;
       
        public function __construct(
            \Magento\Framework\App\Action\Context $context,
            \Magento\Framework\View\Result\PageFactory $resultPageFactory,
            \Magento\Catalog\Model\Session $catalogSession, 
            \Magento\Customer\Model\Session $customerSession,
             UploaderFactory $fileUploaderFactory,
             RedirectFactory $resultRedirectFactory,
            Filesystem $Filesystem
           
        )
        {

            parent::__construct($context,$resultRedirectFactory);
          
            $this->resultPageFactory = $resultPageFactory;
            $this->_customerSession = $customerSession;
            $this->catalogSession = $catalogSession;
            $this->_fileUploaderFactory = $fileUploaderFactory;
            $this->_filesystem = $Filesystem;
            
        }
    /**
     * Default customer account page
     *
     * @return void
     */
     protected function _getSession()
    {
        return $this->_customerSession;
    }
     public function dispatch(RequestInterface $request)
    {
        if (!$this->_getSession()->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        return parent::dispatch($request);
    }
    public function execute()
    {
		$data=(array)$this->getRequest()->getPost();
		$file_id="";
		$resultRedirect = $this->resultRedirectFactory->create();
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerSession = $objectManager->get('Magento\Customer\Model\Session');//get customer session

		if($customerSession->isLoggedIn()) 
		{
			$customer_id=$customerSession->getCustomer()->getId();//print customer id
			$customer_name=$customerSession->getCustomer()->getName();
		}
		
		$data["date"]=date("Y-m-d H:i:s");
		$helper=$objectManager->get('Emipro\Rma\Helper\Data');
		$admin_user_id=$helper->getConfig('rma/emipro_group/ticket_admin');
		
		$admin_email=$objectManager->get('Magento\User\Model\User')->load($admin_user_id)->getEmail();
		

		$status_title=$helper->getConfig('rma/rma_group/rma_selectstatus');
		$ticket_email=$helper->getConfig('rma/emipro_group/ticket_email');
		$data1=$objectManager->get('Emipro\Rma\Model\Status')->load($status_title,"title");
		$status_id=$data1->getStatusId();
		$data["status"]=$status_id;
		$rma=$objectManager->get('Emipro\Rma\Model\Rma');
		$rma->setData($data);
		$rma->save();
		
		$rma_id=$rma->save()->getId();
				$msg=strip_tags($data["comment"]); 
				$message_new=nl2br($msg);
		
		$dataa=$objectManager->get('Emipro\Rma\Model\Rma')->load($rma_id);
		$dataa->getStatus();
		
		
				$model=$objectManager->get('Emipro\Rma\Model\Conversation');
				$model->setData("rma_id",$rma_id);
				$model->setData("message",$message_new);
				$model->setData("name",$customer_name);
				$model->setData("status_id",$status_id);
				$model->setData("date",$data["date"]);
				$model->save();
				$conversation_id=$model->save()->getId();
			
		if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') 
			 {
                    $fileName       = $_FILES['file']['name'];
					$ext = pathinfo($fileName, PATHINFO_EXTENSION);
					$new_fileName=md5(uniqid(rand(), true)).".".$ext;
					
					$uploader = $this->_fileUploaderFactory->create(['fileId' => 'file']);
					 $path = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                        ->getAbsolutePath('rma/attachment');
           
                if (!is_dir($path)) {
                    mkdir($path, 0777, true);
                }
                $uploader->save($path, $new_fileName);
                    $file=$objectManager->get('Emipro\Rma\Model\Attachment');
                    $file->setData("conversation_id",$conversation_id);
                    $file->setData("file",$new_fileName);
                    $file->setData("current_file_name",$fileName);
                    $file->save();
                    $file_id=$file->save()->getId();
                   
                  
              } 
			$current_ticket_status=$dataa->getStatus();
			$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
			$ticket_template=$helper->getConfig('rma/ticket/create',$storeScope); 			
			$sender_email=$helper->getConfig('trans_email/ident_'.$ticket_email.'/email');
			$sender_name=$helper->getConfig('trans_email/ident_'.$ticket_email.'/name');
			
			$emailTemplateVariables = [];
			$emailTemplateVariables['customer_name'] =$customer_name;  
			$emailTemplateVariables['message'] =$message_new;  
			$emailTemplateVariables['rma_id']=$rma_id;
			$emailTemplateVariables['rma_status']= $current_ticket_status;
		
			$emailTemplateVariables['sender_name'] = $helper->getConfig('trans_email/ident_'.$ticket_email.'/name'); 
			$emailTemplateVariables['tempsubject'] = "New RMA request with ticket Id ".$rma_id;
			$storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface');
			$currentStore = $storeManager->getStore();
			$filepath=$currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA)."rma/attachment/";
			
			$attachment=$objectManager->get('Emipro\Rma\Controller\Customer\UploadTransportBuilder');
			if($file_id!="")
			{
					$transport = $attachment->setTemplateIdentifier($ticket_template)
						->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => "1"])
						->setTemplateVars($emailTemplateVariables)
						->setFrom(array("name"=>$sender_name,'email'=>$sender_email))
						->addTo($admin_email)
						->setReplyTo($sender_email)
						->attachFile($path."/".$new_fileName,$new_fileName)
						->getTransport();
			}
			else
			{
				$transport = $attachment->setTemplateIdentifier($ticket_template)
						->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => "1"])
						->setTemplateVars($emailTemplateVariables)
						->setFrom(array("name"=>$sender_name,'email'=>$sender_email))
						->addTo($admin_email)
						->setReplyTo($sender_email)
						->getTransport();
			}			
				 
					$transport->sendMessage();

			// Ticket created successfully email for customer 
			
			$customer=$objectManager->get('Magento\Customer\Model\Customer')->load($customer_id);
			$customer_email=$customer->getemail();
			$template=$helper->getConfig('rma/ticket/customer',$storeScope);      	
			$sender_email=$helper->getConfig('trans_email/ident_'.$ticket_email.'/email');
			$sender_name=$helper->getConfig('trans_email/ident_'.$ticket_email.'/name');
			$emailTemplateVariables = array();
			$emailTemplateVariables['customer_name'] =$customer_name;  
			$emailTemplateVariables['message'] =$message_new; 
			$emailTemplateVariables['rma_id']=$rma_id; 
			$emailTemplateVariables['sender_name'] = $helper->getConfig('trans_email/ident_'.$ticket_email.'/name'); 
			$emailTemplateVariables['tempsubject'] = "RMA Request has been created with RMA Id ".$rma_id;
				$transport = $attachment->setTemplateIdentifier($template)
						->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => "1"])
						->setTemplateVars($emailTemplateVariables)
						->setFrom(array("name"=>$sender_name,'email'=>$sender_email))
						->addTo($customer_email)
						->setReplyTo($sender_email)						
						->getTransport();
			$transport->sendMessage();
			$this->messageManager->addSuccess(
                                __(
                                    'Request for RMA was submitted successfully.'
                                )
                            );
			return $resultRedirect->setPath('*/*/returnlist');		
		
    }
}
