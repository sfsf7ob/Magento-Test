<?php 
namespace Emipro\Rma\Controller\Customer; 
use Magento\Framework\App\RequestInterface;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Filesystem;

class Savereplay extends \Magento\Framework\App\Action\Action {
     /**
         * @var \Magento\Framework\View\Result\PageFactory
         */
        protected $resultPageFactory;
        protected $_resultRedirectFactory;
        protected $_customerSession;
        protected $catalogSession;
        protected $_fileUploaderFactory;
        protected $_filesystem;
       
        public function __construct(
            \Magento\Framework\App\Action\Context $context,
            \Magento\Framework\View\Result\PageFactory $resultPageFactory,
            \Magento\Catalog\Model\Session $catalogSession, 
            \Magento\Customer\Model\Session $customerSession,
            RedirectFactory $resultRedirectFactory,
            UploaderFactory $fileUploaderFactory,
            Filesystem $Filesystem
        )
        {

            parent::__construct($context,$resultRedirectFactory);          
            $this->resultPageFactory = $resultPageFactory;
            $this->_customerSession = $customerSession;
            $this->catalogSession = $catalogSession;
            $this->_fileUploaderFactory = $fileUploaderFactory;
            $this->_filesystem = $Filesystem;
            
        }
    /**
     * Default customer account page
     *
     * @return void
     */
     protected function _getSession()
    {
        return $this->_customerSession;
    }
     public function dispatch(RequestInterface $request)
    {
        if (!$this->_getSession()->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        return parent::dispatch($request);
    }
    public function execute()
    {
		$maxfile_size=1024*1024*4;// 4 MB filesize;
		$data=(array)$this->getRequest()->getPost();
		$file_id="";
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerSession = $objectManager->get('Magento\Customer\Model\Session');//get customer session
		$resultRedirect = $this->resultRedirectFactory->create();

		if($customerSession->isLoggedIn()) 
		{
			$customer_id=$customerSession->getCustomer()->getId();//print customer id
			$customer_name=$customerSession->getCustomer()->getName();
		}
				
		$dataa=$objectManager->get('Emipro\Rma\Model\Rma')->load($data["rma_id"]);
		$status_id=$dataa->getStatus();		
		$helper=$objectManager->get('Emipro\Rma\Helper\Data');
		$admin_user_id=$helper->getConfig('rma/emipro_group/ticket_admin');
		$admin_email=$objectManager->get('Magento\User\Model\User')->load($admin_user_id)->getEmail();				
		$ticket_email=$helper->getConfig('rma/emipro_group/ticket_email');
		
		
		if($data["message"]=="")
		{
			$this->messageManager->addError(
                                __(
                                    'Please enter valid message.'
                                  )
                            );
            return $resultRedirect->setPath('*/*/viewrma/',array("id"=>$data["rma_id"]));
		}
		
		$msg=strip_tags($data["message"]); 
		$message_new=nl2br($msg);		
		try
		{
			if($_FILES['file']['size'] >$maxfile_size)
			{
				Mage::getSingleton('customer/session')->setMessage($data["message"]);
				$this->messageManager->addError(
                                __(
                                    'RMA attachment was not uploaded. Please,try again later.'
                                  )
                            );
                return $resultRedirect->setPath('*/*/viewrma/',array("id"=>$data["viewrmaid"]));
			}	
				$model=$objectManager->get('Emipro\Rma\Model\Conversation');
				$model->setData("rma_id",$data["rma_id"]);
				$model->setData("message",$message_new);
				$model->setData("name",$customer_name);
				$model->setData("user_details", 'customer');
				$model->setData("con_id",$customer_id);
				$model->setData("status_id",$status_id);
				$model->setData("date",$data["date"]);
				$model->save();
				$conversation_id=$model->save()->getId();
			
			 if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '')
			  {
					$fileName       = $_FILES['file']['name'];
					$ext = pathinfo($fileName, PATHINFO_EXTENSION);
					$new_fileName=md5(uniqid(rand(), true)).".".$ext;
					$uploader = $this->_fileUploaderFactory->create(['fileId' => 'file']);
                $path = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                        ->getAbsolutePath('rma/attachment');
                if (!is_dir($path)) {
                    mkdir($path, 0777, true);
                }                              
                $uploader->save($path, $new_fileName);
                     $file=$objectManager->get('Emipro\Rma\Model\Attachment');
                     $file->setData("conversation_id",$conversation_id);
                     $file->setData("file",$new_fileName);
                     $file->setData("current_file_name",$fileName);
                     $file->save();
                     $file_id=$file->save()->getId();                    
               } 
             $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $curr_status=$objectManager->get('Emipro\Rma\Model\Status')->load($dataa->getStatus(),"status_id");
            $current_ticket_status=$curr_status->getTitle();
			$ticket_template=$helper->getConfig('rma/ticket/conversation', $storeScope);          	        	
			$sender_email=$helper->getConfig('trans_email/ident_'.$ticket_email.'/email');
			$sender_name=$helper->getConfig('trans_email/ident_'.$ticket_email.'/name');
			$emailTemplateVariables = array();			 
			$emailTemplateVariables['message'] =$message_new;  
			$emailTemplateVariables['rma_id']=$data["rma_id"];
			$emailTemplateVariables['rma_status']= $current_ticket_status;
			$emailTemplateVariables['sender_name'] = $customer_name;
			$emailTemplateVariables['tempsubject'] = "Reply for RMA request ".$data["rma_id"];				
			$attachment=$objectManager->get('Emipro\Rma\Controller\Customer\UploadTransportBuilder');
			
					
					if($file_id != "")
					{
						$transport = $attachment->setTemplateIdentifier($ticket_template)
							->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => "1"])
							->setTemplateVars($emailTemplateVariables)
							->setFrom(array("name"=>$sender_name,'email'=>$sender_email))
							->addTo($admin_email)
							->setReplyTo($sender_email)
							->attachFile($path."/".$new_fileName,$new_fileName)						
							->getTransport();
										
						$transport->sendMessage();
					}
					else
					{
						$transport = $attachment->setTemplateIdentifier($ticket_template)
							->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => "1"])
							->setTemplateVars($emailTemplateVariables)
							->setFrom(array("name"=>$sender_name,'email'=>$sender_email))
							->addTo($admin_email)
							->setReplyTo($sender_email)
							->getTransport();																					
								$transport->sendMessage();
					}			
			
          $this->messageManager->addSuccess(
                                __(
                                    'Request for RMA was submitted successfully.'
                                )
                            );     
		}
		catch (Exception $e)
		{
			echo $e->getMessage();
			$this->messageManager->addError(
                                __(
                                    'Unable to submit your request. Please, try again later.'
                                )
                            );			
		}				
		return $resultRedirect->setPath('*/*/viewrma/', ["id" => $data["rma_id"]]);		
		

    }
}
