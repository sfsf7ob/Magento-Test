<?php 
namespace Emipro\Rma\Controller\Customer; 
ini_set('session.cache_limiter','public');
header('Cache-Control: max-age=900');
use Magento\Framework\App\RequestInterface;

class Request extends \Magento\Framework\App\Action\Action {
     /**
         * @var \Magento\Framework\View\Result\PageFactory
         */
        protected $resultPageFactory;
        protected $_customerSession;
        protected $catalogSession;
       
        public function __construct(
            \Magento\Framework\App\Action\Context $context,
            \Magento\Framework\View\Result\PageFactory $resultPageFactory,
            \Magento\Catalog\Model\Session $catalogSession, 
            \Magento\Customer\Model\Session $customerSession
        )
        {

            parent::__construct($context);
            $this->resultPageFactory = $resultPageFactory;
            $this->_customerSession = $customerSession;
            $this->catalogSession = $catalogSession;
            
        }
    /**
     * Default customer account page
     *
     * @return void
     */
     protected function _getSession()
    {
        return $this->_customerSession;
    }
     public function dispatch(RequestInterface $request)
    {
        if (!$this->_getSession()->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        return parent::dispatch($request);
    }
    public function execute()
    {
		$data=(array)$this->getRequest()->getPost();
		
		
		if(!empty($data))
		{
			$orderEntityId=$data["hide"];
			$productId=$data["pro"];
			$qty=explode(":",$productId);

			$this->catalogSession->setMyValue($orderEntityId); 
			$this->catalogSession->setMyProduct($qty[0]);
			$this->catalogSession->setMyQty($qty[1]);
		}
        $this->_view->loadLayout();
        $this->_view->renderLayout();
    }
}
