<?php 
namespace Emipro\Rma\Controller\Customer; 
use Magento\Framework\App\RequestInterface;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Filesystem;
class Cancelrequest extends \Magento\Framework\App\Action\Action {
     /**
         * @var \Magento\Framework\View\Result\PageFactory
         */
        protected $resultPageFactory;
        protected $_resultRedirectFactory;
        protected $_customerSession;
        protected $catalogSession;
        protected $_fileUploaderFactory;
        protected $_filesystem;
       
        public function __construct(
            \Magento\Framework\App\Action\Context $context,
            \Magento\Framework\View\Result\PageFactory $resultPageFactory,
            \Magento\Catalog\Model\Session $catalogSession, 
            \Magento\Customer\Model\Session $customerSession,
            RedirectFactory $resultRedirectFactory,
            UploaderFactory $fileUploaderFactory,
            Filesystem $Filesystem
        )
        { 
            parent::__construct($context,$resultRedirectFactory);          
            $this->resultPageFactory = $resultPageFactory;
            $this->_customerSession = $customerSession;
            $this->catalogSession = $catalogSession;
            $this->_fileUploaderFactory = $fileUploaderFactory;
            $this->_filesystem = $Filesystem;
            
        }
    public function execute()
    {
		 $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
   		 $resultRedirect = $this->resultRedirectFactory->create();
    	 $rmaid = $this->getRequest()->getParam('id');
		 $rmamodel= [];
		 $rmamodel=$objectManager->get('Emipro\Rma\Model\Rma')->load($rmaid)->getData();
		 $currentDate = $objectManager->get("Magento\Framework\Stdlib\DateTime\DateTime")->date('Y-m-d H:i');		 
		$status_id=$rmamodel['status'];			
		try
		{
			 if($status_id == 1)
			 {	
			 	$rmamodel['status'] = 6; // 6 = canceled
		 		$rmamodel['date'] = $currentDate;
			 	$collection=$objectManager->create('Emipro\Rma\Model\Rma');
			 	$collection->load($rmaid);
	            $collection->setRmaId($rmaid);
	            $collection->addData($rmamodel);
	            $collection->save();
	            $helper=$objectManager->create('Emipro\Rma\Helper\Data');
		 		$admin_user_id=$helper->getConfig('rma/emipro_group/ticket_admin');
	            $admin_email=$objectManager->get('Magento\User\Model\User')->load($admin_user_id)->getEmail();
	            $customer=$objectManager->get('Magento\Customer\Model\Customer')->load($rmamodel['customer_id']);
				$customer_email=$customer->getemail();
				$emails=[$admin_email,$customer_email];
				$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
				$ticket_email=$helper->getConfig('rma/emipro_group/ticket_email');
				$ticket_template=$helper->getConfig('rma/ticket/cancel',$storeScope);	
				$sender_email=$helper->getConfig('trans_email/ident_'.$ticket_email.'/email');
				$sender_name=$helper->getConfig('trans_email/ident_'.$ticket_email.'/name');

				$emailTemplateVariables = [];
				$emailTemplateVariables['customer_name'] =$rmamodel['customer_name'];   
				$emailTemplateVariables['rma_id']=$rmamodel['rma_id'];
				$emailTemplateVariables['rma_status']= "Canceled";
				$emailTemplateVariables['sender_name'] = $helper->getConfig('trans_email/ident_'.$ticket_email.'/name'); 
				$emailTemplateVariables['tempsubject'] = "Return request has been canceled with Return #".$rmaid;
				$attachment=$objectManager->create('Emipro\Rma\Controller\Customer\UploadTransportBuilder');
				$transport = $attachment->setTemplateIdentifier($ticket_template)
						->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => "1"])
						->setTemplateVars($emailTemplateVariables)
						->setFrom(["name"=>$sender_name,'email'=>$sender_email])
						->addTo($emails)
						->setReplyTo($sender_email)
						->getTransport();
				$transport->sendMessage();
						
	            $this->messageManager->addSuccess(
                                __(
                                    'Request has been canceled successfully.'
                                )
                            );
			 }
			 else
			 {	
			 	$this->messageManager->addError(
                                __(
                                    'Request must be pandding to approve for cancel request.'
                                )
                            );
			 }
			 return $resultRedirect->setPath('*/*/viewrma/', ["id" => $rmaid]);
			
		}
		catch (Exception $e)
		{
			echo $e->getMessage();
			$this->messageManager->addError(
                                __(
                                    'Unable to submit your request. Please, try again later.'
                                )
                            );			
		}
		return $resultRedirect->setPath('*/*/viewrma/', ["id" => $rmaid]);				

    }
}
