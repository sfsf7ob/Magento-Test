<?php
/*
 * //////////////////////////////////////////////////////////////////////////////////////
 *
 * @Author Emipro Technologies Private Limited
 * @Category Emipro
 * @Package  Emipro_Paymentservicecharge
 * @License http://shop.emiprotechnologies.com/license-agreement/
 *
 * //////////////////////////////////////////////////////////////////////////////////////
 */
namespace Emipro\Paymentservicecharge\Helper;

use Magento\Framework\Url;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $scopeConfig;
    protected $objManager;
    protected $storeManager;
    protected $messageManager;
    protected $response;
    protected $resourceConfig;
    protected $responseFactory;
    protected $url;
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\App\ResponseInterface $response,
        \Magento\Framework\App\Config\Storage\WriterInterface $resourceConfig,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->objManager = $objectmanager;
        $this->_storeManager = $storeManager;
        $this->messageManager = $messageManager;
        $this->response = $response;
        $this->resourceConfig = $resourceConfig;
        $this->responseFactory = $responseFactory;
        $this->url = $url;
    }

    public function checkVersion($ua_regexp)
    {
        $productMetadata = $this->objManager->create('Magento\Framework\App\ProductMetadataInterface');
        $version = $productMetadata->getVersion();
        if ($version < '2.2.0') {
            $table_data = unserialize($ua_regexp);
            return $table_data;
        } else {
            $serialize = $this->objManager->create('Magento\Framework\Serialize\Serializer\Json');
            $table_data = $serialize->unserialize($ua_regexp);
            return $table_data;
        }
    }
    public function getConfig($config_path)
    {
        return $this->scopeConfig->getValue(
            $config_path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}
