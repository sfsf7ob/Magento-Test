<?php

namespace Emipro\Paymentservicecharge\Plugin;

use Magento\Catalog\Model\Session;

class UpdateFeeForOrder
{
    /**
     * @var \Magento\Quote\Model\QuoteFactory
     */
    protected $checkoutSession;
    protected $registry;
    protected $session;
    const AMOUNT_SUBTOTAL = 'subtotal';
    
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Registry $registry,
        Session $session
    ) {
        $this->session = $session;
        $this->checkoutSession = $checkoutSession;
        $this->registry = $registry;
    }
    /**
     * Get shipping, tax, subtotal and discount amounts all together
     *
     * @return array
     */
    public function afterGetAmounts($cart, $result)
    {
        $total = $result;
        $quote = $this->checkoutSession->getQuote();
        $paymentMethod = $quote->getPayment()->getMethod();
        $paypalMehodList = ['payflowpro','payflow_link','payflow_advanced','braintree_paypal','paypal_express_bml'
        ,'payflow_express_bml','payflow_express','paypal_express'];
        $pointsSession = $this->session;
        if ($pointsSession->getCalcpoints()) {
            if (in_array($paymentMethod, $paypalMehodList)) {
                $finalpoints = $pointsSession->getCalcpoints();
                $total[self::AMOUNT_SUBTOTAL] = $total[self::AMOUNT_SUBTOTAL] + $finalpoints;
            }
        }
        return  $total;
    }
    /**
     * Get shipping, tax, subtotal and discount amounts all together
     *
     * @return array
     */
    public function beforeGetAllItems($cart)
    {
        $paypalTest = $this->registry->registry('is_paypal_items')? $this->registry->registry('is_paypal_items') : 0;
        $quote = $this->checkoutSession->getQuote();
        $pointsSession = $this->session;
        $paymentMethod = $quote->getPayment()->getMethod();
        $paypalMehodList = ['payflowpro','payflow_link','payflow_advanced','braintree_paypal','paypal_express_bml'
        ,'payflow_express_bml','payflow_express','paypal_express'];
        if ($pointsSession->getCalcpoints()) {
            if ($paypalTest < 3 && in_array($paymentMethod, $paypalMehodList)) {
                if (method_exists($cart, 'addCustomItem')) {
                    if (!$pointsSession->getCriditcustomitem() && !$pointsSession->getCriditcustomitempoint()) {
                        $cart->addCustomItem($pointsSession->getCalcLable(), 1, $pointsSession->getCalcpoints());
                        $pointsSession->setCriditcustomitem(true);
                        $pointsSession->setCriditcustomitempoint($pointsSession->getCalcpoints());
                    } elseif ($pointsSession->getCriditcustomitem() && !$pointsSession->getCriditcustomitempoint()) {
                        $cart->addCustomItem($pointsSession->getCalcLable(), 1, $pointsSession->getCalcpoints());
                        $pointsSession->setCriditcustomitem(true);
                        $pointsSession->setCriditcustomitempoint($pointsSession->getCalcpoints());
                    } elseif (!$pointsSession->getCriditcustomitem() && $pointsSession->getCriditcustomitempoint()) {
                        $cart->addCustomItem($pointsSession->getCalcLable(), 1, $pointsSession->getCalcpoints());
                        $pointsSession->setCriditcustomitem(true);
                        $pointsSession->setCriditcustomitempoint($pointsSession->getCalcpoints());
                    } elseif ($pointsSession->getCriditcustomitem() && $pointsSession->getCriditcustomitempoint()) {
                        $pointsSession->setCriditcustomitem(0);
                        $pointsSession->setCriditcustomitempoint(0);
                    }
                    $reg = $this->registry->registry('is_paypal_items');
                    $current = $reg + 1 ;
                    $this->registry->unregister('is_paypal_items');
                    $this->registry->register('is_paypal_items', $current);
                }
            }
        }
    }
}
