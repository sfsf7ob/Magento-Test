var config = {
    map: {
        '*': {
            'Magento_Checkout/js/action/select-payment-method':
                'Emipro_Paymentservicecharge/js/action/select-payment-method'
        }
    }
};