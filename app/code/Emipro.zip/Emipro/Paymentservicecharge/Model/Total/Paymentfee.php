<?php

namespace Emipro\Paymentservicecharge\Model\Total;

use Magento\Catalog\Model\Session;

class Paymentfee extends \Magento\Quote\Model\Quote\Address\Total\AbstractTotal
{
    protected $quoteValidator = null;
    protected $calculator = null;
    protected $customersession;
    protected $pointssession;
    protected $storeManager;
    protected $currencyFactory;

    protected $data;
    public function __construct(
        \Magento\Quote\Model\QuoteValidator $quoteValidator,
        \Magento\Tax\Model\Calculation $calculations,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
        Session $session,
        \Magento\Customer\Model\Session $customersession,
        \Emipro\Paymentservicecharge\Helper\Data $data
    ) {
        $this->data = $data;
        $this->customersession = $customersession;
        $this->pointssession = $session;
        $this->quoteValidator = $quoteValidator;
        $this->calculator = $calculations;
        $this->storeManager = $storeManager;
        $this->currencyFactory = $currencyFactory;
    }

    public function collect(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
        \Magento\Quote\Model\Quote\Address\Total $total
    ) {
        parent::collect($quote, $shippingAssignment, $total);
        $selectedpaymentmethod = $quote->getPayment()->getMethod();
        $customer_group_id = $this->customersession->getCustomerGroupId();
        $enable = $this->data->getConfig('checkout/general/active', true);
        $ua_regexp = $this->data->getConfig('checkout/general/active2', true);
        $tax_en = $this->data->getConfig('checkout/general/charge_tax_active', true);
        $paymentTaxClass = $this->data->getConfig('checkout/general/charge_tax_class', true);
        $chargeType = $this->data->getConfig('checkout/general/charge_includes_tax', true);
        $table_data = $this->data->checkVersion($ua_regexp);
        $taxAmount = 0;
        $balance = 0;
        $basebalance = 0;
        $isFix = 0;
        $isPercent = 1;
        $lable = '';
        if ($enable == 1) {
            foreach ($table_data as $data) {
                if (($data['payment_method'] == $selectedpaymentmethod || $data["payment_method"] == 32000) &&
                    ($customer_group_id == $data["customer_group"] || $data["customer_group"] == 32000)) {
                    if ($data['extra_charge_type'] == 'fixed') {
                        $basebalance = $data['extra_charge_value'];
                        $balance = $this->convertPrice($basebalance, $isFix);
                    }
                    if ($data['extra_charge_type'] == 'percentage') {
                        $totalamount = round($quote->getSubtotal());
                        $balance = $totalamount * $data['extra_charge_value'] / 100;
                        $basebalance = $this->convertPrice($balance, $isPercent);
                    }
                    if ($tax_en == 1) {
                        if ($chargeType == 1) {
                            $lable = $data['name'] . "(Included Tax)";
                        } else {
                            $lable = $data['name'];
                        }
                    } else {
                        $lable = $data['name'];
                    }
                }
            }
            $fee = $balance;
            if ($tax_en == 1) {
                $calc = $this->calculator;
                $store = $quote->getStore();
                $addressTaxRequest = $calc->getRateRequest(
                    $quote->getShippingAddress(),
                    $quote->getBillingAddress(),
                    $quote->getCustomerTaxClassId(),
                    $store
                );
                $addressTaxRequest->setProductClassId($paymentTaxClass);
                $rate = $calc->getRate($addressTaxRequest);
                $taxAmount = $calc->calcTaxAmount($balance, $rate, false, true);
                $baseTaxAmount = $calc->calcTaxAmount($balance, $rate, false, true);
                if ($total->getSubtotal()) {
                    $fee = $fee + $taxAmount;
                    if ($chargeType == 1) {
                        $balance = $balance + $taxAmount;
                    } else {
                        $total->setTaxAmount($total->getTaxAmount() + $taxAmount);
                        $total->setBaseTaxAmount($total->getBaseTaxAmount() + $baseTaxAmount);
                    }
                }
            }
            if ($total->getSubtotal()) {
                $total->setTotalAmount('paymentfee', $balance);
                $total->setBaseTotalAmount('paymentfee', $balance);
                $total->setPaychargeFee($balance);
                $total->setPaychargeBaseFee($basebalance);
                $total->setPaychargeTaxFee($taxAmount);
                $total->setPaychargeBaseTaxFee($taxAmount);
                $total->setPaychargeFeeName($lable);
                $quote->setPaychargeFee($balance);
                $quote->setPaychargeBaseFee($basebalance);
                $quote->setPaychargeTaxFee($taxAmount);
                $quote->setPaychargeBaseTaxFee($taxAmount);
                $quote->setPaychargeFeeName($lable);
                $total->setGrandTotal($total->getGrandTotal() + $fee);
                $total->setBaseGrandTotal($total->getBaseGrandTotal() + $basebalance);
                $this->pointssession->setCalcpoints($balance);
                $this->pointssession->setCalcLable($lable);
            }
        }
        return $this;
    }
    protected function clearValues(Address\Total $total)
    {
        $total->setTotalAmount('subtotal', 0);
        $total->setBaseTotalAmount('subtotal', 0);
        $total->setTotalAmount('tax', 0);
        $total->setBaseTotalAmount('tax', 0);
        $total->setTotalAmount('discount_tax_compensation', 0);
        $total->setBaseTotalAmount('discount_tax_compensation', 0);
        $total->setTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setBaseTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setSubtotalInclTax(0);
        $total->setBaseSubtotalInclTax(0);
        $this->pointssession->setCalcpoints(0);
        $this->pointssession->setCriditcustomitem(0);
        $this->pointssession->setCriditcustomitempoint(0);
        $this->pointssession->setCalcLable('');
    }

    public function fetch(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Model\Quote\Address\Total $total
    ) {
        $selectedpaymentmethod = $quote->getPayment()->getMethod();
        $customer_group_id = $this->customersession->getCustomerGroupId();
        $enable = $this->data->getConfig('checkout/general/active', true);
        $ua_regexp = $this->data->getConfig('checkout/general/active2', true);
        $tax_en = $this->data->getConfig('checkout/general/charge_tax_active', true);
        $paymentTaxClass = $this->data->getConfig('checkout/general/charge_tax_class', true);
        $chargeType = $this->data->getConfig('checkout/general/charge_includes_tax', true);
        $table_data = $this->data->checkVersion($ua_regexp);
        $fee = 0;
        $isFix = 0;
        $lable = '';
        if ($enable == 1) {
            foreach ($table_data as $data) {
                if (($data['payment_method'] == $selectedpaymentmethod || $data["payment_method"] == 32000) &&
                    ($customer_group_id == $data["customer_group"] || $data["customer_group"] == 32000)) {
                    if ($data['extra_charge_type'] == 'fixed') {
                        $fee = $data['extra_charge_value'];
                        $fee = $this->convertPrice($fee, $isFix);
                    }
                    if ($data['extra_charge_type'] == 'percentage') {
                        $totalamount = round($quote->getSubtotal());
                        $fee = $totalamount * $data['extra_charge_value'] / 100;
                    }
                    if ($tax_en == 1) {
                        if ($chargeType == 1) {
                            $lable = $data['name'] . "(Included Tax)";
                        } else {
                            $lable = $data['name'];
                        }
                    } else {
                        $lable = $data['name'];
                    }
                }
            }
            if ($tax_en == 1) {
                $calc = $this->calculator;
                $store = $quote->getStore();
                $addressTaxRequest = $calc->getRateRequest(
                    $quote->getShippingAddress(),
                    $quote->getBillingAddress(),
                    $quote->getCustomerTaxClassId(),
                    $store
                );
                $addressTaxRequest->setProductClassId($paymentTaxClass);
                $rate = $calc->getRate($addressTaxRequest);
                $taxAmount = $calc->calcTaxAmount($fee, $rate, false, true);
                $baseTaxAmount = $calc->calcTaxAmount($fee, $rate, false, true);
                if ($total->getSubtotal()) {
                    if ($chargeType == 1) {
                        $fee = $fee + $taxAmount;
                    }
                }
            }
        }
        return [
            'code' => 'paymentfee',
            'title' => __("$lable"),
            'value' => $fee,
        ];
    }

    public function getLabel()
    {
        return __(" ");
    }

    public function convertPrice($amountValue, $chargetype)
    {
        $currentCurrency = $this->storeManager->getStore()->getCurrentCurrency()->getCode();
        $baseCurrency = $this->storeManager->getStore()->getBaseCurrency()->getCode();
        if ($currentCurrency != $baseCurrency) {
            $rate = $chargetype == 0 ? $rate = $this->currencyFactory->create()->load($baseCurrency)->getAnyRate($currentCurrency) : $rate = $this->currencyFactory->create()->load($currentCurrency)->getAnyRate($baseCurrency);
            $amountValue = $amountValue * $rate;
        }
        return $amountValue;
    }
}
