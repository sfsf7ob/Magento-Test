<?php
namespace Emipro\Paymentservicecharge\Model\Total\Invoice;

class Paymentfee extends \Magento\Sales\Model\Order\Invoice\Total\AbstractTotal
{
    public function collect(\Magento\Sales\Model\Order\Invoice $invoice)
    {
            parent::collect($invoice);
            $order=$invoice->getOrder();
            $invoice->setPaychargeFee($order->getPaychargeFee());
            $invoice->setPaychargeBaseFee($order->getPaychargeBaseFee());
            $invoice->setPaychargeFeeName($order->getPaychargeFeeName());
            $invoice->setTaxAmount($order->getTaxAmount());
            $invoice->setBaseTaxAmount($order->getBaseTaxAmount());
            $invoice->setGrandTotal($order->getGrandTotal());
            $invoice->setBaseGrandTotal($order->getBaseGrandTotal());
            return $this;
    }
}
