<?php
namespace Emipro\Paymentservicecharge\Model\Total\Order\Creditmemo;

class Paymentfee extends \Magento\Sales\Model\Order\Creditmemo\Total\AbstractTotal
{
    public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }
    public function collect(\Magento\Sales\Model\Order\Creditmemo $creditmemo)
    {
        parent::collect($creditmemo);
        $order=$creditmemo->getOrder();
        if ($order->getPaychargeFee()) {
            $creditmemo->setPaychargeFee($order->getPaychargeFee());
            $creditmemo->setPaychargeBaseFee($order->getPaychargeBaseFee());
            $creditmemo->setPaychargeFeeName($order->getPaychargeFeeName());
            $creditmemo->setTaxAmount($order->getTaxAmount());
            $creditmemo->setBaseTaxAmount($order->getBaseTaxAmount());
            $creditmemo->setGrandTotal($order->getGrandTotal());
            $creditmemo->setBaseGrandTotal($order->getBaseGrandTotal());
        }
        return $this;
    }
}
