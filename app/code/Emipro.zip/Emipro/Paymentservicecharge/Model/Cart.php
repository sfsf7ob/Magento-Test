<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Emipro\Paymentservicecharge\Model;

/**
 * PayPal-specific model for shopping cart items and totals
 * The main idea is to accommodate all possible totals into PayPal-compatible 4 totals and line items
 */
class Cart extends \Magento\Paypal\Model\Cart
{
    protected function _validate()
    {
        $areItemsValid = false;
        $this->_areAmountsValid = false;
        $modelsession = \Magento\Framework\App\ObjectManager::getInstance();
        $pointsSession = $modelsession->get('Magento\Catalog\Model\Session');
        $referenceAmount = $this->_salesModel->getDataUsingMethod('base_grand_total');
        $itemsSubtotal = 0;
        foreach ($this->getAllItems() as $i) {
            $itemsSubtotal = $itemsSubtotal + $i->getQty() * $i->getAmount();
        }

        $sum = $itemsSubtotal + $this->getTax();

        if (empty($this->_transferFlags[self::AMOUNT_SHIPPING])) {
            $sum += $this->getShipping();
        }

        if (empty($this->_transferFlags[self::AMOUNT_DISCOUNT])) {
            $sum -= $this->getDiscount();
            // PayPal requires to have discount less than items subtotal
            $this->_areAmountsValid = round($this->getDiscount(), 4) < round($itemsSubtotal, 4);
        } else {
            $this->_areAmountsValid = $itemsSubtotal > 0.00001;
        }
        if (sprintf('%.4F', $sum) != sprintf('%.4F', $referenceAmount)) {
            if ($pointsSession->getCalcpoints()) {
                $referenceAmount = $this->_salesModel->getDataUsingMethod('base_grand_total')-
                $pointsSession->getCalcpoints();
            } else {
                $referenceAmount = $this->_salesModel->getDataUsingMethod('base_grand_total');
            }
        }
        if (sprintf('%.4F', $sum) == sprintf('%.4F', $referenceAmount)) {
            $areItemsValid = true;
        }
        $areItemsValid = $areItemsValid && $this->_areAmountsValid;

        if (!$areItemsValid) {
            $this->_salesModelItems = [];
            $this->_customItems = [];
        }
    }
}
