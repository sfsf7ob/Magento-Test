<?php
namespace Emipro\Paymentservicecharge\Observer;

use Magento\Customer\Model\Session;
use Magento\Framework\Event\ObserverInterface;

class Paymentfee implements ObserverInterface
{
    protected $scopeConfig;
    protected $customersession;
    protected $data;
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Emipro\Paymentservicecharge\Helper\Data $data,
        Session $customersession
    ) {
        $this->data = $data;
        $this->customersession = $customersession;
        $this->scopeConfig = $scopeConfig;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quote = $observer->getQuote();
        $selectedpaymentmethod = $quote->getPayment()->getMethod();
        $customer_group_id = $this->customersession->getCustomerGroupId();
        $enable = $this->data->getConfig('checkout/general/active', true);
        $ua_regexp = $this->data->getConfig('checkout/general/active2', true);
        $table_data = $this->data->checkVersion($ua_regexp);
        $order = $observer->getOrder();
        foreach ($table_data as $data) {
            if (($data['payment_method'] == $selectedpaymentmethod || $data["payment_method"] == 32000) &&
                ($customer_group_id == $data["customer_group"] || $data["customer_group"] == 32000)) {
                $service_charge = $quote->getPaychargeFee();
                $base_service_charge = $quote->getPaychargeBaseFee();
                $name = $quote->getPaychargeFeeName();
                $order->setPaychargeFee($service_charge);
                $order->setPaychargeBaseFee($base_service_charge);
                $order->setPaychargeFeeName($name);
                $order->setGrandTotal($order->getGrandTotal());
                $order->setBaseGrandTotal($order->getBaseGrandTotal());
            }
        }
    }
}
