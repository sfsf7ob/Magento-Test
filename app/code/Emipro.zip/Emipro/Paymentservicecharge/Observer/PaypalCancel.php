<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Emipro\Paymentservicecharge\Observer;

use Magento\Framework\Event\ObserverInterface;

class PaypalCancel implements ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $objManager = \Magento\Framework\App\ObjectManager::getInstance();
        $pointsSession = $objManager->get('Magento\Catalog\Model\Session');
        $pointsSession->setCriditcustomitem(0);
        $pointsSession->setCriditcustomitempoint(0);
        $pointsSession->setCalcLable('');
    }
}
