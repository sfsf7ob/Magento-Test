<?php

namespace Emipro\Paymentservicecharge\Observer\Sales;

use Magento\Framework\Event\ObserverInterface;

class OrderLoadAfter implements ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order=$observer->getOrder();
        $extensionAttributes = $order->getExtensionAttributes();
        if ($extensionAttributes === null) {
            $extensionAttributes = $this->getOrderExtensionDependency();
        }
        $attr=$order->getData('paycharge_fee_name');
        $extensionAttributes->setPaychargeFeeName($attr);
        $order->setExtensionAttributes($extensionAttributes);
        $attr=$order->getData('paycharge_fee');
        $extensionAttributes->setPaychargeFee($attr);
        $order->setExtensionAttributes($extensionAttributes);
    }
    private function getOrderExtensionDependency()
    {
        $orderapi = \Magento\Framework\App\ObjectManager::getInstance();
        $orderExtension = $orderapi->get('\Magento\Sales\Api\Data\OrderExtension');
        return $orderExtension;
    }
}
