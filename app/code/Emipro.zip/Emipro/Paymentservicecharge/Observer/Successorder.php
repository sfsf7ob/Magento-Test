<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Emipro\Paymentservicecharge\Observer;

use Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\App\ResourceConnection;
use Magento\Catalog\Model\Session;

class Successorder implements ObserverInterface
{
    protected $pointssession;
    public function __construct(
        Session $session
    ) {
        $this->pointssession = $session;
    }
 
    /**
     * This is the method that fires when the event runs.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->pointssession->setCalcpoints(0);
        $this->pointssession->setCriditcustomitem(0);
        $this->pointssession->setCriditcustomitempoint(0);
        $this->pointssession->setCalcLable('');
    }
}
