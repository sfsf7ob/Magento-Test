<?php
namespace Emipro\Paymentservicecharge\Block\Sales\Order;

class Paymentfee extends \Magento\Framework\View\Element\Template
{
    
    protected $config;
    protected $order;
    protected $source;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Tax\Model\Config $taxConfig,
        array $data = []
    ) {
        $this->config = $taxConfig;
        parent::__construct($context, $data);
    }

    public function initTotals()
    {
        $parent = $this->getParentBlock();
        $this->order = $parent->getOrder();
        $this->source = $parent->getSource();
        if ($this->source->getPaychargeFee()) {
            $store = $this->getStore();
            $fee = new \Magento\Framework\DataObject(
                [
                    'code' => 'paymentfee',
                    'strong' => false,
                    'value' => $this->source->getPaychargeFee(),
                    'base_value' => $this->source->getPaychargeBaseFee(),
                    'label' => __($this->source->getPaychargeFeeName()),
                ]
            );
            $parent->addTotal($fee, 'paymentfee');
            $parent->addTotal($fee, 'paymentfee');
            return $this;
        }
    }
}
