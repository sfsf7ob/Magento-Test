<?php
namespace Emipro\Paymentservicecharge\Block\Adminhtml\Sales\Order;

class Paymentfee extends \Magento\Framework\View\Element\Template
{
    /**
     * Tax configuration model
     *
     * @var \Magento\Tax\Model\Config
     */
    protected $config;

    /**
     * @var Order
     */
    protected $order;

    /**
     * @var \Magento\Framework\DataObject
     */
    protected $source;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Tax\Model\Config $taxConfig
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Tax\Model\Config $taxConfig,
        array $data = []
    ) {
        $this->config = $taxConfig;
        parent::__construct($context, $data);
    }

    public function initTotals()
    {

        $parent = $this->getParentBlock();
        $this->order = $parent->getOrder();
        $this->source = $parent->getSource();

        $store = $this->getStore();
        if ($this->source->getPaychargeFee()) {
            $fee = new \Magento\Framework\DataObject(
                [
                    'code' => 'paymentfee',
                    'strong' => false,
                    'value' => $this->source->getPaychargeFee(),
                    'base_value' => $this->source->getPaychargeBaseFee(),
                    'label' => __($this->source->getPaychargeFeeName()),
                ]
            );
            $parent->addTotal($fee, 'paymentfee');
            $parent->addTotal($fee, 'paymentfee');
            return $this;
        }
    }
}
