<?php
namespace Emipro\Paymentservicecharge\Block\Adminhtml\Sales\Order\Invoice;

class Paymentfee extends \Magento\Framework\View\Element\Template
{

    protected $config;
    protected $order;
    protected $source;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Tax\Model\Config $taxConfig,
        array $data = []
    ) {
        $this->config = $taxConfig;
        parent::__construct($context, $data);
    }

    public function initTotals()
    {
        $parent = $this->getParentBlock();
        $this->order = $parent->getOrder();
        $this->source = $parent->getSource();
        $store = $this->getStore();
        if ($this->source->getPaychargeFee()) {
            $fee = new \Magento\Framework\DataObject(
                [
                    'code' => 'paymentfee',
                    'strong' => false,
                    'value' => $this->order->getPaychargeFee(),
                    'base_value' => $this->order->getPaychargeBaseFee(),
                    'label' => __($this->order->getPaychargeFeeName()),
                ]
            );
            $parent->addTotal($fee, 'paymentfee');
            $parent->addTotal($fee, 'paymentfee');
            return $this;
        }
    }
}
