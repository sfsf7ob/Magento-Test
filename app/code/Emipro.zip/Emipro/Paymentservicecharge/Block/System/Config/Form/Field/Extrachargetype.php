<?php
/*
* //////////////////////////////////////////////////////////////////////////////////////
*
* @Author Emipro Technologies Private Limited
* @Category Emipro
* @Package  Emipro_Paymentservicecharge
* @License http://shop.emiprotechnologies.com/license-agreement/
*
* //////////////////////////////////////////////////////////////////////////////////////
*/
namespace Emipro\Paymentservicecharge\Block\System\Config\Form\Field;

class Extrachargetype extends \Magento\Framework\View\Element\Html\Select
{
    public function getExtrachargetype()
    {
        $methods = [];
        return [
            'fixed'=>__('Fixed Charge'),
            'percentage'=>__('Percentage')];
    }
    public function setInputName($value)
    {
        return $this->setName($value);
    }
    public function _toHtml()
    {
        if (!$this->getOptions()) {
            foreach ($this->getExtrachargetype() as $key => $Titles) {
                $this->addOption($key, $Titles);
            }
        }
        return parent::_toHtml();
    }
}
