<?php
namespace Emipro\Paymentservicecharge\Block\System\Config\Form\Field;

class Regexceptions extends \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{
    /**
     * Grid columns
     *
     * @var array
     */
    protected $customerGroupRenderer;
    protected $paymentRenderer;
    protected $chargeTypeRenderer;
    /**
     * Enable the "Add after" button or not
     *
     * @var bool
     */
    protected $addAfter = true;
    /**
     *  Label of add button
     *
     * @var string
     */
    protected $addButtonLabel;
    /**
     * Check if columns are defined, set template
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->addButtonLabel = __('Add');
    }
    /**
     * Returns renderer for country element
     *
     * @return \Magento\Braintree\Block\Adminhtml\Form\Field\Countries
     */
    protected function getCustomerGroupRenderer()
    {
        if (!$this->customerGroupRenderer) {
            $this->customerGroupRenderer = $this->getLayout()->createBlock(
                'Magento\CatalogInventory\Block\Adminhtml\Form\Field\Customergroup',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
        }
        return $this->customerGroupRenderer;
    }

    protected function _getPaymentRenderer()
    {
        if (!$this->paymentRenderer) {
            $this->paymentRenderer = $this->getLayout()->createBlock(
                'Emipro\Paymentservicecharge\Block\System\Config\Form\Field\Activepayment',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
        }
        return $this->paymentRenderer;
    }

    protected function _getChargeTypeRenderer()
    {
        if (!$this->chargeTypeRenderer) {
            $this->chargeTypeRenderer = $this->getLayout()->createBlock(
                'Emipro\Paymentservicecharge\Block\System\Config\Form\Field\Extrachargetype',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
        }
        return $this->chargeTypeRenderer;
    }

    /**
     * Prepare to render
     *
     * @return void
     */
    protected function _prepareToRender()
    {
        $this->addColumn(
            'name',
            [
                'label' => __('Label'),
                'required' => true,
                'style' => 'width:100px',
            ]
        );
        $this->addColumn(
            'payment_method',
            [
                'label' => __('Payment Method'),
                'renderer' => $this->_getPaymentRenderer(),
            ]
        );
        $this->addColumn(
            'customer_group',
            [
                'label' => __('Customer Group'),
                'renderer' => $this->getCustomerGroupRenderer(),
            ]
        );
        $this->addColumn(
            'extra_charge_value',
            [
                'label' => __('Extra Charge Type'),
                'required' => true,
                'style' => 'width:100px',
            ]
        );
        $this->addColumn(
            'extra_charge_type',
            [
                'label' => __('Extra Charge Type'),
                'renderer' => $this->_getChargeTypeRenderer(),
            ]
        );
        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add');
    }

    protected function _prepareArrayRow(\Magento\Framework\DataObject $row)
    {
        $options = [];

        $customerGroup = $row->getData('customer_group');
        if ($customerGroup) {
            $options['option_' . $this->getCustomerGroupRenderer()->calcOptionHash($customerGroup)] = 'selected="selected"';
        }

        $paymentmethod = $row->getData('payment_method');
        if ($paymentmethod) {
            $options['option_' . $this->_getPaymentRenderer()->calcOptionHash($paymentmethod)] = 'selected="selected"';
        }
        $chargetype = $row->getData('extra_charge_type');
        if ($chargetype) {
            $options['option_' . $this->_getChargeTypeRenderer()->calcOptionHash($chargetype)] = 'selected="selected"';
        }
        $row->setData('option_extra_attrs', $options);
    }
}
