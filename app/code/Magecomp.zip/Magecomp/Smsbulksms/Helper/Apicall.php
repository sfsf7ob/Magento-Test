<?php
namespace Magecomp\Smsbulksms\Helper;

class Apicall extends \Magento\Framework\App\Helper\AbstractHelper
{
	const XML_BULKSMS_API_USERNAME = 'sms/smsgatways/bulksmsusername';
	const XML_BULKSMS_API_PASSWORD = 'sms/smsgatways/bulksmspassword';
	const XML_BULKSMS_API_URL = 'sms/smsgatways/bulksmsapiurl';

	public function __construct(\Magento\Framework\App\Helper\Context $context)
	{
		parent::__construct($context);
	}

    public function getTitle() {
        return __("Bulksms");
    }

    public function getApiUsername(){
        return $this->scopeConfig->getValue(
            self::XML_BULKSMS_API_USERNAME,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getApiPassword(){
        return $this->scopeConfig->getValue(
            self::XML_BULKSMS_API_PASSWORD,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

	public function getApiUrl()	{
		return $this->scopeConfig->getValue(
            self::XML_BULKSMS_API_URL,
			 \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
	}

    public function validateSmsConfig()
    {
        return $this->getApiUsername() && $this->getApiPassword() && $this->getApiUrl();
    }

		public function callApiUrl($mobilenumbers,$message)
    {

        //$url = $this->getApiUrl();
        $url = "https://www.hisms.ws/api.php";
        $user = $this->getApiUsername();
        $password = $this->getApiPassword();
        $mobilenumbers = $mobilenumbers;

        $ch = curl_init();
        if (!$ch){
            die("Couldn't initialize a cURL handle");
        }
        $ret = curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt ($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt ($ch, CURLOPT_POSTFIELDS,
            "send_sms&username=966566666314&password=tanza2020&numbers=$mobilenumbers&sender=Tanza.sa&message=$message");
        $ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

       $curlresponse = curl_exec($ch);

       // $curlresponse = "https://mobily.ws/api/msgSend.php?mobile=966555179112&password=123456789&numbers='.$mobilenumbers.'&sender=alhabibshop&msg='.$message.'&applicationType=68&lang=3&senderId=alhabibshop";
            //curl_exec($ch); // execute

        return $curlresponse;

    }
}
