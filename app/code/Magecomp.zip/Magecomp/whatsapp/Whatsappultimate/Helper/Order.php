<?php 
namespace Magecomp\Whatsappultimate\Helper;

use Magento\Store\Model\ScopeInterface;

class Order extends \Magecomp\Whatsappultimate\Helper\Data
{
    // USER TEMPLATE
    const WHATSAPP_IS_CUSTOMER_ORDER_NOTIFICATION = 'usertemplate/userorderplace/enable';
    const WHATSAPP_CUSTOMER_ORDER_NOTIFICATION_TEMPLATE = 'usertemplate/userorderplace/template';

	//ADMIN TEMPLATE
    const WHATSAPP_IS_ADMIN_ORDER_NOTIFICATION = 'admintemplate/adminorderplace/enable';
    const WHATSAPP_ADMIN_ORDER_NOTIFICATION_TEMPLATE = 'admintemplate/adminorderplace/template';

	public function isOrderNotificationForUser() {
        return $this->isEnabled() && $this->scopeConfig->getValue(self::WHATSAPP_IS_CUSTOMER_ORDER_NOTIFICATION,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid());
    }

    public function getOrderNotificationUserTemplate()
    {
        if($this->isEnabled())
        {
            return  $this->scopeConfig->getValue(self::WHATSAPP_CUSTOMER_ORDER_NOTIFICATION_TEMPLATE,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid());
        }
    }

    public function isOrderNotificationForAdmin()
    {
        return $this->isEnabled() && $this->scopeConfig->getValue(self::WHATSAPP_IS_ADMIN_ORDER_NOTIFICATION,
                ScopeInterface::SCOPE_STORE,
                $this->getStoreid());
    }

    public function getOrderNotificationForAdminTemplate()
    {
        if($this->isEnabled())
        {
            return  $this->scopeConfig->getValue(self::WHATSAPP_ADMIN_ORDER_NOTIFICATION_TEMPLATE,
                ScopeInterface::SCOPE_STORE,
                $this->getStoreid());
        }
    }
}