<?php 
namespace Magecomp\Whatsappultimate\Helper;

use Magento\Store\Model\ScopeInterface;

class Contact extends \Magecomp\Whatsappultimate\Helper\Data
{
    // USER TEMPLATE
    const WHATSAPP_IS_CUSTOMER_CONTACT_NOTIFICATION = 'usertemplate/usercontactus/enable';
    const WHATSAPP_CUSTOMER_CONTACT_NOTIFICATION_TEMPLATE = 'usertemplate/usercontactus/template';

	//ADMIN TEMPLATE
    const WHATSAPP_IS_ADMIN_CONTACT_NOTIFICATION = 'admintemplate/admincontactus/enable';
    const WHATSAPP_ADMIN_CONTACT_NOTIFICATION_TEMPLATE = 'admintemplate/admincontactus/template';

	public function isContactNotificationForUser() {
        return $this->isEnabled() && $this->scopeConfig->getValue(self::WHATSAPP_IS_CUSTOMER_CONTACT_NOTIFICATION,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid());
    }

    public function getContactNotificationUserTemplate()
    {
        if($this->isEnabled())
        {
            return  $this->scopeConfig->getValue(self::WHATSAPP_CUSTOMER_CONTACT_NOTIFICATION_TEMPLATE,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid());
        }
    }

    public function isContactNotificationForAdmin()
    {
        return $this->isEnabled() && $this->scopeConfig->getValue(self::WHATSAPP_IS_ADMIN_CONTACT_NOTIFICATION,
                ScopeInterface::SCOPE_STORE,
                $this->getStoreid());
    }

    public function getContactNotificationForAdminTemplate()
    {
        if($this->isEnabled())
        {
            return  $this->scopeConfig->getValue(self::WHATSAPP_ADMIN_CONTACT_NOTIFICATION_TEMPLATE,
                ScopeInterface::SCOPE_STORE,
                $this->getStoreid());
        }
    }
}