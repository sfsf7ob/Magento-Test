var config = {
    map: {
        '*': {
            'Magento_Checkout/js/model/address-converter':'Magecomp_Cityandregionmanager/js/model/address-converter',
            checkoutjs:'Magecomp_Cityandregionmanager/js/checkout_js'
        }
    }
};