<?php

namespace Magecomp\Cityandregionmanager\Block\Checkout;

use Magento\Framework\View\Element\Template;
use Magecomp\Cityandregionmanager\Model\Config;

class Js extends \Magento\Framework\View\Element\Template
{
    protected $_config;

    public function __construct(
        Template\Context $context,
        Config $config,
        array $data = []
    )
    {
        $this->_config = $config;
        parent::__construct($context, $data);
    }

    public function enableModule()
    {
        return $this->_config->getEnableExtensionYesNo() == 1 ? true : false;
    }

    public function enableButtons()
    {
        return $this->_config->getEnableButtonsYesNo() == 1 ? true : false;
    }

}