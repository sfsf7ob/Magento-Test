<?php
namespace Magecomp\Cityandregionmanager\Controller\Adminhtml\Importcitieslist;

use Magento\Backend\App\Action;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Json\Helper\Data as JsonHelper;

class Upload extends Action
{
    protected $_directoryList;
    protected $_jsonHelper;

    public function __construct(
        Action\Context $context,
        DirectoryList $directoryList,
        JsonHelper $jsonHelper
    )
    {
        $this->_jsonHelper = $jsonHelper;
        $this->_directoryList = $directoryList;
        parent::__construct($context);
    }

    public function execute()
    {
        try{
            $tmpDir = $this->_directoryList->getPath('tmp');
            $ext = pathinfo('import_cities_list.csv')['extension'];
            move_uploaded_file($this->getRequest()->getFiles("csv_uploader")['tmp_name'], $tmpDir . "/datasheet-citiesList." . $ext);
            return $this->jsonResponse(['error' => "File uploaded successfully! Now click on import data."]);
        }catch (\Exception $e){
            return $this->jsonResponse(['error' => $e->getMessage()]);
        }
    }

    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson($this->_jsonHelper->jsonEncode($response));
    }

}