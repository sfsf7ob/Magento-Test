<?php
namespace Magecomp\Smspro\Model;

class Phonebook extends \Magento\Framework\Model\AbstractModel
{

    protected function _construct()
    {
        $this->_init('Magecomp\Smspro\Model\ResourceModel\Phonebook');
    }


}