<?php
\Magento\Framework\Component\ComponentRegistrar::register(\Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magecomp_Reviewreminder', __DIR__);
