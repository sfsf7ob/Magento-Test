<?php
namespace Magecomp\Whatsappultimate\Observer\Customer;

use Magento\Framework\Event\ObserverInterface;

class ContactPostObserver implements ObserverInterface
{
    protected $helperapi;
    protected $helpercontact;
    protected $emailfilter;
    protected $helpersmsapi;

    public function __construct(
        \Magecomp\Whatsappultimate\Helper\Apicall $helperapi,
        \Magecomp\Whatsappultimate\Helper\Contact $helpercontact,
        \Magento\Email\Model\Template\Filter $filter,
        \Magecomp\Smspro\Helper\Apicall $helpersmsapi)
    {
        $this->helperapi = $helperapi;
        $this->helpercontact = $helpercontact;
        $this->emailfilter = $filter;
        $this->helpersmsapi = $helpersmsapi;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if(!$this->helpercontact->isEnabled())
            return $this;

        $request = $observer->getRequest();
        $name = $request->getParam('name');
        $email = $request->getParam('email');
        $telephone = $request->getParam('telephone');
        $comment = $request->getParam('comment');

        $this->emailfilter->setVariables([
            'name' => $name,
            'email' => $email,
            'telephone' => $telephone,
            'comment' => $comment,
            'store_name' => $this->helpercontact->getStoreName()
        ]);

        if ($this->helpercontact->isContactNotificationForUser())
        {
            $message = $this->helpercontact->getContactNotificationUserTemplate();
            $finalmessage = $this->emailfilter->filter($message);
            $this->helperapi->callApiUrl($telephone,$finalmessage);
            $this->helpersmsapi->callApiUrl($telephone,$finalmessage);
        }

        if($this->helpercontact->isContactNotificationForAdmin() && $this->helpercontact->getAdminNumber())
        {
            $message = $this->helpercontact->getContactNotificationForAdminTemplate();
            $finalmessage = $this->emailfilter->filter($message);
            $this->helperapi->callApiUrl($this->helpercontact->getAdminNumber(),$finalmessage);
            $this->helpersmsapi->callApiUrl($this->helpercontact->getAdminNumber(),$finalmessage);
        }

        return $this;
    }
}
