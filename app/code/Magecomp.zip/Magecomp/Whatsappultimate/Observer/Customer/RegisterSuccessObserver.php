<?php
namespace Magecomp\Whatsappultimate\Observer\Customer;

use Magento\Framework\Event\ObserverInterface;

class RegisterSuccessObserver implements ObserverInterface
{
    protected $helperapi;
    protected $helpercustomer;
    protected $smsmodel;
    protected $emailfilter;
    protected $helpersmsapi;

    public function __construct(
        \Magecomp\Whatsappultimate\Helper\Apicall $helperapi,
        \Magecomp\Whatsappultimate\Helper\Customer $helpercustomer,
        \Magecomp\Whatsappultimate\Model\WhatsappultimateFactory $smsmodel,
        \Magecomp\Smspro\Helper\Apicall $helpersmsapi,
        \Magento\Email\Model\Template\Filter $filter)
    {
        $this->helperapi = $helperapi;
        $this->helpersmsapi = $helpersmsapi;
        $this->helpercustomer = $helpercustomer;
        $this->smsmodel = $smsmodel;
        $this->emailfilter = $filter;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test1.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info("call observer");
        if(!$this->helpercustomer->isEnabled())
            return $this;

        $customer = $observer->getEvent()->getCustomer();

        $controller = $observer->getAccountController();
        
		$mobilenumber = $controller->getRequest()->getParam('mobilenumber');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $tempcustomer = $objectManager->create('Magento\Customer\Model\Customer')
            ->load($customer->getId());
        $logger->info($customer->getId());
        $logger->info($mobilenumber);
        $this->emailfilter->setVariables([
            'customer' => $tempcustomer,
            'mobilenumber' => $mobilenumber
        ]);

        if($this->helpercustomer->isSignUpNotificationForAdmin() && $this->helpercustomer->getAdminNumber())
        {
            $message = $this->helpercustomer->getSignUpNotificationForAdminTemplate();
            $finalmessage = $this->emailfilter->filter($message);
            $this->helperapi->callApiUrl($this->helpercustomer->getAdminNumber(),$finalmessage);
            $this->helpersmsapi->callApiUrl($this->helpercustomer->getAdminNumber(),$finalmessage);
        }
        if($mobilenumber == '' || $mobilenumber == null)
            return $this;

        $smsModel = $this->smsmodel->create();
        $smscollection = $smsModel->getCollection()
                       ->addFieldToFilter('mobile_number', $mobilenumber);
        foreach ($smscollection as $sms)
        {
            $sms->delete();
        }
        $logger->info("call observer");
        if ($this->helpercustomer->isSignUpNotificationForUser())
        {
            $message = $this->helpercustomer->getSignUpNotificationForUserTemplate();
            $logger->info($message);
            $finalmessage = $this->emailfilter->filter($message);
            $logger->info($finalmessage);
            $this->helperapi->callApiUrl($mobilenumber,$finalmessage);
            $this->helpersmsapi->callApiUrl($mobilenumber,$finalmessage);
        }
        return $this;
    }
}
