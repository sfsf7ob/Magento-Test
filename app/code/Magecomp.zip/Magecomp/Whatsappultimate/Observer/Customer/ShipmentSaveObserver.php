<?php
namespace Magecomp\Whatsappultimate\Observer\Customer;

use Magento\Framework\Event\ObserverInterface;

class ShipmentSaveObserver implements ObserverInterface
{
    protected $helperapi;
    protected $helpershipment;
    protected $emailfilter;
    protected $customerFactory;
    protected $helpersmsapi;

    public function __construct(
        \Magecomp\Whatsappultimate\Helper\Apicall $helperapi,
        \Magecomp\Whatsappultimate\Helper\Shipment $helpershipment,
        \Magento\Email\Model\Template\Filter $filter,
        \Magecomp\Smspro\Helper\Apicall $helpersmsapi,
        \Magento\Customer\Model\CustomerFactory $customerFactory)
    {
        $this->helperapi = $helperapi;
        $this->helpershipment = $helpershipment;
        $this->helpersmsapi = $helpersmsapi;
        $this->emailfilter = $filter;
        $this->customerFactory = $customerFactory;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		if(!$this->helpershipment->isEnabled())
            return $this;

        $shipment   = $observer->getShipment();
        $order      = $shipment->getOrder();

        if($shipment)
        {
            $billingAddress = $order->getBillingAddress();
            $mobilenumber = $billingAddress->getTelephone();
            if($order->getCustomerId() > 0)
            {
                $customer = $this->customerFactory->create()->load($order->getCustomerId());
                $mobile = $customer->getMobilenumber();
                if($mobile != '' && $mobile != null)
                {
                    $mobilenumber = $mobile;
                }

                $this->emailfilter->setVariables([
                    'order' => $order,
                    'shipment' => $shipment,
                    'customer' => $customer,
                    'mobilenumber' => $mobilenumber
                ]);
            }
            else
            {
                $this->emailfilter->setVariables([
                    'order' => $order,
                    'shipment' => $shipment,
                    'mobilenumber' => $mobilenumber
                ]);
            }

            if ($this->helpershipment->isShipmentNotificationForUser())
            {
                $message = $this->helpershipment->getShipmentNotificationUserTemplate();
                $finalmessage = $this->emailfilter->filter($message);
                $this->helpersmsapi->callApiUrl($mobilenumber,$finalmessage);
                $this->helperapi->callApiUrl($mobilenumber,$finalmessage);
            }

            if($this->helpershipment->isShipmentNotificationForAdmin() && $this->helpershipment->getAdminNumber())
            {
                $message = $this->helpershipment->getShipmentNotificationForAdminTemplate();
                $finalmessage = $this->emailfilter->filter($message);
                $this->helperapi->callApiUrl($this->helpershipment->getAdminNumber(),$finalmessage);
                $this->helpersmsapi->callApiUrl($this->helpershipment->getAdminNumber(),$finalmessage);
            }
        }
        return $this;
    }
}
