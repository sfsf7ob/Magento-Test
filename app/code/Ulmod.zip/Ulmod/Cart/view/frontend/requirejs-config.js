var config = {
    config: {
        mixins: {
            'Ulmod_Conf/js/swatch-renderer': {
                'Ulmod_Cart/js/swatch-renderer': true
            },
            'Magento_Swatches/js/swatch-renderer': {
                'Ulmod_Cart/js/swatch-renderer': true
            }
        }
    }
};
