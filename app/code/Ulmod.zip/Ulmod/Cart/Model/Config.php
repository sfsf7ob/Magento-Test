<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\Json\DecoderInterface;
use Ulmod\Cart\Model\Source\DisplayElements;
use Ulmod\Cart\Plugin\DataPost\Replacer;
use Magento\Customer\Model\SessionFactory;
use Magento\Framework\UrlInterface;

class Config
{
    /**
     * @var EncoderInterface
     */
    private $jsonEncoder;

    /**
     * @var DecoderInterface
     */
    private $jsonDecoder;

    /**
     * @var SessionFactory
     */
    private $sessionFactory;
  
    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;
    
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param EncoderInterface $jsonEncoder
     * @param DecoderInterface $jsonDecoder
     * @param SessionFactory $sessionFactory
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        EncoderInterface $jsonEncoder,
        DecoderInterface $jsonDecoder,
        SessionFactory $sessionFactory,
        UrlInterface $urlBuilder
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->jsonEncoder = $jsonEncoder;
        $this->jsonDecoder = $jsonDecoder;
        $this->sessionFactory = $sessionFactory;
        $this->urlBuilder = $urlBuilder;
    }
    
    /**
     * @param $path
     *
     * @return mixed
     */
    public function getModuleConfig($path)
    {
        return $this->scopeConfig->getValue(
            'ulmod_cart/' . $path,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getViewCartText()
    {
        return (string)$this->getModuleConfig('popup/confirm_display/viewcart_text');
    }

    /**
     * @return int
     */
    public function getTime()
    {
        return (int)$this->getModuleConfig('popup/confirm_display/time');
    }
    
    /**
     * @return string
     */
    public function getContinueText()
    {
        return (string)$this->getModuleConfig('popup/confirm_display/continue_text');
    }
       
    /**
     * @return bool
     */
    public function isUsedOnProductPage()
    {
        return (bool)$this->getModuleConfig('popup/product/use_on_product_page');
    }

    /**
     * @return string
     */
    public function getGotoCheckoutText()
    {
        return (string)$this->getModuleConfig('popup/confirm_display/goto_checkout_text');
    }
    
    /**
     * @return string
     */
    public function getProductButton()
    {
        return $this->getModuleConfig('popup/product/product_button');
    }

    /**
     * @return bool
     */
    public function isDisplayImageBlock()
    {
        return in_array(
            DisplayElements::IMAGE,
            $this->getDisplayElements()
        );
    }

    /**
     * @return array
     */
    protected function getDisplayElements()
    {
        $elements = $this->getModuleConfig('popup/confirm_display/display_elements');
        $elements = explode(',', $elements);

        return $elements;
    }
    
    /**
     * @return bool
     */
    public function isDisplayCount()
    {
        return in_array(
            DisplayElements::COUNT,
            $this->getDisplayElements()
        );
    }

    /**
     * @return bool
     */
    public function isDisplayGoToCheckout()
    {
        return in_array(
            DisplayElements::CHECKOUT_BUTTON,
            $this->getDisplayElements()
        );
    }

    /**
     * @return bool
     */
    public function isDisplaySubtotal()
    {
        return in_array(
            DisplayElements::SUBTOTAL,
            $this->getDisplayElements()
        );
    }
    
    /**
     * @return string
     */
    public function jsParam($block)
    {
        $loadingGif = $block->getViewFileUrl(
            'Ulmod_Cart::images/umpp_loading.gif'
        );
        
        $param = [
            'send_url'           => $this->getUrl('ulmod_cart/cart/add'),
            'src_image_progress' => $loadingGif,
            'flying_image'       => $this->getModuleConfig('general/flying_image'),
            'align'              => "0",
            'open_minicart'      => false
        ];

        return $this->jsonEncoder->encode($param);
    }
   
    /**
     * @return bool
     */
    public function isOpenMinicart()
    {
        return (bool)$this->getModuleConfig('general/open_minicart');
    }

    /**
     * @return string
     */
    public function getDisplayAlign()
    {
        return $this->getModuleConfig('confirm_display/align');
    }
    
    /**
     * @return bool
     */
    public function isFlyImageEnabled()
    {
        return (bool)$this->getModuleConfig('general/flying_image');
    }
    
    /**
     * @param string $data
     * @return array
     */
    public function decode($data)
    {
        return $this->jsonDecoder->decode($data);
    }

    /**
     * @param $data
     * @return string
     */
    public function encode($data)
    {
        return $this->jsonEncoder->encode($data);
    } 

    /**
     * @return int
     */
    public function isShowProductQty()
    {
        return (int)$this->getModuleConfig('popup/confirm_display/show_qty_product');
    }

    /**
     * URL getter
     *
     * @param string $route
     * @param array $params
     * @return string
     */
    public function getUrl($route, $params = [])
    {
        return $this->urlBuilder->getUrl($route, $params);
    }
    
    /**
     * @return string
     */
    public function getInfoMessage()
    {
        return __('in your cart');
    }

    /**
     * @return bool
     */
    public function isWishlistAjax()
    {
        return $this->getModuleConfig('general/wishlist')
            && $this->isCustomerLogged();
    }

    /**
     * @return int
     */
    public function getProductsQtyLimit()
    {
        return (int)$this->getModuleConfig('popup/selling/products_qty_limit');
    }
    
    /**
     * @return bool
     */
    public function isCompareAjax()
    {
        return (bool)$this->getModuleConfig('general/compare');
    }

    /**
     * @param string $type
     * @return string
     */
    public function getDataPost($type)
    {
        $result = Replacer::DATA_POST;
        if (($type == 'compare' && $this->isCompareAjax())
            || ($type == 'wishlist' && $this->isWishlistAjax())
        ) {
            $result = Replacer::DATA_POST_AJAX;
        }

        return $result;
    }
    
    /**
     * Check if need include dataPostAjax.js
     *
     * @return bool
     */
    public function isActionsAjax()
    {
        return $this->isWishlistAjax()
            || $this->isCompareAjax();
    }
    
    /**
     * @return bool
     */
    public function isRedirectToProduct()
    {
        return (bool)$this->getModuleConfig('general/redirect_to_product');
    }
    
    /**
     * @return bool
     */
    public function isChangeQty()
    {
        return in_array(
            DisplayElements::QTY,
            $this->getDisplayElements()
        );
    }

    /**
     * @return string
     */
    public function getBlockTitle()
    {
        return $this->getModuleConfig('popup/selling/block_title') ?: __('More Choices:');
    }

    /**
     * @return bool
     */
    public function isCustomerLogged()
    {
        return $this->sessionFactory->create()->isLoggedIn();
    }
    
    /**
     * @return string
     */
    public function getBlockSubTitle()
    {
        return $this->getModuleConfig('popup/selling/block_subtitle')
            ?: __('You may be interested in the following items');
    }
}
