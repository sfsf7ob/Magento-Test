<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Model\Source;

use Magento\Framework\Option\ArrayInterface;

class Button implements ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            [
                'value' => '0',
                'label' => __('Stay on Product Page')
            ],
            [
                'value' => '1',
                'label' => __('Go to Category Page')
            ],
            [
                'value' => '2',
                'label' => __('Go to Custom Page')
            ]
        ];

        return $options;
    }
}
