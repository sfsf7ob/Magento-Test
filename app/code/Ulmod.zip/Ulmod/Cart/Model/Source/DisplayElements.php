<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Model\Source;

use Magento\Framework\Option\ArrayInterface;

class DisplayElements implements ArrayInterface
{
    /**
     * Popup elements values
     */
    const IMAGE = 'image';
    const COUNT = 'count';
    const SUBTOTAL = 'subtotal';
    const QTY = 'qty';
    const CHECKOUT_BUTTON = 'checkout_button';

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            [
                'value' => self::IMAGE,
                'label' =>__('Product Image')
            ],
            [
                'value' => self::COUNT,
                'label' =>__('Products Number in Cart')
            ],
            [
                'value' => self::SUBTOTAL,
                'label' =>__('Cart Subtotal')
            ],
            [
                'value' => self::QTY,
                'label' =>__('Product Quantity Box')
            ],
            [
                'value' => self::CHECKOUT_BUTTON,
                'label' =>__('Go To Checkout Button')
            ],
        ];

        return $options;
    }
}
