<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Model\Source;

use Magento\Framework\Option\ArrayInterface;

class BlockType implements ArrayInterface
{
    /**
     * Block type values
     */
    const RELATED = 'related';
    const CROSSSELL = 'crosssell';
    
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            [
                'value' => '0',
                'label' =>__('None')
            ],
            [
                'value' => self::RELATED,
                'label' =>__('Related Products')
            ],
            [
                'value' => self::CROSSSELL,
                'label' =>__('Cross-Sell Products')
            ],
        ];
        return $options;
    }
}
