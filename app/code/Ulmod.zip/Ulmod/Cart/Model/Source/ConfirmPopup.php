<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Model\Source;

use Magento\Framework\Option\ArrayInterface;

class ConfirmPopup implements ArrayInterface
{
    /**
     * Confirm popup values
     */
    const MINI_PAGE = '0';
    const OPTIONS = '1';

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            [
                'value' => self::MINI_PAGE,
                'label' => __('Show All Product Infos')
            ],
            [
                'value' => self::OPTIONS,
                'label' => __('Show Product Name, Custom Options and Qty Only')
            ]
        ];

        return $options;
    }
}
