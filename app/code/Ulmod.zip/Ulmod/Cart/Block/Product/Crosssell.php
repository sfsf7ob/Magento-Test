<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Block\Product;

use Magento\Catalog\Block\Product\Context;
use Ulmod\Cart\Model\Config as ModelConfig;
        
class Crosssell extends \Magento\Catalog\Block\Product\ProductList\Crosssell
{
    /**
     * @var ModelConfig
     */
    private $modelConfig;

    /**
     * @param Context $context
     * @param ModelConfig $modelConfig
     */
    public function __construct(
        Context $context,
        ModelConfig $modelConfig,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->modelConfig = $modelConfig;
        $this->setBlockType('crosssell');
    }

    /**
     * @return ModelConfig
     */
    public function getModelConfig()
    {
        return $this->modelConfig;
    }
    
    /**
     * Count items
     *
     * @return int
     * @codeCoverageIgnore
     */
    public function getItemCount()
    {
        return count($this->getItems());
    }
    
    /**
     * Prepare crosssell items data
     *
     * @return \Magento\Catalog\Block\Product\ProductList\Crosssell
     */
    protected function _prepareData()
    {
        $product = $this->_coreRegistry->registry('product');
        /* @var $product \Magento\Catalog\Model\Product */

        $productAttributes = $this->_catalogConfig->getProductAttributes();
        $this->_itemCollection = $product->getCrossSellProductCollection()
            ->addAttributeToSelect($productAttributes)
            ->setPositionOrder()
            ->addStoreFilter();

        $qtyLimit = $this->modelConfig->getProductsQtyLimit();
        $this->_itemCollection->getSelect()->limit($qtyLimit);
        
        $this->_itemCollection->load();

        foreach ($this->_itemCollection as $product) {
            $product->setDoNotUseCategoryId(true);
        }

        return $this;
    }
}
