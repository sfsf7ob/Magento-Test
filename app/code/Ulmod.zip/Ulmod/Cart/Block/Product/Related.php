<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Block\Product;

use Magento\Catalog\Block\Product\Context;
use Magento\Checkout\Model\ResourceModel\Cart as CheckoutCart;
use Magento\Catalog\Model\Product\Visibility as ProductVisibility;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Module\Manager as ModuleManager;
use Ulmod\Cart\Model\Config as ModelConfig;
        
class Related extends \Magento\Catalog\Block\Product\ProductList\Related
{
    /**
     * @var ModelConfig
     */
    private $modelConfig;

    /**
     * @param Context $context
     * @param CheckoutCart $checkoutCart
     * @param ProductVisibility $productVisibility
     * @param CheckoutSession $checkoutSession
     * @param ModuleManager $moduleManager
     * @param ModelConfig $modelConfig
     */
    public function __construct(
        Context $context,
        CheckoutCart $checkoutCart,
        ProductVisibility $productVisibility,
        CheckoutSession $checkoutSession,
        ModuleManager $moduleManager,
        ModelConfig $modelConfig,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $checkoutCart,
            $productVisibility,
            $checkoutSession,
            $moduleManager,
            $data
        );
        $this->modelConfig = $modelConfig;
        $this->_scopeConfig = $context->getScopeConfig();
        $this->setBlockType('related');
    }

    /**
     * Prepare related items data
     *
     * @return \Magento\Catalog\Block\Product\ProductList\Related
     */
    protected function _prepareData()
    {
        /* @var $product \Magento\Catalog\Model\Product */
        $product = $this->_coreRegistry->registry('product');

        $productAttributes = $this->_catalogConfig->getProductAttributes();
        $this->_itemCollection = $product->getRelatedProductCollection()
            ->addAttributeToSelect($productAttributes)
            ->setPositionOrder()
            ->addStoreFilter();

        $limit = $this->modelConfig->getProductsQtyLimit();
        
        $this->_itemCollection->getSelect()
            ->limit($limit);
            
        $this->_itemCollection->load();

        foreach ($this->_itemCollection as $product) {
            $product->setDoNotUseCategoryId(true);
        }

        return $this;
    }
    
    /**
     * @return ModelConfig
     */
    public function getModelConfig()
    {
        return $this->modelConfig;
    }
}
