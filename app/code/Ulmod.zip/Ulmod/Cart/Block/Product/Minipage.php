<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Block\Product;

use Magento\Catalog\Block\Product\View;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Block\Product\ReviewRendererInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Catalog\Block\Product\ImageBuilder;

class Minipage extends View
{
    /**
     * @return $this
     */
    public function _construct()
    {
        $this->setTemplate('Ulmod_Cart::product/minipage.phtml');
        parent::_construct();
    }

    /**
     * @return PageFactory
     */
    public function getPageFactory()
    {
        return $this->getData('pageFactory');
    }

    /**
     * @return Product
     */
    public function getProduct()
    {
        return $this->getData('product');
    }
    
    /**
     * @return ImageBuilder
     */
    public function getImageBuilder()
    {
        return $this->getData('imageBuilder');
    }

    /**
     * @param $product
     * @param $imageId
     * @param array $attributes
     *
     * @return string
     */
    public function getImageBlock($product, $imageId, $attributes = [])
    {
        $block = $this->getImageBuilder()
            ->setProduct($product)
            ->setImageId($imageId)
            ->setAttributes($attributes)
            ->create();

        $html = $block->toHtml();

        return $html;
    }
    
    /**
     * @return string
     */
    public function getOptions()
    {
        return $this->getData('optionsHtml');
    }

    /**
     * @return string
     */
    public function renderPriceHtml()
    {
        $html = '';
        $block = $this->_layout->getBlock('product.price.final');
        if (!$block) {
            $page = $this->getPageFactory()->create(
                false,
                ['isIsolated' => true]
            );
            
            $page->addHandle('catalog_product_view');

            $type = $this->getProduct()->getTypeId();
            $page->addHandle('catalog_product_view_type_' . $type);
            
            $block = $page->getLayout()
                ->getBlock('product.price.final');
        }

        if ($block) {
            $html = $block->toHtml();
        }

        return $html;
    }
    
    /**
     * @return string
     */
    public function getRatingSummary($product)
    {
        $block = $this->getLayout()->createBlock(
            \Magento\Review\Block\Product\ReviewRenderer::class,
            'ulmod.productreview',
            [ 'data' => [
                'product' => $product
            ] ]
        );

        return $block->getReviewsSummaryHtml(
            $product,
            ReviewRendererInterface::SHORT_VIEW
        );
    }
}
