<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Ulmod\Cart\Model\Config as ModelConfig;
use Ulmod\Cart\Plugin\DataPost\Replacer;

class Config extends Template
{
    /**
     * @var array
     */
    private $ajaxElements = [
        'a',
        'button',
        'span'
    ];

    /**
     * @var ModelConfig
     */
    private $modelConfig;
    
    /**
     * @param Context $context
     * @param ModelConfig $modelConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        ModelConfig $modelConfig,
        array $data = []
    ) {
        $this->modelConfig = $modelConfig;
        $this->setTemplate('Ulmod_Cart::config.phtml');
        parent::__construct($context, $data);
    }

    /**
     * @return ModelConfig
     */
    public function getModelConfig()
    {
        return $this->modelConfig;
    }

    /**
     * @return string
     */
    public function getDataPostSelector()
    {
        $attr = '[' . Replacer::DATA_POST_AJAX . ']';
        $selectors = array_map(
            function ($ajaxElement) use ($attr) {
                return $ajaxElement . $attr;
            },
            $this->ajaxElements
        );

        return $this->modelConfig->encode($selectors);
    }
}
