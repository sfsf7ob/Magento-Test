<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Ulmod\Cart\Model\Config as ModelConfig;
use Magento\Framework\Data\Form\FormKey;
use Magento\Catalog\Block\Product\ImageBuilder;
use Magento\Framework\Registry;

class Product extends Template
{
    /**
     * @var ModelConfig
     */
    protected $modelConfig;

    /**
     * @var FormKey
     */
    protected $formKey;
    
    /**
     * @var Registry
     */
    protected $_registry;

    /**
     * @var ImageBuilder
     */
    protected $imageBuilder;

    /**
     * @param Context $context
     * @param ImageBuilder $imageBuilder
     * @param Registry $registry
     * @param FormKey $formKey
     * @param ModelConfig $modelConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        ImageBuilder $imageBuilder,
        Registry $registry,
        FormKey $formKey,
        ModelConfig $modelConfig,
        array $data = []
    ) {
        $this->modelConfig = $modelConfig;
        $this->formKey = $formKey;
        $this->imageBuilder = $imageBuilder;
        $this->_registry = $registry;
        $this->_scopeConfig = $context->getScopeConfig();
        parent::__construct($context, $data);
    }

    /**
     * Get form key
     *
     * @return string
     */
    public function getFormKey()
    {
        return $this->formKey->getFormKey();
    }

    /**
     * Retrieve product image
     *
     * @param \Magento\Catalog\Model\Product $product
     * @param string $imageId
     * @param array $attributes
     * @return \Magento\Catalog\Block\Product\Image
     */
    public function getImage($product, $imageId, $attributes = [])
    {
        $umSimpleProduct = $this->_registry->registry(
            'ulmod_cart_simple_product'
        );
        
        if ($umSimpleProduct) {
            $product = $umSimpleProduct;
        }

        return $this->imageBuilder->setProduct($product)
            ->setImageId($imageId)
            ->setAttributes($attributes)
            ->create();
    }

    /**
     * Get shopping cart modelConfig
     *
     * @return ModelConfig
     */
    public function getModelConfig()
    {
        return $this->modelConfig;
    }
}
