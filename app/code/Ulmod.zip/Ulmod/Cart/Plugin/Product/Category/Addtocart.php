<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Plugin\Product\Category;

use Magento\Catalog\Block\Category\View;
use Ulmod\Cart\Model\Config as ModelConfig;
use Magento\Framework\View\LayoutFactory;

class Addtocart
{
    /**
     * @var LayoutFactory
     */
    private $layoutFactory;
    
    /**
     * @var ModelConfig
     */
    private $modelConfig;

    /**
     * @param ModelConfig $modelConfig
     * @param LayoutFactory $layoutFactory
     */
    public function __construct(
        ModelConfig $modelConfig,
        LayoutFactory $layoutFactory
    ) {
        $this->modelConfig = $modelConfig;
        $this->layoutFactory = $layoutFactory;
    }

    /**
     * @param View $subject
     * @param $result
     *
     * @return string
     */
    public function afterGetProductListHtml(
        View $subject,
        $result
    ) {
        $isEnable = $this->modelConfig->getModuleConfig('general/enable');
        if ($isEnable) {
            $layout = $this->layoutFactory->create();
            $configBlock = $layout->createBlock(
                'Ulmod\Cart\Block\Config',
                'ulmod.cart.config',
                [ 'data' => [] ]
            );

            $html = $configBlock->setPageType('category')
                ->toHtml();
                
            $result .= $html;
        }

        return  $result;
    }
}
