<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Plugin\Product\View;

use Magento\Catalog\Block\Product\View;
use Ulmod\Cart\Model\Config as ModelConfig;
use Magento\Framework\View\LayoutFactory;
    
class Addtocart
{
    /**
     * @var LayoutFactory
     */
    private $layoutFactory;

    /**
     * @var ModelConfig
     */
    private $modelConfig;
    
    /**
     * @param ModelConfig $modelConfig
     * @param LayoutFactory $layoutFactory
     */
    public function __construct(
        ModelConfig $modelConfig,
        LayoutFactory $layoutFactory
    ) {
        $this->modelConfig = $modelConfig;
        $this->layoutFactory = $layoutFactory;
    }

    /**
     * @param View $subject
     * @param $result
     *
     * @return string
     */
    public function afterToHtml(
        View $subject,
        $result
    ) {
        $name = $subject->getNameInLayout();
        $isEnable = $this->modelConfig->getModuleConfig('general/enable');
        $usedOnProductPage = $this->modelConfig->isUsedOnProductPage();
        if ($isEnable && $usedOnProductPage
            && in_array(
                $name,
                [
                    'product.info.addtocart',
                    'product.info.addtocart.additional',
                    'product.info.addto'
                ]
            )
        ) {
            $layout = $this->layoutFactory->create();
            $configBlock = $layout->createBlock(
                \Ulmod\Cart\Block\Config::class,
                'ulmod.cart.config',
                [ 'data' => [] ]
            );

            $html = $configBlock->setPageType('product')
                ->toHtml();
            
            $result .= $html;
        }

        return  $result;
    }
}
