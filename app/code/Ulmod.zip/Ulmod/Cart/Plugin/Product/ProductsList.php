<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Plugin\Product;

use Ulmod\Cart\Model\Config as ModelConfig;
use Magento\Framework\View\LayoutFactory;
        
class ProductsList
{
    /**
     * @var bool
     */
    private $initialized = false;
    
    /**
     * @var ModelConfig
     */
    private $modelConfig;

    /**
     * @var LayoutFactory
     */
    private $layoutFactory;

    /**
     * @param ModelConfig $modelConfig
     * @param LayoutFactory $layoutFactory
     */
    public function __construct(
        ModelConfig $modelConfig,
        LayoutFactory $layoutFactory
    ) {
        $this->modelConfig = $modelConfig;
        $this->layoutFactory = $layoutFactory;
    }

    /**
     * @param View $subject
     * @param $result
     *
     * @return string
     */
    public function afterToHtml(
        $subject,
        $result
    ) {
        $isEnable = $this->modelConfig->getModuleConfig('general/enable');
        if ($isEnable && !$this->initialized) {
            $layout = $this->layoutFactory->create();
            $configBlock = $layout->createBlock(
                'Ulmod\Cart\Block\Config',
                'ulmod.cart.config',
                [ 'data' => [] ]
            );

            $html = $configBlock->setPageType('category')
                ->toHtml();
                
            $result .= $html;
            
            $this->initialized = true;
        }

        return  $result;
    }
}
