<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Plugin\DataPost\Block\Category;

use Ulmod\Cart\Plugin\DataPost\Replacer;
use Magento\Catalog\Block\Product\ProductList\Item\AddTo\Compare as AddToCompare;

class Compare extends Replacer
{
    /**
     * @param AddToCompare $subject
     * @param string $result
     * @return string
     */
    public function afterToHtml(
        AddToCompare $subject,
        $result
    ) {
        $isCompareAjax = $this->modelConfig->isCompareAjax();
        if ($isCompareAjax) {
            $this->dataPostReplace($result);
        }

        return $result;
    }
}
