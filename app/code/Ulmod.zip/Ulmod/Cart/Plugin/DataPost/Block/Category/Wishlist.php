<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Plugin\DataPost\Block\Category;

use Ulmod\Cart\Plugin\DataPost\Replacer;
use Magento\Wishlist\Block\Catalog\Product\ProductList\Item\AddTo\Wishlist as AddToWishlist;

class Wishlist extends Replacer
{
    /**
     * @param AddToWishlist $subject
     * @param string $result
     *
     * @return string
     */
    public function afterToHtml(
        AddToWishlist $subject,
        $result
    ) {
        $isWishlistAjax = $this->modelConfig->isWishlistAjax();
        if ($isWishlistAjax) {
            $this->dataPostReplace($result);
        }

        return $result;
    }
}
