<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Plugin\DataPost\Block\Widget;

use Magento\CatalogWidget\Block\Product\ProductsList as WidgetList;
use Ulmod\Cart\Plugin\DataPost\Replacer;

class ProductsList extends Replacer
{
    /**
     * @param WidgetList $subject
     * @param string $result
     *
     * @return string
     */
    public function afterToHtml(WidgetList $subject, $result)
    {
        $classes = [];
        
        $isWishlistAjax = $this->modelConfig->isWishlistAjax();
        if ($isWishlistAjax) {
            $classes[] = self::WISHLIST_REGEX;
        }
        
        $isCompareAjax = $this->modelConfig->isCompareAjax();
        if ($isCompareAjax) {
            $classes[] = self::COMPARE_REGEX;
        }

        $this->dataPostReplace($result, $classes);

        return $result;
    }
}
