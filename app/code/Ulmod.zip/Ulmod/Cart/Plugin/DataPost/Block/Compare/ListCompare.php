<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Plugin\DataPost\Block\Compare;

use Ulmod\Cart\Plugin\DataPost\Replacer;
use Magento\Catalog\Block\Product\Compare\ListCompare as ProductCompare;

class ListCompare extends Replacer
{
    /**
     * @param ProductCompare $subject
     * @param string $result
     *
     * @return string
     */
    public function afterToHtml(
        ProductCompare $subject,
        $result
    ) {
        $classes = [];
        
        $isWishlistAjax = $this->modelConfig->isWishlistAjax();
        if ($isWishlistAjax) {
            $classes[] = self::WISHLIST_REGEX;
        }
    
        $isCompareAjax = $this->modelConfig->isCompareAjax();
        if ($this->modelConfig->isCompareAjax()) {
            $classes[] = self::COMPARE_REGEX;
        }

        $this->dataPostReplace($result, $classes);

        return $result;
    }
}
