<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Plugin\DataPost\Block\Sidebar;

use Ulmod\Cart\Plugin\DataPost\Replacer;
use Magento\Wishlist\Block\Customer\Sidebar as SidebarWishlist;

class Wishlist extends Replacer
{
    /**
     * @param SidebarWishlist $subject
     * @param string $result
     *
     * @return string
     */
    public function afterToHtml(
        SidebarWishlist $subject,
        $result
    ) {
        $isWishlistAjax = $this->modelConfig->isWishlistAjax();
        if ($isWishlistAjax) {
            $this->dataPostReplace($result);
        }

        return $result;
    }
}
