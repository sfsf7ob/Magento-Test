<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Plugin\DataPost\Controller;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Message\MessageInterface;
use Magento\Framework\Message\ManagerInterface;

class Ajax
{
    /**
     * @var ResultFactory
     */
    private $resultFactory;

    /**
     * @var ManagerInterface
     */
    private $messageManager;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @param RequestInterface $request
     * @param ResultFactory $resultFactory
     * @param ManagerInterface $messageManager
     */
    public function __construct(
        ResultFactory $resultFactory,
        RequestInterface $request,
        ManagerInterface $messageManager
    ) {
        $this->resultFactory = $resultFactory;
        $this->request = $request;
        $this->messageManager = $messageManager;
    }

    /**
     * @param Action $subject
     * @param mixed $result
     *
     * @return mixed
     */
    public function afterExecute(Action $subject, $result)
    {
        $ajaxParam = $this->request->getParam('is_ajax', null);
        if ($ajaxParam) {
            $result = $this->resultFactory
                ->create(ResultFactory::TYPE_JSON)
                ->setData([]);

            $messages = $this->messageManager->getMessages();
            foreach ($messages->getItems() as $message) {
                /** @var MessageInterface $message */
                // replace message for wishlist added
                if ($message->getIdentifier() == 'addProductSuccessMessage') {
                    $message->setIdentifier('addAmProductSuccessMessage');
                }
            }
        }

        return $result;
    }
}
