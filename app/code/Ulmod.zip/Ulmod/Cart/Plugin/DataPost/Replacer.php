<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Plugin\DataPost;

use Ulmod\Cart\Model\Config as ModelConfig;

class Replacer
{
    /**
     * Replacer values
     */
    const DATA_POST_AJAX = 'data-post-ajax';
    const REPLACE_REGEX = '(<a[^>]*(%s)?[^>]*)%s([^>]*(%s)?)';
    const DATA_POST = 'data-post';
    const HREF_ATTR = '@href="#"@';
    const WISHLIST_REGEX = '@(<a[^>]*)data-post([^>]*towishlist[^>]*)@';
    const COMPARE_REGEX = '@(<a[^>]*tocompare[^>]*)data-post([^>]*)@';
    
    /**
     * @var ModelConfig
     */
    protected $modelConfig;

    /**
     * @param ModelConfig $modelConfig
     */
    public function __construct(
        ModelConfig $modelConfig
    ) {
        $this->modelConfig = $modelConfig;
    }

    /**
     * @param string $html
     * @param array $patterns
     */
    public function dataPostReplace(
        &$html,
        $patterns = ['@' . self::DATA_POST . '@']
    ) {
        $actionsAjax = $this->modelConfig->isActionsAjax();
        if ($actionsAjax) {
            foreach ($patterns as $pattern) {
                $html = preg_replace(
                    $pattern,
                    '$1' . self::DATA_POST_AJAX . '$2',
                    $html
                );
            }
            $html = preg_replace(
                self::HREF_ATTR,
                '',
                $html
            );
        }
    }
}
