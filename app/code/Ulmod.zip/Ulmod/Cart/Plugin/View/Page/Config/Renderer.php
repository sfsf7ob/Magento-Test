<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Plugin\View\Page\Config;

use Magento\Framework\App\CacheInterface;
use Magento\Framework\View\Page\Config\Renderer as MagentoRenderer;
use Magento\Framework\View\Asset\File;
use Magento\Framework\View\Page\Config as PageConfig;

class Renderer
{
    const CACHE_KEY = 'ulmod_cart_should_load_css_file';

    protected $filesToCheck = [
        'css/styles-l.css',
        'css/styles-m.css'
    ];

    /**
     * @var CacheInterface
     */
    private $cache;

    /**
     * @var PageConfig
     */
    private $config;

    /**
     * @param PageConfig $config
     * @param CacheInterface $cache
     */
    public function __construct(
        PageConfig $config,
        CacheInterface $cache
    ) {
        $this->config = $config;
        $this->cache = $cache;
    }

    /**
     * @return int
     */
    private function isShouldLoadCss()
    {
        $found = 0;
        
        $collection = $this->config->getAssetCollection();
        foreach ($collection as $item) {
            /** @var File $item */
            $filePath = $item->getFilePath();
            if ($item instanceof File
                && in_array($filePath, $this->filesToCheck)
            ) {
                $found++;
            }
        }

        return (int)($found < count($this->filesToCheck));
    }

    /**
     * Add our css file if less functionality is missing
     *
     * @param MagentoRenderer $subject
     * @param array $resultGroups
     * @return array
     */
    public function beforeRenderAssets(
        MagentoRenderer $subject,
        $resultGroups = []
    ) {
        $shouldLoad = $this->cache->load(self::CACHE_KEY);
        if ($shouldLoad === false) {
            $shouldLoad = $this->isShouldLoadCss();
            $this->cache->save(
                $shouldLoad,
                self::CACHE_KEY
            );
        }

        if ($shouldLoad) {
            $this->config->addPageAsset(
                'Ulmod_Cart::css/source/mkcss/umcart.css'
            );
        }

        return [$resultGroups];
    }
}
