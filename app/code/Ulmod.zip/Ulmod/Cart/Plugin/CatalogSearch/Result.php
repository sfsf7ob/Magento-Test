<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Plugin\CatalogSearch;

use Magento\CatalogSearch\Block\Result as BlockResult;
use Ulmod\Cart\Model\Config as ModelConfig;
use Magento\Framework\View\LayoutFactory;
        
class Result
{
    /**
     * @var ModelConfig
     */
    private $modelConfig;

    /**
     * @var LayoutFactory
     */
    private $layoutFactory;

    /**
     * @param ModelConfig $modelConfig
     * @param LayoutFactory $layoutFactory
     */
    public function __construct(
        ModelConfig $modelConfig,
        LayoutFactory $layoutFactory
    ) {
        $this->modelConfig = $modelConfig;
        $this->layoutFactory = $layoutFactory;
    }

    /**
     * @param BlockResult $subject
     * @param string $result
     * @return string
     */
    public function afterGetProductListHtml(
        BlockResult $subject,
        $result
    ) {
        $isEnable = $this->modelConfig->getModuleConfig('general/enable');
        if ($isEnable) {
            $layout = $this->layoutFactory->create();
            $configBlock = $layout->createBlock(
                'Ulmod\Cart\Block\Config',
                'ulmod.cart.config',
                [ 'data' => [] ]
            );

            $html = $configBlock->setPageType('category')
                ->toHtml();
                
            $result .= $html;
        }

        return  $result;
    }
}
