<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Controller\Wishlist;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Ulmod\Cart\Model\Config as ModelConfig;
use Magento\Catalog\Helper\Product as ProductHelper;
use Magento\Checkout\Helper\Cart as CartHelper;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\View\LayoutInterface;
use Magento\Framework\Registry;
use Magento\Catalog\Model\Session as CatalogSession;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Wishlist\Model\ItemFactory;
use Magento\Wishlist\Controller\WishlistProviderInterface;
use Magento\Wishlist\Model\LocaleQuantityProcessor;
use Magento\Wishlist\Model\Item\OptionFactory;
use Magento\Wishlist\Helper\Data as WishlistHelper;
use Magento\Catalog\Block\Product\ImageBuilder;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product\Exception as ProductException;
use Magento\Checkout\Model\Cart as CustomerCart;
use Magento\Framework\View\Result\PageFactory;
use Magento\Checkout\Helper\Data as HelperData;
use Magento\Framework\Url\Helper\Data as UrlHelper;
use Magento\Framework\DataObjectFactory as ObjectFactory;
use Magento\Framework\Escaper;

class Cart extends \Ulmod\Cart\Controller\Cart\Add
{
    /**
     * @var WishlistHelper
     */
    private $wishlistHelper;
    
    /**
     * @var WishlistProviderInterface
     */
    private $wishlistProvider;

    /**
     * @var ItemFactory
     */
    private $itemFactory;

    /**
     * @var LocaleQuantityProcessor
     */
    private $quantityProcessor;
    
    /**
     * @var OptionFactory
     */
    private $optionFactory;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param CheckoutSession $checkoutSession
     * @param StoreManagerInterface $storeManager
     * @param FormKeyValidator $formKeyValidator
     * @param CustomerCart $cart
     * @param ProductRepositoryInterface $productRepository
     * @param ModelConfig $modelConfig
     * @param ProductHelper $productHelper
     * @param CartHelper $cartHelper
     * @param ResolverInterface $localeResolver
     * @param LayoutInterface $layout
     * @param PageFactory $resultPageFactory
     * @param Registry $coreRegistry
     * @param CatalogSession $catalogSession
     * @param CategoryFactory $categoryFactory
     * @param HelperData $helperData
     * @param Escaper $escaper
     * @param UrlHelper $urlHelper
     * @param ItemFactory $itemFactory
     * @param WishlistProviderInterface $wishlistProvider
     * @param LocaleQuantityProcessor $quantityProcessor
     * @param OptionFactory $optionFactory
     * @param WishlistHelper $wishlistHelper
     * @param ObjectFactory $objectFactory
     * @param ImageBuilder $imageBuilder
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        CheckoutSession $checkoutSession,
        StoreManagerInterface $storeManager,
        FormKeyValidator $formKeyValidator,
        CustomerCart $cart,
        ProductRepositoryInterface $productRepository,
        ModelConfig $modelConfig,
        ProductHelper $productHelper,
        CartHelper $cartHelper,
        ResolverInterface $localeResolver,
        LayoutInterface $layout,
        PageFactory $resultPageFactory,
        Registry $coreRegistry,
        CatalogSession $catalogSession,
        CategoryFactory $categoryFactory,
        HelperData $helperData,
        Escaper $escaper,
        UrlHelper $urlHelper,
        ItemFactory $itemFactory,
        WishlistProviderInterface $wishlistProvider,
        LocaleQuantityProcessor $quantityProcessor,
        OptionFactory $optionFactory,
        WishlistHelper $wishlistHelper,
        ObjectFactory $objectFactory,
        ImageBuilder $imageBuilder
    ) {
        parent::__construct(
            $context,
            $scopeConfig,
            $checkoutSession,
            $storeManager,
            $formKeyValidator,
            $cart,
            $productRepository,
            $modelConfig,
            $productHelper,
            $cartHelper,
            $localeResolver,
            $layout,
            $resultPageFactory,
            $coreRegistry,
            $catalogSession,
            $categoryFactory,
            $helperData,
            $escaper,
            $urlHelper,
            $objectFactory,
            $imageBuilder
        );
        $this->wishlistProvider = $wishlistProvider;
        $this->itemFactory = $itemFactory;
        $this->quantityProcessor = $quantityProcessor;
        $this->wishlistHelper = $wishlistHelper;
        $this->cartHelper = $cartHelper;
        $this->optionFactory = $optionFactory;
        $this->localeResolver = $localeResolver;
    }

    /**
     * Add wishlist item to shopping cart and remove from wishlist
     *
     * If Product has required options - item removed from wishlist and redirect
     * to product view page with message about needed defined required options
     *
     * @return \Magento\Framework\Controller\ResultInterface
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $params = $this->getRequest()->getParams();
        
        $itemId = (int)$this->getRequest()->getParam('item');

        /** @var \Magento\Wishlist\Model\Item $item */
        $item = $this->itemFactory->create()->load($itemId);
        
        if (!$item->getId()) {
            $message = __('We can\'t add this item to your shopping cart right now.');
            return $this->addToCartResponse($message, 0);
        }

        $wishlistId = $item->getWishlistId();
        $wishlist = $this->wishlistProvider->getWishlist($wishlistId);
        if (!$wishlist) {
            $message = __('We can\'t add this item to your shopping cart right now.');
            return $this->addToCartResponse($message, 0);
        }

        $storeId = $this->_storeManager->getStore()->getId();
        $productId = $item->getProductId();
        $product = $this->productRepository->getById(
            $productId,
            false,
            $storeId
        );
        
        $this->setProduct($product);

        $showOptionResponse = $this->isShowOptionResponse(
            $product,
            $params
        );
        
        if ($showOptionResponse) {
            return $this->showOptionsResponse(
                $product,
                null,
                'wishlist/index/cart'
            );
        }

        // Set quantity
        $quantity = $this->getRequest()->getParam('qty');
        if (is_array($quantity)) {
            if (isset($quantity[$itemId])) {
                $quantity = $quantity[$itemId];
            } else {
                $quantity = 1;
            }
        }

        $quantity = $this->quantityProcessor->process($quantity);
        if ($quantity) {
            $item->setQty($quantity);
        }

        try {
            /** @var \Magento\Wishlist\Model\ResourceModel\Item\Option\Collection $itemOptions */
            $itemOptions = $this->optionFactory->create()->getCollection()->addItemFilter([$itemId]);
            
            $itemOptions = $itemOptions->getOptionsByItem($itemId);
            $item->setOptions($itemOptions);

            $requestParams = $this->getRequest()->getParams();
            $buyItemRequest = $item->getBuyRequest();
            $buyRequest = $this->_productHelper->addParamsToBuyRequest(
                $requestParams,
                ['current_config' => $buyItemRequest]
            );

            $item->mergeBuyRequest($buyRequest);

            $item->addToCart(
                $this->cart,
                true
            );
            
            $this->cart->save()->getQuote()
                ->collectTotals();
            
            $wishlist->save();

            $prodUrl = $product->getProductUrl();
            $prodName = $product->getName();

            $quoteHasError = $this->cart->getQuote()->getHasError();
            if (!$quoteHasError) {
                $message = '<p>' . __(
                    '%1 has been added to your cart.',
                    '<a href="' . $prodUrl .'" title=" . ' .
                    $prodName . '">' .
                    $prodName .
                    '</a>'
                ) . '</p>';

                $page = $this->resultPageFactory->create(
                    false,
                    ['isIsolated' => true]
                );
                
                $page->addHandle('wishlist_index_index');

                $this->setProduct($product);
                
                $message = $this->getProductAddedMessage(
                    $product,
                    $message
                );

                $wishlistBlock = $page->getLayout()
                    ->getBlock('customer.wishlist');

                return $this->addToCartResponse($message, 1, [
                    'customer_wishlist' => $wishlistBlock->toHtml()
                ]);
            } else {
                $message = [];
                $quoteErrors = $this->cart->getQuote()
                    ->getErrors();
                foreach ($quoteErrors as $error) {
                    $message[] = $error->getText();
                }
                return $this->showMessages($message);
            }
        } catch (ProductException $e) {
            return $this->showMessages(
                [__('This product(s) is out of stock.')]
            );
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            return $this->showMessages(
                [nl2br($e->getMessage())]
            );
        } catch (\Exception $e) {
            $this->addToCartResponse(
                __('We can\'t add the item to the cart right now.'),
                0
            );
        }

        $this->wishlistHelper->calculate();
    }
}
