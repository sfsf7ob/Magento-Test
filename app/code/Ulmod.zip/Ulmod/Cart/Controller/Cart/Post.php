<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Controller\Cart;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Helper\PostHelper;
use Magento\Catalog\Block\Product\AbstractProduct;
use Magento\Framework\Json\Helper\Data as JsonHelper;
use Magento\Store\Model\StoreManagerInterface;

class Post extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PostHelper
     */
    private $postHelper;

    /**
     * @var AbstractProduct
     */
    private $abstractProduct;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;
    
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    
    /**
     * @var JsonHelper
     */
    private $jsonHelper;

    /**
     * @param Context $context
     * @param PostHelper $postHelper
     * @param ProductRepositoryInterface $productRepository
     * @param AbstractProduct $abstractProduct
     * @param JsonHelper $jsonHelper
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        PostHelper $postHelper,
        ProductRepositoryInterface $productRepository,
        AbstractProduct $abstractProduct,
        JsonHelper $jsonHelper,
        StoreManagerInterface $storeManager
    ) {
        $this->postHelper = $postHelper;
        $this->abstractProduct = $abstractProduct;
        $this->productRepository = $productRepository;
        $this->storeManager = $storeManager;
        $this->jsonHelper = $jsonHelper;
        parent::__construct($context);
    }

    /**
     * Post Action
     *
     * @return void
     */
    public function execute()
    {
        $product = $this->_initProduct();
        if ($product) {
            $entityId = $product->getEntityId();
            $postData = $this->postHelper->getPostData(
                $this->abstractProduct->getAddToCartUrl($product),
                ['product' => $entityId]
            );

            $jsonEncodeData = $this->jsonHelper->jsonEncode($postData);
            return $this->getResponse()->representJson($jsonEncodeData);
        }

        return '';
    }

    /**
     * Initialize product instance from request data
     *
     * @return \Magento\Catalog\Model\Product|false
     */
    protected function _initProduct()
    {
        $prodId = (int)$this->getRequest()->getParam('product');
        if ($prodId) {
            $storeId = $this->storeManager->getStore()->getId();
            try {
                return $this->productRepository->getById(
                    $prodId,
                    false,
                    $storeId
                );
            } catch (NoSuchEntityException $e) {
                return false;
            }
        }

        return false;
    }
}
