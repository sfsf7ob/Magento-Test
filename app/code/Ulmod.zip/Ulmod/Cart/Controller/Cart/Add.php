<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Controller\Cart;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Ulmod\Cart\Model\Config as ModelConfig;
use Magento\Catalog\Helper\Product as ProductHelper;
use Magento\Checkout\Helper\Cart as CartHelper;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\View\LayoutInterface;
use Magento\Framework\Registry;
use Magento\Catalog\Model\Session as CatalogSession;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Block\Product\ImageBuilder;
use Magento\Catalog\Model\Product;
use Magento\Checkout\Model\Cart as CustomerCart;
use Ulmod\Cart\Model\Source\ConfirmPopup;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Url\Helper\Data as UrlHelper;
use Magento\Framework\DataObjectFactory as ObjectFactory;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Checkout\Helper\Data as HelperData;

class Add extends \Magento\Checkout\Controller\Cart\Add
{
    /**
     * @var array
     */
    private $messages = [];
    
    /**
     * @var \Magento\Framework\App\ViewInterface
     */
    protected $_view;
    
    /**
     * @var Product
     */
    private $product;

    /**
     * @var ProductHelper
     */
    protected $_productHelper;

    /**
     * @var ModelConfig
     */
    protected $modelConfig;
    
    /**
     * @var LayoutFactory
     */
    protected $layoutFactory;

    /**
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * @var UrlHelper
     */
    protected $urlHelper;

    /**
     * @var HelperData
     */
    protected $helperData;

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var CatalogSession
     */
    protected $catalogSession;

    /**
     * @var CategoryFactory
     */
    protected $categoryFactory;

    /**
     * @var LayoutInterface
     */
    protected $layout;

    /**
     * @var ObjectFactory
     */
    private $objectFactory;

    /**
     * @var ImageBuilder
     */
    private $imageBuilder;

    /**
     * @var Escaper
     */
    protected $escaper;

    /**
     * @var CartHelper
     */
    protected $cartHelper;

    /**
     * @var ResolverInterface
     */
    protected $localeResolver;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param CheckoutSession $checkoutSession
     * @param StoreManagerInterface $storeManager
     * @param FormKeyValidator $formKeyValidator
     * @param CustomerCart $cart
     * @param ProductRepositoryInterface $productRepository
     * @param ModelConfig $modelConfig
     * @param ProductHelper $productHelper
     * @param CartHelper $cartHelper
     * @param ResolverInterface $localeResolver
     * @param LayoutInterface $layout
     * @param PageFactory $resultPageFactory
     * @param Registry $coreRegistry
     * @param CatalogSession $catalogSession
     * @param CategoryFactory $categoryFactory
     * @param HelperData $helperData
     * @param Escaper $escaper
     * @param UrlHelper $urlHelper
     * @param ObjectFactory $objectFactory
     * @param ImageBuilder $imageBuilder
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        CheckoutSession $checkoutSession,
        StoreManagerInterface $storeManager,
        FormKeyValidator $formKeyValidator,
        CustomerCart $cart,
        ProductRepositoryInterface $productRepository,
        ModelConfig $modelConfig,
        ProductHelper $productHelper,
        CartHelper $cartHelper,
        ResolverInterface $localeResolver,
        LayoutInterface $layout,
        PageFactory $resultPageFactory,
        Registry $coreRegistry,
        CatalogSession $catalogSession,
        CategoryFactory $categoryFactory,
        HelperData $helperData,
        Escaper $escaper,
        UrlHelper $urlHelper,
        ObjectFactory $objectFactory,
        ImageBuilder $imageBuilder
    ) {
        $this->modelConfig = $modelConfig;
        $this->resultPageFactory = $resultPageFactory;
        $this->_productHelper = $productHelper;
        $this->helperData = $helperData;
        $this->_view = $context->getView();
        $this->_coreRegistry = $coreRegistry;
        $this->urlHelper = $urlHelper;
        $this->layout = $layout;
        $this->localeResolver = $localeResolver;
        $this->objectFactory = $objectFactory;
        $this->escaper = $escaper;
        $this->catalogSession = $catalogSession;
        $this->categoryFactory = $categoryFactory;
        $this->cartHelper = $cartHelper;
        $this->imageBuilder = $imageBuilder;
        parent::__construct(
            $context,
            $scopeConfig,
            $checkoutSession,
            $storeManager,
            $formKeyValidator,
            $cart,
            $productRepository
        );
    }

    /**
     * Add Action
     *
     * @return void
     */
    public function execute()
    {
        $validate = $this->_formKeyValidator->validate($this->getRequest());
        if (!$validate) {
            $message = __('We can\'t add this item to your shopping cart right now. Please reload the page.');
            return $this->addToCartResponse($message, 0);
        }

        $params = $this->getRequest()->getParams();
        $product = $this->_initProduct();

        if (!$product) {
            $message = __('We can\'t add this item to your shopping cart right now.');
            return $this->addToCartResponse($message, 0);
        }
        $this->setProduct($product);

        try {
            $showOptionResponse = $this->isShowOptionResponse($product, $params);
            if ($showOptionResponse) {
                $configurableParams = isset($params['super_attribute'])
                    ? $params['super_attribute'] : null;
                    
                return $this->showOptionsResponse(
                    $product,
                    $configurableParams
                );
            }

            if (isset($params['qty'])) {
                $filter = new \Zend_Filter_LocalizedToNormalized(
                    ['locale' => $this->localeResolver->getLocale()]
                );
                $params['qty'] = $filter->filter($params['qty']);
            }

            $related = $this->getRequest()->getParam('related_product');
            $this->cart->addProduct($product, $params);
            if (!empty($related)) {
                $this->cart->addProductsByIds(
                    explode(',', $related)
                );
            }

            $this->cart->save();

            $this->_coreRegistry->unregister('ulmod_cart_simple_product');

            $this->_eventManager->dispatch(
                'checkout_cart_add_product_complete',
                [
                    'product' => $product,
                    'request' => $this->getRequest(),
                    'response' => $this->getResponse()
                ]
            );

            $noCartRedirect = $this->_checkoutSession->getNoCartRedirect(true);
            if (!$noCartRedirect) {
                if (!$this->cart->getQuote()->getHasError()) {
                    $productName = $product->getName();
                    $productUrl = $product->getProductUrl();
                    $message = '<p>' . __(
                        '%1 has been added to your cart',
                        '<a href="' . $productUrl .'" title=" . ' .
                            $productName . '">' .
                            $productName .
                            '</a>'
                    ) . '</p>';

                    $message = $this->getProductAddedMessage(
                        $product,
                        $message
                    );
                    
                    return $this->addToCartResponse($message, 1);
                } else {
                    $message = [];
                    $errors = $this->cart->getQuote()->getErrors();
                    foreach ($errors as $error) {
                        $message[] = $error->getText();
                    }

                    return $this->showMessages($message);
                }
            }
        } catch (LocalizedException $e) {
            $errorMessage = $this->escaper->escapeHtml($e->getMessage());
            return $this->showMessages(
                [
                    nl2br($errorMessage)
                ]
            );
        } catch (\Exception $e) {
            $message = __('We can\'t add this item to your shopping cart right now.');
            $message .= $e->getMessage();
            return $this->addToCartResponse($message, 0);
        }
    }

    /**
     * Is show options response
     * @param $product
     * @param $params
     *
     * @return void
     */
    protected function isShowOptionResponse($product, $params)
    {
        $requiredOptions = $product->getTypeInstance()
            ->hasRequiredOptions($product);
            
        $showOptionsResponse = false;
        switch ($product->getTypeId()) {
            case 'configurable':
                $configAttributesCount = $product->getTypeInstance()
                    ->getConfigurableAttributes($product)
                    ->count();
                    
                $superAttributeCount = (array_key_exists('super_attribute', $params)) ?
                    count(array_filter($params['super_attribute'])) : 0;
                if (isset($params['configurable-option'])) {
                    // compatibility with product matrix by Ulmod
                    $matrixOptionSelected = false;
                    foreach ($params['umconfigurable-option'] as $umConfigOption) {
                        $umOptionData = $this->modelConfig->decode($umConfigOption);
                        if (isset($umOptionData['qty']) && $umOptionData['qty'] > 0) {
                            $matrixOptionSelected = true;
                            break;
                        }
                    }
                    if (!$matrixOptionSelected) {
                        $this->messages[] = __('Please specify the quantity of product(s).');
                        $showOptionsResponse = true;
                    }
                } elseif ($configAttributesCount != $superAttributeCount) {
                    $showOptionsResponse = true;
                }
                break;
            case 'grouped':
                if (!array_key_exists('super_group', $params)) {
                    $showOptionsResponse = true;
                }
                break;
            case 'bundle':
                if (!array_key_exists('bundle_option', $params)) {
                    $showOptionsResponse = true;
                }
                break;
            case 'downloadable':
                if ($requiredOptions && !array_key_exists('links', $params)
                    && !array_key_exists('options', $params)
                ) {
                    $showOptionsResponse = true;
                }
                break;
            case 'simple':
            case 'virtual':
                // required custom options
                if ($requiredOptions && !array_key_exists('options', $params)) {
                    $showOptionsResponse = true;
                }
                break;
        }

        // not required custom options block
        $isRedirectToProduct = $this->modelConfig->isRedirectToProduct();
        $productPage = $this->getRequest()->getParam('product_page');
        if (!$isRedirectToProduct && $product->getOptions()
            && !(array_key_exists('options', $params) || $productPage == "true")
        ) {
            $showOptionsResponse = true;
        }

        $result = $this->objectFactory->create([
            'data' => [
                'show_options_response' => $showOptionsResponse
            ]
        ]);
        $this->_eventManager->dispatch(
            'ulmod_cart_add_is_show_option_response_after',
            ['controller' => $this, 'result' => $result]
        );

        return $result->getShowOptionsResponse();
    }

    /**
     * If product is composite - show popup with options
     * @param array $message
     *
     * @return mixed
     */
    protected function showMessages($message)
    {
        $product = $this->getProduct();
        if (!$product->isComposite()) {
            return $this->addToCartResponse(
                implode(', ', $message),
                0
            );
        } else {
            $this->messages = $message;
            return $this->showOptionsResponse(
                $product,
                null
            );
        }
    }
    
    /**
     * Creating options popup
     * @param Product $product
     * @param array|null $selectedOptions Selected configurable options
     * @param string|null $submitRoute
     * @return mixed
     */
    protected function showOptionsResponse(
        Product $product,
        $selectedOptions = null,
        $submitRoute = null
    ) {
        $redirectToProduct = $this->modelConfig->isRedirectToProduct();
        $productPageParam = $this->getRequest()->getParam('product_page');
        if ($redirectToProduct && $productPageParam == "false") {
            $result['redirect'] = $product->getProductUrl();
            $resultObject = $this->objectFactory->create(
                ['data' => ['result' => $result]]
            );
            $this->messageManager->addNoticeMessage(
                __('You need to choose options for your item.')
            );

            return $this->getResponse()->representJson(
                $this->modelConfig->encode($resultObject->getResult())
            );
        }

        $this->_productHelper->initProduct(
            $product->getEntityId(),
            $this
        );
        
        $page = $this->resultPageFactory->create(
            false,
            ['isIsolated' => true]
        );
        
        $page->addHandle('catalog_product_view');

        $type = $product->getTypeId();
        $page->addHandle('catalog_product_view_type_' . $type);

        $optionsHtmlGen = $this->generateOptionsHtml(
            $product,
            $page,
            $submitRoute
        );

        $isMiniPage = $this->modelConfig->isRedirectToProduct() ? 1 : $this->isMiniPage();
        if ($isMiniPage) {
            $block = $page->getLayout()->createBlock(
                \Ulmod\Cart\Block\Product\Minipage::class,
                'ulmod.cart.minipage',
                [ 'data' =>
                      [
                        'product' => $product,
                        'optionsHtml' => $optionsHtmlGen,
                        'imageBuilder' => $this->imageBuilder,
                        'pageFactory' => $this->resultPageFactory
                      ]
                ]
            );
            $message = $block->toHtml();
            $cancelBtnName = __('Continue shopping');
        } else {
            $message = $optionsHtmlGen;
            $cancelBtnName = __('Cancel');
        }

        $result = [
            'title'     =>  __('Set options'),
            'b1_name'   =>  $cancelBtnName,
            'b2_name'   =>  __('Add to cart'),
            'b1_action' =>  'self.confirmHide();',
            'b2_action' =>  'self.submitFormInPopup();',
            'align' =>  'self.confirmHide();',
            'is_add_to_cart' =>  '0',
            'message'   =>  $message,
            'is_minipage' => $isMiniPage ? true : false
        ];

        if ($selectedOptions) {
            $result['selected_options'] = $selectedOptions;
        }

        $resultObject = $this->objectFactory->create(
            [
                'data' => [
                    'result' => $result
                ]
            ]
        );
        
        $this->_eventManager->dispatch(
            'ulmod_cart_add_show_option_response_after',
            [
                'controller' => $this,
                'product' => $product,
                'result' => $resultObject
            ]
        );

        return $this->getResponse()->representJson(
            $this->modelConfig->encode($resultObject->getResult())
        );
    }

    /**
     * @return bool
     */
    private function isMiniPage()
    {
        $confirmPopup = $this->modelConfig->getModuleConfig(
            'popup/confirm_display/confirm_popup'
        );
        
        return $confirmPopup == ConfirmPopup::MINI_PAGE;
    }
    
    /**
     * Generate html for product options
     * @param Product $product
     * @param $page
     * @param string|null $submitRoute
     *
     * @return mixed|string
     */
    protected function generateOptionsHtml(Product $product, $page, $submitRoute)
    {
        $block = $page->getLayout()->getBlock('product.info');
        if (!$block) {
            $block = $page->getLayout()->createBlock(
                \Magento\Catalog\Block\Product\View::class,
                'product.info',
                [ 'data' => [] ]
            );
        }

        $block->setProduct($product);
        if ($submitRoute) {
            $block->setData('submit_route_data', [
                'route' => $submitRoute
            ]);
        }
        $html = $block->toHtml();

        $prodId = $product->getId();
        $html = str_replace(
            '"spConfig',
            '"priceHolderSelector": ".price-box[data-product-id=' . $prodId . ']", "spConfig',
            $html
        );

        $contentClass = 'product-options-bottom';
        if ($product->getTypeId() == Configurable::TYPE_CODE) {
            $contentClass .= ' product-item';
        }

        $errors = '';
        if (count($this->messages)) {
            $errors .= '<div class="message error">'
                . implode(' ', $this->messages) . '</div>';
        }

        $isMiniPage = $this->modelConfig->isRedirectToProduct() ? 1 : $this->isMiniPage();

        if ($isMiniPage) {
            $title = '';
        } else {
            $productName = $product->getName();
            $productUrl = $product->getProductUrl();
            $title = '<a href="' . $productUrl . '" title="' .
                $productName . '" class="added-item">' .
                $productName .
                '</a>';
        }

        $html = '<div class="' . $contentClass . '" >' .
            $title .
            $errors .
            $html .
            '</div>';
        $html = $this->replaceHtmlElements($html, $product);

        return $html;
    }

    /**
     * @param Product $product
     * @param $message
     * @return string
     */
    protected function getProductAddedMessage(Product $product, $message)
    {
        $isDisplayImageBlock = $this->modelConfig->isDisplayImageBlock();
        if ($isDisplayImageBlock) {
            $block = $this->layout->getBlock('ulmod.cart.product');
            if (!$block) {
                $block = $this->layout->createBlock(
                    \Ulmod\Cart\Block\Product::class,
                    'ulmod.cart.product',
                    [ 'data' => [] ]
                );
                $block->setTemplate('Ulmod_Cart::dialog.phtml');
            }

            $block->setQtyHtml($this->getQtyBlockHtml($product));
            $block->setProduct($product);

            $message = $block->toHtml();
        } else {
            $message .= $this->getQtyBlockHtml($product);
        }

        $message .= "<div id='umcart-info' class='umcart-info'>";
        
        //display count cart item
        if ($this->modelConfig->isDisplayCount()) {
            $summary = $this->cart->getSummaryQty();
            $cartUrl = $this->cartHelper->getCartUrl();
          //  $viewCartText = $this->modelConfig->getViewCartText();
            if ($summary == 1) {
                $messagePartOne = __('There is');
                $messagePartTwo = __(' item');
            } else {
                $messagePartOne = __('There are');
                $messagePartTwo = __(' items');
            }

            $message .=
                "<p id='umcart-count' class='text'>".
                $messagePartOne .
                ' <a href="'. $cartUrl .'" id="um-a-count" data-umcart="umcart-count" title="' . __('View Cart') . '">'.
                $summary.  $messagePartTwo .
                '</a> '.
                __(' in your cart.') .
                "</p>";
        }

        // cart subtotal
        $isDisplaySubtotal = $this->modelConfig->isDisplaySubtotal();
        if ($isDisplaySubtotal) {
            $message .=
                '<p class="umcart-subtotal text">' .
                __('Cart Subtotal:') .
                ' <span class="um_price" data-umcart="umcart-price">'.
                $this->getSubtotalHtml() .
                '</span></p>';
        }
        
        // qty block
        if ($this->modelConfig->isChangeQty()) {
            $message .= $this->getQtyBlockHtml($product);
        }
        
        $message .= "</div>";

        // product relationship
        $type = $this->modelConfig->getModuleConfig('popup/selling/block_type');
        if ($type && $type !== '0') {
            /* replace uenc for correct redirect*/
            $refererUrl = $this->_request->getServer('HTTP_REFERER');
            $message = $this->replaceUenc($refererUrl, $message);
        }

        return $message;
    }

    /**
     * @return string
     */
    protected function getAdditionalBlockHtml()
    {
        //display related products
        $html = '';
        $product = $this->getProduct();
        $type = $this->modelConfig->getModuleConfig('popup/selling/block_type');
        $entityId = $product->getEntityId();
        if ($type && $type !== '0' && $product) {
            $this->_productHelper->initProduct($entityId, $this);
            $this->layout->createBlock(
                \Magento\Framework\Pricing\Render::class,
                'product.price.render.default',
                ['data' => [
                    'price_render_handle' => 'catalog_product_prices',
                    'use_link_for_as_low_as' => true
                ]]
            );
            $block = $this->layout->createBlock(
                'Ulmod\Cart\Block\Product\\' . ucfirst($type),
                'ulmod.cart.product_' . $type,
                ['data' => []]
            );
            $block->setProduct($product)
                ->setTemplate("Ulmod_Cart::product/list/items.phtml");
                
            $html = $block->toHtml();
            
            $refererUrl = $product->getProductUrl();
            
            $html = $this->replaceUenc($refererUrl, $html);
        }

        return $html;
    }

    /**
     * @return string
     */
    protected function getSubtotalHtml()
    {
        $totals = $this->cart->getQuote()->getTotals();
        $subtotal = isset($totals['subtotal'])
            && $totals['subtotal'] instanceof Total
            ? $totals['subtotal']->getValue()
            : 0;

        return $this->helperData->formatPrice($subtotal);
    }

    /**
     * @param $message
     * @param $status
     * @param array $additionalResult
     *
     * @return mixed
     */
    protected function addToCartResponse($message, $status, $additionalResult = [])
    {
        $result = ['is_add_to_cart' => $status];
        
        $isOpenMinicart = $this->modelConfig->isOpenMinicart();
        if (!$isOpenMinicart) {
            $cartUrl = $this->cartHelper->getCartUrl();
            if (!$status) {
                $message = '<div class="message error">' . $message . '</div>';
            }
            
            $result = array_merge(
                $result,
                [
                    'title'     => __('Information'),
                    'message'   => $message,
                    'related'   => $this->getAdditionalBlockHtml(),
                    'b1_name'   => __($this->modelConfig->getContinueText()),
                    'b2_name'   => __($this->modelConfig->getViewCartText()),
                    'b2_action' => 'document.location = "' . $cartUrl . '";',
                    'b1_action' => 'self.confirmHide();',
                    'checkout'  => '',
                    'timer'     => ''
                ]
            );

            $isDisplayGoToCheckout = $this->modelConfig->isDisplayGoToCheckout();
            $gotoCheckoutText = $this->modelConfig->getGotoCheckoutText();
            if ($isDisplayGoToCheckout) {
                $goto = __($gotoCheckoutText);
                $result['checkout'] =
                    '<a class="checkout"
                    title="' . $goto . '"
                    data-role="proceed-to-checkout"
                    href="' . $this->modelConfig->getUrl('checkout') . '"
                    >
                    ' . $goto . '
                </a>';
            }

            // Product page : go to category page or custom page
            $isProductView = $this->getRequest()->getParam('product_page');
            $productButton = $this->modelConfig->getModuleConfig('popup/product/product_button');
            if ($isProductView == 'true' && $productButton == 1) {
                $categoryId = $this->catalogSession->getLastVisitedCategoryId();
                if (!$categoryId && $this->getProduct()) {
                    $productCats = $this->getProduct()->getCategoryIds();
                    if (count($productCats) > 0) {
                        $rootCategoryId = $this->_storeManager->getStore()
                            ->getRootCategoryId();

                        $categoryId = $productCats[0];
                        if ($categoryId == $rootCategoryId) {
                            if (isset($productCats[1])) {
                                $categoryId = $productCats[1];
                            } else {
                                $categoryId = null;
                            }
                        }
                    }
                }
                if ($categoryId) {
                    $category = $this->categoryFactory->create()
                        ->load($categoryId);
                    if ($category) {
                        $result['b1_action'] = 'document.location = "' .
                            $category->getUrl()
                            . '";';
                    }
                }
            } elseif ($isProductView == 'true' && $productButton == 2) {
                $customUrl = $this->modelConfig->getModuleConfig('popup/product/custom_url');
                $result['b1_action'] = 'document.location = "' . $customUrl . '";';
            }
            
            //add timer
            $time = $this->modelConfig->getTime();
            if (0 < $time) {
                $result['timer'] .= '<span class="timer">'
                . '(' . $time . ')' . '</span>';
            }
        } else {
            $this->messageManager->addSuccessMessage(
                __(
                    '%1 has been added to your cart.',
                    $this->getProduct()->getName()
                )
            );
        }
        
        $result = array_merge($result, $additionalResult);

        if ($status) {
            $result['product_sku'] = $this->getProduct()->getSku();
            $result['product_id'] = $this->getProduct()->getId();
        }

        $resultObject = $this->objectFactory->create(
            ['data' => ['result' => $result]]
        );
        
        $this->_eventManager->dispatch(
            'ulmod_cart_add_addtocart_response_after',
            ['controller' => $this, 'result' => $resultObject]
        );

        return $this->getResponse()->representJson(
            $this->modelConfig->encode($resultObject->getResult())
        );
    }
    
    /**
     * @param string $refererUrl
     * @param string $item
     * @return string mixed
     */
    private function replaceUenc($refererUrl, $item)
    {
        $currentUrlEncoded = $this->urlHelper->getEncodedUrl();
        $newUrlEncoded = $this->urlHelper->getEncodedUrl($refererUrl);
        
        return str_replace($currentUrlEncoded, $newUrlEncoded, $item);
    }

    /**
     * @return Product
     */
    public function getProduct()
    {
        return $this->product;
    }
    
    /**
     * @param mixed $product
     */
    public function setProduct($product)
    {
        $this->product = $product;
    }
    
    /**
     * @param Product $product
     * @return string
     */
    private function getQtyBlockHtml($product)
    {
        $result = '';
        if ($this->modelConfig->isChangeQty()) {
            $quoteItem = $this->getItemByProduct(
                $product,
                $this->cart->getQuote()
            );
            
            if ($quoteItem) {
                $block = $this->layout->getBlock('ulmod.cart.qty');
                if (!$block) {
                    $block = $this->layout->createBlock(
                        \Ulmod\Cart\Block\Product::class,
                        'ulmod.cart.qty',
                        ['data' => []]
                    );
                }

                $block->setTemplate('Ulmod_Cart::qty.phtml');
                $block->setQty($quoteItem->getQty());
                $block->setQuoteId($quoteItem->getData('item_id'));

                $result = $block->toHtml();
            }
        }

        return $result;
    }

    /**
     * @param $html
     * @param Product $product
     * @return string
     */
    private function replaceHtmlElements($html, $product)
    {
        $currentUrlEncoded = $this->urlHelper->getEncodedUrl();
        $refererUrl = $product->getProductUrl();
        $newUrlEncoded = $this->urlHelper->getEncodedUrl($refererUrl);

        $html = str_replace(
            $currentUrlEncoded,
            $newUrlEncoded,
            $html
        );
        
        $html = str_replace(
            '"swatch-opt"',
            '"swatch-opt swatch-opt-' . $product->getId() . '"',
            $html
        );
        
        $html = str_replace(
            'spConfig": {"attributes',
            'spConfig": {"containerId":"#confirmBox", "attributes',
            $html
        );
        
        $html = str_replace(
            '[data-role=swatch-options]',
            '#confirmBox [data-role=swatch-options]',
            $html
        );

        return $html;
    }

    /**
     * Compare products by id
     * @param Product $product
     * @param \Magento\Quote\Model\Quote $quote
     * @return bool
     */
    public function getItemByProduct($product, $quote)
    {
        $productId = $product->getId();
        $result = false;
        foreach ($quote->getAllItems() as $item) {
            if ($item->getProduct()->getId() == $productId) {
                $result = $item;
                break;
            }
        }

        return $result;
    }
}
