<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Ulmod\Cart\Controller\Cart;

use Magento\Checkout\Model\Sidebar;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Checkout\Model\Session;
use Magento\Checkout\Helper\Data as HelperData;
use Magento\Framework\DataObjectFactory as ObjectFactory;
use Magento\Framework\Exception\LocalizedException;
use Ulmod\Cart\Model\Config as ModelConfig;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;

class Update extends Action
{
    /**
     * @var ModelConfig
     */
    private $modelConfig;
    
    /**
     * @var Session
     */
    private $session;

    /**
     * @var Sidebar
     */
    private $sidebar;
    
    /**
     * @var HelperData
     */
    private $helperData;

    /**
     * @var FormKeyValidator
     */
    private $formKeyValidator;

    /**
     * @var ObjectFactory
     */
    private $objectFactory;
    
    /**
     * @param Context $context
     * @param Sidebar $sidebar
     * @param Session $session
     * @param HelperData $helperData
     * @param ObjectFactory $objectFactory
     * @param ModelConfig $modelConfig
     * @param FormKeyValidator $formKeyValidator
     */
    public function __construct(
        Context $context,
        Sidebar $sidebar,
        Session $session,
        HelperData $helperData,
        ObjectFactory $objectFactory,
        ModelConfig $modelConfig,
        FormKeyValidator $formKeyValidator
    ) {
        $this->sidebar = $sidebar;
        $this->helperData = $helperData;
        $this->session = $session;
        $this->objectFactory = $objectFactory;
        $this->modelConfig = $modelConfig;
        $this->formKeyValidator = $formKeyValidator;
        parent::__construct($context);
    }

    /**
     * Update item options
     *
     * @return void
     */
    public function execute()
    {
        try {
            $validate = $this->formKeyValidator->validate($this->getRequest());
            if (!$validate) {
                throw new LocalizedException(
                    __('We can\'t add this item to your shopping cart right now. Please reload the page.')
                );
            }
        
            $itemQty = (int)$this->getRequest()->getParam('item_qty');
            if ($itemQty <= 0) {
                throw new LocalizedException(
                    __('We can\'t add this item to your shopping cart.')
                );
            }

            $itemId = (int)$this->getRequest()->getParam('item_id');
            $this->sidebar->checkQuoteItem($itemId);
            $this->sidebar->updateQuoteItem($itemId, $itemQty);
            
            $quote = $this->session->getQuote();

            $itemsSummaryQty = $quote->getItemsSummaryQty();
            $resultObject = $this->objectFactory->create(
                [
                    'data' => [
                        'result' => [
                            'items'    => $itemsSummaryQty . __(' items'),
                            'subtotal' => $this->getSubtotalHtml()
                        ]
                    ]
                ]
            );
        } catch (LocalizedException $exception) {
            $resultObject = $this->objectFactory->create(
                [
                    'data' => [
                        'result' => [
                            'error' => $exception->getMessage()
                        ]
                    ]
                ]
            );
        } catch (\Exception $exception) {
            $resultObject = $this->objectFactory->create(
                [
                    'data' => [
                        'result' => [
                            'error' => __('We can\'t add this item to your shopping cart.')
                        ]
                    ]
                ]
            );
        }

        return $this->getResponse()->representJson(
            $this->modelConfig->encode($resultObject->getResult())
        );
    }

    /**
     * @return string
     */
    protected function getSubtotalHtml()
    {
        $quoteTotals = $this->session->getQuote()->getTotals();
        $subtotal = isset($quoteTotals['subtotal'])
            && $quoteTotals['subtotal'] instanceof Total
            ? $quoteTotals['subtotal']->getValue()
            : 0;

        return $this->helperData->formatPrice($subtotal);
    }
}
