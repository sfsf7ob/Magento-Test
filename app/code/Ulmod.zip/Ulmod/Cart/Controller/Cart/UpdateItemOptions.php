<?php
/**
 * Copyright © Ulmod. All rights reserved.
 * See LICENSE.txt for license details.
 */
 
namespace Ulmod\Cart\Controller\Cart;

class UpdateItemOptions extends Add
{
    /**
     * Update item options
     *
     * @return void
     */
    public function execute()
    {
        $resultStatus = 0;
        
        $id = (int)$this->getRequest()->getParam('id');
        
        $this->setProduct($this->_initProduct());
        
        $params = $this->getRequest()->getParams();
        if (!isset($params['options'])) {
            $params['options'] = [];
        }
        try {
            if (isset($params['qty'])) {
                $locale = $this->localeResolver->getLocale();
                $filter = new \Zend_Filter_LocalizedToNormalized(
                    ['locale' => $locale]
                );
                $params['qty'] = $filter->filter($params['qty']);
            }

            $quoteItem = $this->cart->getQuote()->getItemById($id);
            if (!$quoteItem) {
                $message = __('We can\'t find the quote item.');
                return $this->addToCartResponse($message, 0);
            }

            $item = $this->cart->updateItem(
                $id,
                new \Magento\Framework\DataObject($params)
            );
            
            if (is_string($item)) {
                $message = __($item);
                return $this->addToCartResponse($message, 0);
            }

            if ($item->getHasError()) {
                $message = __($item->getMessage());
                return $this->addToCartResponse($message, 0);
            }

            $relatedParam = $this->getRequest()->getParam('related_product');
            if (!empty($relatedParam)) {
                $this->cart->addProductsByIds(
                    explode(',', $relatedParam)
                );
            }

            $this->cart->save();

            $this->_eventManager->dispatch(
                'checkout_cart_update_item_complete',
                [
                    'item' => $item,
                    'request' => $this->getRequest(),
                    'response' => $this->getResponse()
                ]
            );

            $isQuoteHasError = $this->cart->getQuote()->getHasError();
            if (!$isQuoteHasError) {
                $productName = $item->getProduct()->getName();
                $message = __(
                    '%1 was updated in your shopping cart.',
                    $this->escaper->escapeHtml($productName)
                );

                $resultStatus = 1;
            } else {
                $message = '';
                $errors = $this->cart->getQuote()->getErrors();
                foreach ($errors as $error) {
                    $message .= $error->getText();
                }
            }
        } catch (\Exception $e) {
            $message = __('We can\'t update the item right now.');
            $message .= ' ' . $e->getMessage();
        }

        return $this->addToCartResponse(
            $message,
            $resultStatus
        );
    }
}
